--[[
===========================================================================
  MoonAgent.lua — Агент Moon Control для MoonLoader (SAMP)
  
  Назначение:
    - Подключение к Moon Core через WebSocket
    - Парсинг игровых чат-сообщений по типам
    - Поиск триггеров в сообщениях
    - Отправка событий и хартбитов в Moon Core
    - Приём конфигураций и команд от Moon Core

  Автор: Moon Control Team
  Версия: 0.1.0
===========================================================================
--]]

-- ===========================================================================
-- МЕТАДАННЫЕ СКРИПТА (MoonLoader)
-- ===========================================================================
script_name('MoonAgent')
script_version('0.1.0')
script_author('Moon Control Team')
script_description('Агент мониторинга чата SAMP для Moon Control')

-- ===========================================================================
-- КОНФИГУРАЦИЯ
-- ===========================================================================
local CONFIG = {
    -- WebSocket соединение
    websocket_host       = "127.0.0.1",
    websocket_port       = 8765,
    -- Интервал хартбита (мс)
    heartbeat_interval   = 5000,
    -- Базовая задержка реконнекта (мс), экспоненциальный backoff: 1s → 2s → 4s → 8s → max
    reconnect_base_delay = 1000,
    -- Максимальная задержка реконнекта (мс)
    reconnect_max_delay  = 60000,
    -- Максимальный размер очереди оффлайн-событий
    max_queue_size       = 100,
    -- Размер локального буфера логов
    log_buffer_size      = 100,
    -- Режим отладки (вывод в консоль SAMP / samp-notify)
    debug_mode           = false,
    -- Таймаут подключения к WebSocket (мс)
    connect_timeout      = 5000,
    -- Таймаут приёма данных (мс)
    receive_timeout      = 100,
}

-- ===========================================================================
-- ИМПОРТЫ И ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ
-- ===========================================================================
local sampev = require 'sampev'
local moonloader = require 'moonloader'

-- Состояние агента
local state = {
    connected          = false,
    connecting         = false,
    socket             = nil,
    reconnect_delay    = CONFIG.reconnect_base_delay,
    last_reconnect_try = 0,
    last_heartbeat     = 0,
    last_frame_time    = os.clock(),
    fps                = 0,
    fps_frame_count    = 0,
    fps_last_calc      = os.clock(),
    triggers           = {},      -- загруженные триггеры
    chat_filters       = {},      -- активные фильтры чатов { chatType: bool }
    trigger_cooldowns  = {},      -- таймеры кулдаунов { triggerId: timestamp }
    event_queue        = {},      -- очередь оффлайн-событий
    log_buffer         = {},      -- локальный буфер логов
    server_name        = "Unknown",
    player_nickname    = "Unknown",
    handshake_done     = false,
    running            = true,
}

-- ===========================================================================
-- УТИЛИТЫ: ЛОГИРОВАНИЕ
-- ===========================================================================

--- Добавить запись в локальный буфер логов
local function add_log(level, message, details)
    local entry = {
        time     = os.date("%H:%M:%S"),
        level    = level or "info",
        message  = message or "",
        details  = details or "",
    }
    table.insert(state.log_buffer, entry)
    -- Удаляем старые записи если превышен лимит
    while #state.log_buffer > CONFIG.log_buffer_size do
        table.remove(state.log_buffer, 1)
    end
end

--- Лог отладки (только если включён debug_mode)
local function debug_log(message, details)
    if CONFIG.debug_mode then
        add_log("debug", message, details)
        print(string.format("[MoonAgent] [DEBUG] %s", message))
        if details then
            print(string.format("[MoonAgent] [DEBUG]   → %s", tostring(details)))
        end
    end
end

--- Лог информации
local function info_log(message, details)
    add_log("info", message, details)
    print(string.format("[MoonAgent] [INFO] %s", message))
end

--- Лог предупреждения
local function warn_log(message, details)
    add_log("warning", message, details)
    print(string.format("[MoonAgent] [WARN] %s", message))
end

--- Лог ошибки
local function error_log(message, details)
    add_log("error", message, details)
    print(string.format("[MoonAgent] [ERROR] %s", message))
end

-- ===========================================================================
-- УТИЛИТЫ: JSON (минимальная реализация)
-- ===========================================================================
-- Встроенный кодировщик/декодер JSON, т.к. внешние библиотеки могут быть
-- недоступны в MoonLoader.

local Json = {} -- таблица модуля JSON

--- Экранировать строку для JSON
local function json_escape(str)
    if type(str) ~= "string" then
        str = tostring(str)
    end
    local result = {}
    local i = 1
    while i <= #str do
        local c = str:sub(i, i)
        if c == '"' then
            table.insert(result, '\\"')
        elseif c == '\\' then
            table.insert(result, '\\\\')
        elseif c == '\n' then
            table.insert(result, '\\n')
        elseif c == '\r' then
            table.insert(result, '\\r')
        elseif c == '\t' then
            table.insert(result, '\\t')
        else
            local byte = string.byte(c)
            if byte < 32 then
                table.insert(result, string.format('\\u%04x', byte))
            else
                table.insert(result, c)
            end
        end
        i = i + 1
    end
    return table.concat(result)
end

--- Кодировать значение в JSON строку
function Json.encode(value)
    local t = type(value)
    if t == "nil" then
        return "null"
    elseif t == "boolean" then
        return value and "true" or "false"
    elseif t == "number" then
        if value ~= value then -- NaN
            return "null"
        end
        if value == 1/0 then return "1e999" end
        if value == -1/0 then return "-1e999" end
        return string.format("%.14g", value)
    elseif t == "string" then
        return '"' .. json_escape(value) .. '"'
    elseif t == "table" then
        -- Проверяем: массив или объект?
        local is_array = true
        local max_index = 0
        for k, _ in pairs(value) do
            if type(k) ~= "number" or k < 1 or math.floor(k) ~= k then
                is_array = false
                break
            end
            if k > max_index then
                max_index = k
            end
        end
        if is_array and max_index == #value then
            -- Массив
            local parts = {}
            for i = 1, #value do
                table.insert(parts, Json.encode(value[i]))
            end
            return '[' .. table.concat(parts, ',') .. ']'
        else
            -- Объект
            local parts = {}
            for k, v in pairs(value) do
                if type(k) == "string" then
                    table.insert(parts, '"' .. json_escape(k) .. '":' .. Json.encode(v))
                end
            end
            return '{' .. table.concat(parts, ',') .. '}'
        end
    else
        return '"' .. json_escape(tostring(value)) .. '"'
    end
end

--- Декодировать JSON строку в Lua таблицу (минимальный парсер)
function Json.decode(str)
    if type(str) ~= "string" then
        return nil, "Входные данные не строка"
    end

    local pos = 1
    local len = #str

    -- Пропустить пробелы и комментарии
    local function skip_ws()
        while pos <= len do
            local c = str:sub(pos, pos)
            if c == ' ' or c == '\t' or c == '\n' or c == '\r' then
                pos = pos + 1
            elseif c == '/' and pos + 1 <= len and str:sub(pos+1, pos+1) == '/' then
                -- однострочный комментарий
                pos = pos + 2
                while pos <= len and str:sub(pos, pos) ~= '\n' do
                    pos = pos + 1
                end
                if pos <= len then pos = pos + 1 end
            else
                break
            end
        end
    end

    -- Парсинг значения
    local function parse_value()
        skip_ws()
        if pos > len then
            return nil, "Неожиданный конец строки"
        end
        local c = str:sub(pos, pos)
        if c == '{' then
            return parse_object()
        elseif c == '[' then
            return parse_array()
        elseif c == '"' then
            return parse_string()
        elseif c == 't' then
            if str:sub(pos, pos+3) == "true" then
                pos = pos + 4
                return true
            end
            return nil, "Некорректный литерал"
        elseif c == 'f' then
            if str:sub(pos, pos+4) == "false" then
                pos = pos + 5
                return false
            end
            return nil, "Некорректный литерал"
        elseif c == 'n' then
            if str:sub(pos, pos+3) == "null" then
                pos = pos + 4
                return nil -- JSON null → Lua nil
            end
            return nil, "Некорректный литерал"
        elseif c == '-' or c:match('%d') then
            return parse_number()
        else
            return nil, string.format("Неожиданный символ '%s' на позиции %d", c, pos)
        end
    end

    -- Парсинг строки
    local function parse_string()
        pos = pos + 1 -- пропустить открывающую кавычку
        local result = {}
        while pos <= len do
            local c = str:sub(pos, pos)
            if c == '"' then
                pos = pos + 1
                return table.concat(result)
            elseif c == '\\' then
                pos = pos + 1
                if pos > len then
                    return nil, "Неожиданный конец строки (escape)"
                end
                local esc = str:sub(pos, pos)
                if esc == '"' then table.insert(result, '"')
                elseif esc == '\\' then table.insert(result, '\\')
                elseif esc == '/' then table.insert(result, '/')
                elseif esc == 'n' then table.insert(result, '\n')
                elseif esc == 'r' then table.insert(result, '\r')
                elseif esc == 't' then table.insert(result, '\t')
                elseif esc == 'b' then table.insert(result, '\b')
                elseif esc == 'f' then table.insert(result, '\f')
                elseif esc == 'u' then
                    local hex = str:sub(pos+1, pos+4)
                    if #hex < 4 then
                        return nil, "Некорректный unicode escape"
                    end
                    pos = pos + 4
                    local code = tonumber(hex, 16)
                    if code and code >= 0xD800 and code <= 0xDBFF then
                        -- Суррогатная пара (high surrogate)
                        if pos + 2 <= len and str:sub(pos+1, pos+2) == '\\u' then
                            local hex2 = str:sub(pos+3, pos+6)
                            if #hex2 == 4 then
                                local low = tonumber(hex2, 16)
                                if low and low >= 0xDC00 and low <= 0xDFFF then
                                    code = 0x10000 + (code - 0xD800) * 0x400 + (low - 0xDC00)
                                    pos = pos + 6
                                end
                            end
                        end
                    end
                    if code then
                        if code < 0x80 then
                            table.insert(result, string.char(code))
                        elseif code < 0x800 then
                            table.insert(result, string.char(192 + math.floor(code / 64), 128 + (code % 64)))
                        elseif code < 0x10000 then
                            table.insert(result, string.char(224 + math.floor(code / 4096), 128 + math.floor((code % 4096) / 64), 128 + (code % 64)))
                        else
                            table.insert(result, string.char(240 + math.floor(code / 262144), 128 + math.floor((code % 262144) / 4096), 128 + math.floor((code % 4096) / 64), 128 + (code % 64)))
                        end
                    end
                else
                    table.insert(result, esc)
                end
                pos = pos + 1
            else
                table.insert(result, c)
                pos = pos + 1
            end
        end
        return nil, "Не закрыта строка"
    end

    -- Парсинг числа
    local function parse_number()
        local start_pos = pos
        if str:sub(pos, pos) == '-' then
            pos = pos + 1
        end
        -- Целая часть
        if pos <= len and str:sub(pos, pos) == '0' then
            pos = pos + 1
        elseif pos <= len and str:sub(pos, pos):match('%d') then
            while pos <= len and str:sub(pos, pos):match('%d') do
                pos = pos + 1
            end
        else
            return nil, "Некорректное число"
        end
        -- Дробная часть
        if pos <= len and str:sub(pos, pos) == '.' then
            pos = pos + 1
            if pos > len or not str:sub(pos, pos):match('%d') then
                return nil, "Некорректное число (дробная часть)"
            end
            while pos <= len and str:sub(pos, pos):match('%d') do
                pos = pos + 1
            end
        end
        -- Экспоненциальная часть
        if pos <= len and (str:sub(pos, pos) == 'e' or str:sub(pos, pos) == 'E') then
            pos = pos + 1
            if pos <= len and (str:sub(pos, pos) == '+' or str:sub(pos, pos) == '-') then
                pos = pos + 1
            end
            if pos > len or not str:sub(pos, pos):match('%d') then
                return nil, "Некорректное число (экспонента)"
            end
            while pos <= len and str:sub(pos, pos):match('%d') do
                pos = pos + 1
            end
        end
        local num_str = str:sub(start_pos, pos - 1)
        local num = tonumber(num_str)
        if not num then
            return nil, "Некорректное число: " .. num_str
        end
        return num
    end

    -- Парсинг объекта
    local function parse_object()
        pos = pos + 1 -- пропустить '{'
        local obj = {}
        skip_ws()
        if pos <= len and str:sub(pos, pos) == '}' then
            pos = pos + 1
            return obj
        end
        while pos <= len do
            skip_ws()
            local key, err = parse_string()
            if not key then return nil, err end
            skip_ws()
            if pos > len or str:sub(pos, pos) ~= ':' then
                return nil, "Ожидается ':'"
            end
            pos = pos + 1
            local val, err2 = parse_value()
            if not val and err2 then return nil, err2 end
            obj[key] = val
            skip_ws()
            if pos <= len and str:sub(pos, pos) == '}' then
                pos = pos + 1
                return obj
            end
            if pos > len or str:sub(pos, pos) ~= ',' then
                return nil, "Ожидается ',' или '}'"
            end
            pos = pos + 1
        end
        return nil, "Не закрыт объект"
    end

    -- Парсинг массива
    local function parse_array()
        pos = pos + 1 -- пропустить '['
        local arr = {}
        skip_ws()
        if pos <= len and str:sub(pos, pos) == ']' then
            pos = pos + 1
            return arr
        end
        while pos <= len do
            local val, err = parse_value()
            if not val and err then return nil, err end
            table.insert(arr, val)
            skip_ws()
            if pos <= len and str:sub(pos, pos) == ']' then
                pos = pos + 1
                return arr
            end
            if pos > len or str:sub(pos, pos) ~= ',' then
                return nil, "Ожидается ',' или ']'"
            end
            pos = pos + 1
        end
        return nil, "Не закрыт массив"
    end

    local result, err = parse_value()
    if err then
        return nil, err
    end
    return result
end

-- ===========================================================================
-- УТИЛИТЫ: BASE64 (для WebSocket handshake)
-- ===========================================================================
local b64chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

local function base64_encode(data)
    return ((data:gsub('.', function(x)
        local r, b = '', x:byte()
        for i = 8, 1, -1 do
            r = r .. (b % 2^i - b % 2^(i-1) > 0 and '1' or '0')
        end
        return r
    end) .. '0000'):gsub('%d%d%d?%d?%d?%d?', function(x)
        if (#x < 6) then return '' end
        local c = 0
        for i = 1, 6 do
            c = c + (x:sub(i, i) == '1' and 2^(6-i) or 0)
        end
        return b64chars:sub(c+1, c+1)
    end) .. ({ '', '==', '=' })[#data % 3 + 1])
end

-- ===========================================================================
-- WEBSOCKET КЛИЕНТ (минимальная реализация через LuaSocket)
-- ===========================================================================
-- Протокол WebSocket (RFC 6455) — упрощённая реализация клиента.
-- Использует socket.core (LuaSocket), доступный в MoonLoader.

local WS = {} -- модуль WebSocket

local OPCODE_CONTINUATION = 0x0
local OPCODE_TEXT         = 0x1
local OPCODE_BINARY       = 0x2
local OPCODE_CLOSE        = 0x8
local OPCODE_PING         = 0x9
local OPCODE_PONG         = 0xA

--- Сгенерировать ключ для WebSocket handshake (Sec-WebSocket-Key)
local function ws_generate_key()
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local key = {}
    for i = 1, 16 do
        local idx = math.random(1, #chars)
        table.insert(key, chars:sub(idx, idx))
    end
    return table.concat(key) .. '=='
end

--- Попытка установить WebSocket соединение
-- @return true в случае успеха, nil и строка ошибки в случае неудачи
function WS.connect(host, port, timeout_ms)
    local socket = require 'socket'
    local tcp = socket.tcp()
    tcp:settimeout(timeout_ms or CONFIG.connect_timeout)

    debug_log("Попытка подключения к WebSocket", string.format("%s:%d", host, port))

    local ok, err = tcp:connect(host, port)
    if not ok then
        tcp:close()
        return nil, string.format("Ошибка подключения: %s", err or "неизвестно")
    end

    -- Формируем HTTP Upgrade-запрос
    local ws_key = ws_generate_key()
    local request = string.format(
        "GET / HTTP/1.1\r\n" ..
        "Host: %s:%d\r\n" ..
        "Upgrade: websocket\r\n" ..
        "Connection: Upgrade\r\n" ..
        "Sec-WebSocket-Key: %s\r\n" ..
        "Sec-WebSocket-Version: 13\r\n" ..
        "User-Agent: MoonAgent/%s\r\n" ..
        "\r\n",
        host, port, ws_key, script_version
    )

    local sent, send_err = tcp:send(request)
    if not sent then
        tcp:close()
        return nil, string.format("Ошибка отправки handshake: %s", send_err or "неизвестно")
    end

    -- Читаем ответ сервера
    local response = ""
    local deadline = os.clock() + (timeout_ms or CONFIG.connect_timeout) / 1000
    while os.clock() < deadline do
        tcp:settimeout(0.1)
        local chunk, recv_err, partial = tcp:receive('*l')
        if chunk then
            response = response .. chunk .. "\r\n"
            -- Проверяем конец HTTP-заголовков (пустая строка)
            if chunk == "" then
                break
            end
        elseif partial then
            response = response .. partial
        end
        -- Если получили достаточно данных, выходим
        if response:find('\r\n\r\n') then
            break
        end
    end

    -- Проверяем статусный код ответа
    local status_line = response:match('(HTTP/%d%.%d%s+%d+)')
    if not status_line or not status_line:find('101') then
        local status = status_line or "нет ответа"
        tcp:close()
        return nil, string.format("WebSocket handshake отклонён: %s", status)
    end

    debug_log("WebSocket соединение установлено")

    -- Возвращаем объект WebSocket
    return {
        socket  = tcp,
        host    = host,
        port    = port,
    }
end

--- Отправить текстовое сообщение через WebSocket
-- @param ws - объект WebSocket (таблица с полем socket)
-- @param data - строка для отправки
-- @return true или nil, error
function WS.send_text(ws, data)
    if not ws or not ws.socket then
        return nil, "Нет соединения"
    end

    local payload = data
    local opcode = OPCODE_TEXT

    -- Формируем фрейм WebSocket
    -- Байт 1: FIN + opcode
    local byte1 = 0x80 + opcode -- FIN=1
    -- Байт 2: MASK + длину (клиент всегда маскирует)
    local len = #payload
    local frame = {}

    if len <= 125 then
        local byte2 = 0x80 + len -- MASK=1
        table.insert(frame, string.char(byte1, byte2))
    elseif len <= 65535 then
        local byte2 = 0x80 + 126 -- MASK=1
        table.insert(frame, string.char(byte1, byte2))
        table.insert(frame, string.char(math.floor(len / 256), len % 256))
    else
        local byte2 = 0x80 + 127 -- MASK=1
        table.insert(frame, string.char(byte1, byte2))
        -- 8 байт длины (big-endian)
        for i = 7, 0, -1 do
            table.insert(frame, string.char(math.floor(len / (256^i)) % 256))
        end
    end

    -- Генерируем маску (4 случайных байта)
    local mask = {}
    for i = 1, 4 do
        table.insert(mask, math.random(0, 255))
    end
    table.insert(frame, string.char(unpack(mask)))

    -- Применяем маску к payload и добавляем в фрейм
    for i = 1, len do
        local masked = string.byte(payload, i) ~ mask[((i - 1) % 4) + 1]
        table.insert(frame, string.char(masked))
    end

    local full_frame = table.concat(frame)
    local ok, err = ws.socket:send(full_frame)
    if not ok then
        return nil, string.format("Ошибка отправки: %s", err or "неизвестно")
    end

    debug_log("Отправлено WebSocket сообщение", string.sub(data, 1, 120))
    return true
end

--- Отправить Pong фрейм
function WS.send_pong(ws, payload)
    if not ws or not ws.socket then return end
    local byte1 = 0x80 + OPCODE_PONG -- FIN + PONG
    local len = payload and #payload or 0
    local byte2 = 0x80 + len -- MASK=1
    local frame = string.char(byte1, byte2)

    local mask = {}
    for i = 1, 4 do mask[i] = math.random(0, 255) end
    frame = frame .. string.char(unpack(mask))

    if payload and len > 0 then
        local masked = {}
        for i = 1, len do
            masked[i] = string.char(string.byte(payload, i) ~ mask[((i-1)%4)+1])
        end
        frame = frame .. table.concat(masked)
    end

    ws.socket:send(frame)
end

--- Отправить Close фрейм
function WS.send_close(ws, code, reason)
    if not ws or not ws.socket then return end
    local payload = ""
    if code then
        payload = string.char(math.floor(code / 256), code % 256)
        if reason then
            payload = payload .. reason
        end
    end

    local byte1 = 0x80 + OPCODE_CLOSE -- FIN + CLOSE
    local len = #payload
    local byte2 = 0x80 + len -- MASK=1
    local frame = string.char(byte1, byte2)

    local mask = {}
    for i = 1, 4 do mask[i] = math.random(0, 255) end
    frame = frame .. string.char(unpack(mask))

    if len > 0 then
        local masked = {}
        for i = 1, len do
            masked[i] = string.char(string.byte(payload, i) ~ mask[((i-1)%4)+1])
        end
        frame = frame .. table.concat(masked)
    end

    pcall(function() ws.socket:send(frame) end)
end

--- Принять одно сообщение (или nil если ничего)
-- Возвращает: данные (строка), тип ("text"/"binary"/"close"/"ping"/nil)
-- Неблокирующий вызов.
function WS.receive(ws)
    if not ws or not ws.socket then
        return nil
    end

    ws.socket:settimeout(0) -- неблокирующий режим

    -- Читаем первые 2 байта (заголовок фрейма)
    local header, err, partial = ws.socket:receive(2)
    if not header then
        if partial and #partial >= 2 then
            header = partial
        else
            return nil -- Нет данных
        end
    end

    local byte1 = string.byte(header, 1)
    local byte2 = string.byte(header, 2)

    local opcode = byte1 & 0x0F
    local fin = (byte1 & 0x80) ~= 0
    local masked = (byte2 & 0x80) ~= 0
    local payload_len = byte2 & 0x7F

    -- Определяем полную длину payload
    if payload_len == 126 then
        local ext, _ = ws.socket:receive(2)
        if not ext or #ext < 2 then return nil end
        payload_len = string.byte(ext, 1) * 256 + string.byte(ext, 2)
    elseif payload_len == 127 then
        local ext, _ = ws.socket:receive(8)
        if not ext or #ext < 8 then return nil end
        payload_len = 0
        for i = 1, 8 do
            payload_len = payload_len * 256 + string.byte(ext, i)
        end
    end

    -- Маска (если есть)
    local mask_bytes = nil
    if masked then
        mask_bytes = ws.socket:receive(4)
        if not mask_bytes or #mask_bytes < 4 then return nil end
    end

    -- Читаем payload
    local payload = ""
    if payload_len > 0 then
        payload, _ = ws.socket:receive(payload_len)
        if not payload then return nil end
    end

    -- Дешифруем маску
    if masked and mask_bytes and #payload > 0 then
        local decoded = {}
        for i = 1, #payload do
            local b = string.byte(payload, i)
            local m = string.byte(mask_bytes, ((i-1) % 4) + 1)
            decoded[i] = string.char(b ~ m)
        end
        payload = table.concat(decoded)
    end

    -- Обрабатываем opcode
    if opcode == OPCODE_TEXT or opcode == OPCODE_CONTINUATION then
        return payload, "text"
    elseif opcode == OPCODE_BINARY then
        return payload, "binary"
    elseif opcode == OPCODE_PING then
        debug_log("Получен WebSocket PING")
        WS.send_pong(ws, payload)
        return nil, "ping"
    elseif opcode == OPCODE_PONG then
        debug_log("Получен WebSocket PONG")
        return nil, "pong"
    elseif opcode == OPCODE_CLOSE then
        debug_log("Получен WebSocket CLOSE", payload)
        return nil, "close"
    end

    return nil
end

--- Закрыть WebSocket соединение
function WS.close(ws)
    if ws and ws.socket then
        WS.send_close(ws, 1000, "normal closure")
        pcall(function() ws.socket:close() end)
        ws.socket = nil
    end
end

-- ===========================================================================
-- ПАРСЕР ЧАТА SAMP
-- ===========================================================================
-- Определяет тип чата по префиксу сообщения, извлекает никнейм и текст.

--- Таблица префиксов чатов: паттерн → имя типа чата
local CHAT_PREFIXES = {
    { pattern = "^%[Gov%]",            chatType = "Government" },
    { pattern = "^%[Government%]",     chatType = "Government" },
    { pattern = "^%[Faction%]",        chatType = "Faction" },
    { pattern = "^%[Fam%]",            chatType = "Faction" },
    { pattern = "^%[Family%]",         chatType = "Family" },
    { pattern = "^%[Global%]",         chatType = "Global" },
    { pattern = "^%[OOC%]",            chatType = "Global" },
    { pattern = "^%[NonRP%]",          chatType = "NonRP" },
    { pattern = "^%[VR%]",             chatType = "VR" },
    { pattern = "^%[SMS%]",            chatType = "SMS" },
    { pattern = "^%[Radio%]",          chatType = "Radio" },
    { pattern = "^%[Admin%]",          chatType = "Admin" },
    { pattern = "^%[A%]%s",            chatType = "Admin" },
}

--- Разобрать сообщение чата
-- @param text - полный текст сообщения из SAMP
-- @return chatType (или nil если тип не определён), nickname, message
local function parse_chat_message(text)
    if type(text) ~= "string" or #text == 0 then
        return nil, nil, nil
    end

    local chatType = nil
    local rest = text

    -- Ищем совпадение по префиксам
    for _, entry in ipairs(CHAT_PREFIXES) do
        local match = text:match(entry.pattern)
        if match then
            chatType = entry.chatType
            -- Убираем префикс и пробел после него
            rest = text:sub(#match + 1)
            -- Убираем ведущий пробел
            rest = rest:match("^%s*(.-)$") or rest
            break
        end
    end

    if not chatType then
        -- Сообщение без распознанного префикса — пропускаем
        return nil, nil, nil
    end

    -- Извлекаем никнейм и текст сообщения
    -- Формат: "Nickname: текст сообщения" или "Ник: текст"
    local nickname, message = rest:match("^([^:]+):%s*(.-)$")
    if nickname and message then
        -- Очищаем никнейм от пробелов
        nickname = nickname:match("^%s*(.-)%s*$") or nickname
        return chatType, nickname, message
    end

    -- Альтернативный формат: без двоеточия (например, системные сообщения в чате)
    -- Возвращаем весь текст как сообщение без никнейма
    return chatType, nil, rest
end

-- ===========================================================================
-- ДВИЖОК ТРИГГЕРОВ
-- ===========================================================================
-- Проверяет сообщение на совпадение с загруженными триггерами.
-- Поддерживает типы: contains, equals, startsWith, endsWith, regex.
-- Учитывает кулдауны и приоритеты.

--- Проверить совпадение триггера с текстом сообщения
-- @param triggerText - текст триггера
-- @param messageText - текст сообщения
-- @param matchType - тип совпадения (contains, equals, startsWith, endsWith, regex)
-- @param caseSensitive - учитывать регистр
-- @param wholeWord - только целые слова
-- @return boolean
local function match_trigger(triggerText, messageText, matchType, caseSensitive, wholeWord)
    if not triggerText or not messageText then
        return false
    end

    local text = messageText
    local pattern = triggerText

    if not caseSensitive then
        text = text:lower()
        pattern = pattern:lower()
    end

    if wholeWord then
        -- Ограничиваем pattern чтобы он совпадал только с целыми словами
        pattern = "%f[%a]" .. pattern:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1") .. "%f[^%a]"
        -- %f — frontier pattern в Lua 5.1+
        local ok, result = pcall(function()
            return text:find(pattern) ~= nil
        end)
        return ok and result
    end

    if matchType == "equals" then
        return text == pattern
    elseif matchType == "startsWith" then
        return text:sub(1, #pattern) == pattern
    elseif matchType == "endsWith" then
        return text:sub(-#pattern) == pattern
    elseif matchType == "regex" then
        -- Для regex — используем исходный паттерн (без lower())
        local search_text = caseSensitive and messageText or messageText:lower()
        local search_pattern = caseSensitive and triggerText or triggerText:lower()
        local ok, result = pcall(function()
            return search_text:find(search_pattern) ~= nil
        end)
        return ok and result
    else
        -- contains (по умолчанию)
        return text:find(pattern, 1, true) ~= nil
    end
end

--- Обработать сообщение чата: проверить все триггеры и вернуть сработавшие
-- @param chatType - тип чата
-- @param nickname - никнейм отправителя
-- @param message - текст сообщения
-- @return список сработавших триггеров { {triggerId, triggerText, profileName, groupName, priority} }
local function check_triggers(chatType, nickname, message)
    local now = os.time()
    local matched = {}

    -- Проверяем, включён ли данный тип чата в фильтрах
    if state.chat_filters[chatType] == false then
        debug_log("Тип чата отфильтрован", chatType)
        return matched
    end

    -- Сортируем триггеры по приоритету (сначала с высоким приоритетом)
    local sorted_triggers = {}
    for _, trigger in ipairs(state.triggers) do
        if trigger.enabled then
            table.insert(sorted_triggers, trigger)
        end
    end
    table.sort(sorted_triggers, function(a, b)
        return (a.priority or 0) > (b.priority or 0)
    end)

    for _, trigger in ipairs(sorted_triggers) do
        -- Проверяем кулдаун
        local last_fire = state.trigger_cooldowns[trigger.id]
        if last_fire then
            local elapsed = now - last_fire
            if elapsed < (trigger.cooldown or 0) then
                debug_log("Триггер в кулдауне", string.format("%s (осталось %ds)", trigger.name, (trigger.cooldown or 0) - elapsed))
                goto continue
            end
        end

        -- Проверяем совпадение
        local hit = match_trigger(
            trigger.triggerText,
            message,
            trigger.matchType or "contains",
            trigger.caseSensitive,
            trigger.wholeWord
        )

        if hit then
            debug_log("Триггер сработал!", string.format("%s → '%s'", trigger.name, trigger.triggerText))

            -- Записываем время срабатывания
            state.trigger_cooldowns[trigger.id] = now

            table.insert(matched, {
                triggerId   = trigger.id,
                triggerText = trigger.triggerText,
                profileName = trigger.profileName or "",
                groupName   = trigger.groupName or "",
                priority    = trigger.priority or 0,
            })
        end

        ::continue::
    end

    return matched
end

-- ===========================================================================
-- ОЧЕРЕДЬ СОБЫТИЙ
-- ===========================================================================
-- Буферизирует события при отсутствии соединения.
-- Отправляет пакетом при реконнекте.

--- Добавить событие в очередь
local function queue_event(event_data)
    table.insert(state.event_queue, event_data)
    -- Удаляем самые старые события если превышен лимит
    while #state.event_queue > CONFIG.max_queue_size do
        table.remove(state.event_queue, 1)
        warn_log("Очередь событий переполнена, самое старое событие удалено")
    end
    debug_log("Событие добавлено в очередь", string.format("в очереди: %d", #state.event_queue))
end

--- Отправить все события из очереди
local function flush_event_queue()
    if #state.event_queue == 0 then return end

    info_log("Отправка накопленных событий", string.format("в очереди: %d", #state.event_queue))

    -- Отправляем каждое событие отдельно
    local sent_count = 0
    local failed_count = 0
    local remaining = {}

    for _, event in ipairs(state.event_queue) do
        local ok, err = WS.send_text(state.socket, Json.encode(event))
        if ok then
            sent_count = sent_count + 1
        else
            table.insert(remaining, event)
            failed_count = failed_count + 1
        end
    end

    state.event_queue = remaining

    if failed_count > 0 then
        warn_log("Не все события отправлены", string.format("успешно: %d, ошибок: %d", sent_count, failed_count))
    else
        info_log("Все накопленные события отправлены", string.format("всего: %d", sent_count))
    end
end

-- ===========================================================================
-- ОТПРАВКА СОБЫТИЙ В MOON CORE
-- ===========================================================================

--- Отправить JSON-событие через WebSocket (или в очередь)
local function send_event(event_data)
    event_data.time = event_data.time or os.date("%H:%M:%S")

    local json_str = Json.encode(event_data)
    add_log("info", "Отправка события", json_str)

    if state.connected and state.socket then
        local ok, err = WS.send_text(state.socket, json_str)
        if ok then
            return true
        else
            warn_log("Не удалось отправить событие, добавляю в очередь", err)
            queue_event(event_data)
            -- Соединение, скорее всего, разорвано
            handle_disconnect("Ошибка отправки: " .. tostring(err))
            return false
        end
    else
        queue_event(event_data)
        return false
    end
end

-- ===========================================================================
-- ХАРТБИТ
-- ===========================================================================

--- Получить текущий FPS
local function calculate_fps()
    local now = os.clock()
    state.fps_frame_count = state.fps_frame_count + 1

    -- Пересчитываем FPS каждую секунду
    if now - state.fps_last_calc >= 1.0 then
        state.fps = math.floor(state.fps_frame_count / (now - state.fps_last_calc))
        state.fps_frame_count = 0
        state.fps_last_calc = now
    end

    return state.fps
end

--- Отправить хартбит
local function send_heartbeat()
    local fps = calculate_fps()

    -- Получаем пинг из SAMP
    local ping = 0
    pcall(function()
        ping = sampGetPlayerPing(sampGetPlayerId()) or 0
    end)

    -- Получаем никнейм игрока
    local nickname = "Unknown"
    pcall(function()
        nickname = sampGetPlayerNickname(sampGetPlayerId()) or "Unknown"
    end)

    -- Получаем имя сервера
    local server_name = state.server_name
    pcall(function()
        server_name = sampGetServerName() or state.server_name
        if server_name and #server_name > 0 then
            state.server_name = server_name
        end
    end)

    local heartbeat = {
        event    = "Heartbeat",
        fps      = fps,
        ping     = ping,
        nickname = nickname,
        server   = server_name,
    }

    state.player_nickname = nickname

    if CONFIG.debug_mode then
        debug_log("Хартбит", string.format("fps=%d ping=%d nick=%s", fps, ping, nickname))
    end

    send_event(heartbeat)
end

-- ===========================================================================
-- ОБРАБОТКА ВХОДЯЩИХ СООБЩЕНИЙ ОТ MOON CORE
-- ===========================================================================

--- Обработать входящее сообщение от Moon Core
local function handle_incoming_message(data)
    if type(data) ~= "string" or #data == 0 then
        return
    end

    local ok, msg = pcall(Json.decode, data)
    if not ok or type(msg) ~= "table" then
        warn_log("Некорректный JSON от Moon Core", string.sub(data, 1, 200))
        return
    end

    local event_type = msg.event

    debug_log("Получено событие от Moon Core", event_type or "без типа")

    if event_type == "ReloadConfiguration" then
        -- Перезагрузка конфигурации
        handle_config_reload(msg)

    elseif event_type == "Reconnect" then
        -- Команда на реконнект в игру
        handle_reconnect_command(msg)

    elseif event_type == "HandshakeResponse" or event_type == "Config" then
        -- Ответ на хендшейк / начальная конфигурация
        handle_config_reload(msg)

    else
        debug_log("Неизвестное событие от Moon Core", tostring(event_type))
    end
end

--- Обработать перезагрузку конфигурации
local function handle_config_reload(msg)
    info_log("Перезагрузка конфигурации от Moon Core")

    -- Загружаем триггеры
    if msg.triggers and type(msg.triggers) == "table" then
        state.triggers = msg.triggers
        -- Сбрасываем кулдауны при перезагрузке конфигурации
        state.trigger_cooldowns = {}
        info_log("Загружено триггеров", tostring(#state.triggers))
    end

    -- Загружаем фильтры чатов
    if msg.chatFilters and type(msg.chatFilters) == "table" then
        state.chat_filters = {}
        if type(msg.chatFilters) == "table" then
            for _, filter in ipairs(msg.chatFilters) do
                if type(filter) == "table" then
                    state.chat_filters[filter.chatType] = (filter.enabled ~= false)
                elseif type(filter) == "string" then
                    -- Простой формат: массив строк (включённые типы чатов)
                    state.chat_filters[filter] = true
                end
            end
        end
        info_log("Загружено фильтров чатов", tostring(#msg.chatFilters))
    end

    state.handshake_done = true
    info_log("Конфигурация успешно перезагружена")
end

--- Обработать команду на реконнект в игру
local function handle_reconnect_command(msg)
    local delay = msg.delay or 5
    info_log("Получена команда реконнекта", string.format("задержка: %ds", delay))

    -- Отправляем подтверждение
    send_event({
        event   = "ReconnectStarted",
        message = string.format("Реконнект через %d секунд", delay),
    })

    -- Выполняем реконнект с задержкой через lua_thread
    lua_thread.create(function()
        wait(delay * 1000)
        info_log("Выполняем реконнект к серверу...")

        local success, err = pcall(function()
            -- SAMP реконнект: сначала отключаемся, потом подключаемся
            sampDisconnect()
            wait(1000)
            sampConnect()
        end)

        if success then
            send_event({
                event   = "ReconnectCompleted",
                message = "Реконнект выполнен успешно",
            })
            info_log("Реконнект выполнен успешно")
        else
            send_event({
                event    = "Error",
                category = "Reconnect",
                message  = "Ошибка при реконнекте",
                details  = tostring(err),
            })
            error_log("Ошибка реконнекта", tostring(err))
        end
    end)
end

-- ===========================================================================
-- УПРАВЛЕНИЕ СОЕДИНЕНИЕМ
-- ===========================================================================

--- Установить соединение с Moon Core
local function connect_to_core()
    if state.connecting or state.connected then
        return
    end

    state.connecting = true
    info_log("Подключение к Moon Core...", string.format("ws://%s:%d", CONFIG.websocket_host, CONFIG.websocket_port))

    local ws, err = WS.connect(CONFIG.websocket_host, CONFIG.websocket_port, CONFIG.connect_timeout)
    if not ws then
        state.connecting = false
        handle_disconnect(tostring(err))
        return
    end

    state.socket = ws
    state.connected = true
    state.connecting = false
    state.reconnect_delay = CONFIG.reconnect_base_delay

    info_log("Соединение с Moon Core установлено!")

    -- Отправляем хендшейк
    local handshake = {
        event = "Handshake",
        version = script_version or "0.1.0",
        agent = "MoonAgent",
    }
    WS.send_text(ws, Json.encode(handshake))
    debug_log("Хендшейк отправлен")

    -- Добавляем запись в лог
    add_log("info", "WebSocket подключён", string.format("%s:%d", CONFIG.websocket_host, CONFIG.websocket_port))

    -- Отправляем накопленные события
    flush_event_queue()

    -- Обновляем статус в MoonLoader
    pcall(function()
        lua_thread.create(function()
            -- Уведомляем Moon Core о подключении
            send_event({
                event   = "AgentConnected",
                message = "Агент подключён к Moon Core",
            })
        end)
    end)
end

--- Обработать отключение
local function handle_disconnect(reason)
    if state.connected then
        warn_log("Отключение от Moon Core", reason or "неизвестная причина")
        add_log("warning", "WebSocket отключён", reason or "")
    end

    state.connected = false
    state.connecting = false
    state.handshake_done = false

    -- Закрываем сокет
    if state.socket then
        WS.close(state.socket)
        state.socket = nil
    end

    -- Отправляем ошибку (в очередь, т.к. мы отключены)
    if reason then
        queue_event({
            event    = "Error",
            category = "Connection",
            message  = "Отключение от Moon Core",
            details  = reason,
            time     = os.date("%H:%M:%S"),
        })
    end
end

--- Отправить ошибку в Moon Core
local function send_error(category, message, details)
    send_event({
        event    = "Error",
        category = category or "Internal",
        message  = message or "Неизвестная ошибка",
        details  = details or "",
    })
end

-- ===========================================================================
-- ОБРАБОТЧИКИ SAMP СОБЫТИЙ
-- ===========================================================================

--- Обработчик входящих сообщений чата (sampev.onServerMessage)
local function on_server_message(color, text)
    -- Безопасный вызов — никогда не должен крашнуть игру
    local ok, err = pcall(function()
        if not text or type(text) ~= "string" or #text == 0 then
            return
        end

        -- Парсим сообщение
        local chatType, nickname, message = parse_chat_message(text)

        if not chatType then
            -- Сообщение не содержит распознанного префикса — пропускаем
            return
        end

        debug_log("Чат-сообщение", string.format("[%s] %s: %s", chatType, nickname or "система", message or ""))

        -- Проверяем триггеры
        local matched_triggers = check_triggers(chatType, nickname, message)

        -- Отправляем события для сработавших триггеров
        for _, match in ipairs(matched_triggers) do
            send_event({
                event      = "TriggerDetected",
                profile    = match.profileName,
                chat       = chatType,
                nickname   = nickname or "",
                message    = message or "",
                trigger    = match.triggerText,
                triggerId  = match.triggerId,
                time       = os.date("%H:%M:%S"),
            })
        end
    end)

    if not ok then
        error_log("Ошибка в обработчике чата", tostring(err))
        send_error("Parser", "Ошибка парсинга чата", tostring(err))
    end
end

--- Обработчик входящих сообщений чата (sampev.onIncomingChat)
local function on_incoming_chat(color, text, senderId)
    -- Альтернативный хук — обработка через onIncomingChat
    -- Используем onServerMessage как основной, это — резервный
end

-- ===========================================================================
-- КОМАНДЫ ЧАТА (для отладки)
-- ===========================================================================

--- Команда /moon — выводит статус агента
local function cmd_moon(arg)
    print("[MoonAgent] ══════════════════════════════")
    print(string.format("[MoonAgent] Статус: %s", state.connected and "ПОДКЛЮЧЁН" or "ОТКЛЮЧЁН"))
    print(string.format("[MoonAgent] Версия: %s", script_version or "0.1.0"))
    print(string.format("[MoonAgent] Хост: %s:%d", CONFIG.websocket_host, CONFIG.websocket_port))
    print(string.format("[MoonAgent] Триггеров загружено: %d", #state.triggers))
    print(string.format("[MoonAgent] Фильтров чатов: %d", table.maxn(state.chat_filters) or 0))
    print(string.format("[MoonAgent] Очередь событий: %d/%d", #state.event_queue, CONFIG.max_queue_size))
    print(string.format("[MoonAgent] FPS: %d", state.fps))
    print(string.format("[MoonAgent] Буфер логов: %d записей", #state.log_buffer))
    print("[MoonAgent] ══════════════════════════════")
end

--- Команда /moontest — тестовое сообщение в Moon Core
local function cmd_moontest(arg)
    send_event({
        event   = "TestMessage",
        message = "Тестовое сообщение от агента",
        time    = os.date("%H:%M:%S"),
    })
    print("[MoonAgent] Тестовое сообщение отправлено")
end

--- Команда /moondebug — переключить режим отладки
local function cmd_moondebug(arg)
    CONFIG.debug_mode = not CONFIG.debug_mode
    print(string.format("[MoonAgent] Режим отладки: %s", CONFIG.debug_mode and "ВКЛ" or "ВЫКЛ"))
end

--- Команда /moonreconnect — принудительный реконнект к Moon Core
local function cmd_moonreconnect(arg)
    handle_disconnect("Ручной реконнект по команде")
    state.reconnect_delay = 0
    print("[MoonAgent] Принудительный реконнект...")
end

--- Команда /moonlog — показать последние записи из буфера логов
local function cmd_moonlog(arg)
    local count = tonumber(arg) or 10
    print(string.format("[MoonAgent] Последние %d записей лога:", math.min(count, #state.log_buffer)))
    print("[MoonAgent] ──────────────────────────────")
    local start_idx = math.max(1, #state.log_buffer - count + 1)
    for i = start_idx, #state.log_buffer do
        local entry = state.log_buffer[i]
        local line = string.format("[%s] [%s] %s", entry.time, entry.level, entry.message)
        if entry.details and #entry.details > 0 then
            line = line .. string.format(" → %s", entry.details)
        end
        print("[MoonAgent] " .. line)
    end
    print("[MoonAgent] ──────────────────────────────")
end

--- Команда /moonqueue — показать очередь событий
local function cmd_moonqueue(arg)
    print(string.format("[MoonAgent] Очередь событий: %d/%d", #state.event_queue, CONFIG.max_queue_size))
    for i, evt in ipairs(state.event_queue) do
        print(string.format("[MoonAgent]   %d. %s", i, evt.event or "unknown"))
    end
end

-- ===========================================================================
-- ГЛАВНЫЙ ЦИКЛ
-- ===========================================================================

--- Основная функция (запускается MoonLoader)
function main()
    info_log("MoonAgent запущен", string.format("v%s", script_version or "0.1.0"))

    -- Регистрируем обработчики SAMP событий
    sampev.onServerMessage(function(color, text)
        on_server_message(color, text)
    end)

    -- Регистрируем команды чата
    sampRegisterChatCommand('moon', cmd_moon)
    sampRegisterChatCommand('moontest', cmd_moontest)
    sampRegisterChatCommand('moondebug', cmd_moondebug)
    sampRegisterChatCommand('moonreconnect', cmd_moonreconnect)
    sampRegisterChatCommand('moonlog', cmd_moonlog)
    sampRegisterChatCommand('moonqueue', cmd_moonqueue)

    info_log("Команды зарегистрированы", "/moon, /moontest, /moondebug, /moonreconnect, /moonlog, /moonqueue")

    -- Пытаемся получить имя сервера
    pcall(function()
        local name = sampGetServerName()
        if name and #name > 0 then
            state.server_name = name
            info_log("Имя сервера", name)
        end
    end)

    -- Получаем никнейм игрока
    pcall(function()
        local nick = sampGetPlayerNickname(sampGetPlayerId())
        if nick and #nick > 0 then
            state.player_nickname = nick
            info_log("Никнейм игрока", nick)
        end
    end)

    -- ═══════════════════════════════════════════════════
    -- ОСНОВНОЙ ЦИКЛ
    -- ═══════════════════════════════════════════════════
    while state.running do
        wait(0) -- минимальная задержка (1 кадр)

        local now = os.clock()

        -- ── Подключение / реконнект ──
        if not state.connected and not state.connecting then
            if now - state.last_reconnect_try >= (state.reconnect_delay / 1000) then
                state.last_reconnect_try = now
                local ok, err = pcall(connect_to_core)
                if not ok then
                    error_log("Критическая ошибка подключения", tostring(err))
                    send_error("Connection", "Критическая ошибка подключения", tostring(err))
                end
            end
        end

        -- ── Приём сообщений от Moon Core ──
        if state.connected and state.socket then
            local ok, err = pcall(function()
                local data, msg_type = WS.receive(state.socket)
                if data then
                    handle_incoming_message(data)
                elseif msg_type == "close" then
                    handle_disconnect("Сервер закрыл соединение (close frame)")
                elseif msg_type == "ping" then
                    -- Pong уже отправлен внутри WS.receive
                end
            end)
            if not ok then
                local err_str = tostring(err)
                -- Проверяем, не является ли это ошибкой таймаута (нормально)
                if not err_str:find("timeout") and not err_str:find("closed") then
                    error_log("Ошибка приёма данных", err_str)
                end
                handle_disconnect("Ошибка приёма: " .. err_str)
            end
        end

        -- ── Хартбит ──
        if state.connected and state.handshake_done then
            local now_ms = os.clock() * 1000
            if now_ms - state.last_heartbeat >= CONFIG.heartbeat_interval then
                state.last_heartbeat = now_ms
                local ok, err = pcall(send_heartbeat)
                if not ok then
                    error_log("Ошибка хартбита", tostring(err))
                    send_error("Internal", "Ошибка хартбита", tostring(err))
                end
            end
        end

        -- ── FPS-подсчёт ──
        calculate_fps()

    end -- while

    -- ═══════════════════════════════════════════════════
    -- ЗАВЕРШЕНИЕ РАБОТЫ
    -- ═══════════════════════════════════════════════════
    info_log("MoonAgent завершает работу...")

    -- Отправляем событие отключения
    pcall(function()
        send_event({
            event   = "AgentDisconnected",
            message = "Агент остановлен",
        })
    end)

    -- Закрываем WebSocket
    handle_disconnect("Агент остановлен")

    info_log("MoonAgent остановлен")
end

-- ===========================================================================
-- ОБРАБОТЧИК ЗАВЕРШЕНИЯ СКРИПТА
-- ===========================================================================

--- Вызывается при завершении/перезагрузке скрипта
function onScriptTerminate(script, quitGame)
    if script == this_script() then
        info_log("Скрипт завершается", quitGame and "игра закрывается" or "перезагрузка скрипта")

        -- Закрываем соединение
        handle_disconnect("Скрипт завершается")

        -- Если есть накопленные события — логируем
        if #state.event_queue > 0 then
            warn_log("Неподтверждённые события в очереди", tostring(#state.event_queue))
        end
    end
end

-- ===========================================================================
-- ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ SAMP
-- ===========================================================================

--- Вызывается при загрузке/перезагрузке SAMP
function onSAMPInit()
    info_log("SAMP инициализирован, агент готов к работе")

    -- Сбрасываем состояние
    state.handshake_done = false
    state.last_reconnect_try = 0
    state.reconnect_delay = CONFIG.reconnect_base_delay
end

-- ===========================================================================
-- КОНЕЦ ФАЙЛА
-- ===========================================================================