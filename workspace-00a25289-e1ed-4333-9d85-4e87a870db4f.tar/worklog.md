# Moon Control — Worklog

## Task 3: Complete Frontend UI (Desktop Client)

**Date**: 2025-07-08
**Status**: ✅ Completed

### Summary
Built the complete frontend UI for Moon Control as a single-page application in `src/app/page.tsx`. The application is a premium dark-themed control panel with 13 fully functional pages, Zustand state management, React Query data fetching, and Framer Motion animations.

### Changes Made

#### Files Modified
- **`src/app/layout.tsx`** — Updated to use `next-themes` ThemeProvider with dark theme default, replaced Toaster with Sonner toaster, set Russian lang, applied dark background directly
- **`src/app/page.tsx`** — Complete rewrite: ~2430 lines containing the entire SPA

#### Architecture
- **Zustand Store** (`MoonStore`): Manages `activePage`, `sidebarCollapsed`, `refreshKey`
- **React Query**: All 13 pages fetch from API endpoints with loading/error states, auto-refresh where appropriate
- **QueryClientProvider**: Wraps the app at the top level for React Query access

#### Pages Implemented (13 total)
1. **Dashboard** — 6 status cards, CPU/RAM/Uptime info, recent events list, quick actions
2. **Profiles** — Grid of profile cards with CRUD, create/edit dialog, active profile highlight
3. **Chats** — 10 chat types with toggle switches, immediate save via API
4. **Triggers** — Full table with search/filter, create/edit dialog with all fields (name, trigger text, match type, case sensitive, whole word, priority, cooldown, group, description, enabled)
5. **Telegram** — Connection card (bot token, chat ID, owner name), notification toggles (7 types), monitor-only mode, test message
6. **Agent** — Connection status card, 6 info metrics, action buttons, heartbeat bar chart
7. **Automation** — Expandable rules with visual action chain editor (telegram, delay, disconnect, reconnect, log actions), reorder buttons, dry run, create dialog
8. **Scheduler** — Task list with status badges, cancel for pending tasks
9. **Events (Journal)** — Full event log table, level/source filters, detail dialog with JSON data, clear all, auto-refresh 10s
10. **Statistics** — 4 recharts: triggers/day bar chart, events/pie chart, CPU/RAM area chart, reconnects line chart
11. **Settings** — 5 tabs: General, Appearance, Database (with clear/reset), Modules, Developer info
12. **Backup** — Backup list with create/restore/delete actions, empty state
13. **About** — System info, architecture diagram, credits

#### Layout Structure
- **TopBar** (60px): Logo, version badge, active profile indicator, search (Ctrl+P), notifications, settings
- **Sidebar** (280px / 72px collapsed): 13 navigation items with icons, active indicator, smooth collapse animation
- **StatusBar** (32px): Backend/Lua/Telegram/DB status dots, event count, active profile, version
- **Footer**: Sticky to bottom via `mt-auto`

#### Design System
- Dark Premium theme: `#0D1117` background, `#161B22` secondary, `#1E2530` cards
- Glass morphism: `backdrop-blur-sm` + semi-transparent backgrounds
- Accent: Blue `#3B82F6` (per user specification), Emerald for success, Yellow for warning, Red for error
- All text in Russian
- Responsive: Mobile-first with sidebar collapse
- Framer Motion: Page transitions, card hover, sidebar collapse, expand/collapse animations
- Loading skeletons on all data-dependent pages
- Empty states with icons and descriptions

#### Keyboard Shortcuts
- `Ctrl+P`: Focus search
- `Ctrl+B`: Create backup (toast notification)

#### API Endpoints Used
All data fetching uses React Query with graceful fallback to mock data:
- `GET /api/status`, `GET/POST /api/profiles`, `GET/POST /api/triggers`, `GET/POST /api/automation`
- `GET/PUT /api/telegram`, `POST /api/telegram/test`, `GET /api/agent`, `POST /api/agent/reconnect`
- `GET /api/events`, `GET/PUT /api/settings`, `GET/POST /api/scheduler`
- `GET /api/backups`, `GET /api/modules`, `GET /api/system-info`

### Notes
- All API calls gracefully fall back to mock data if the endpoint doesn't exist yet (being created by another agent)
- ESLint passes with zero errors
- Dev server compiles successfully with HTTP 200

---

## Task 3-fix: Split page.tsx into modular components

**Date**: 2025-07-08
**Status**: ✅ Completed

### Summary
The monolithic `src/app/page.tsx` (2430 lines) was causing Next.js dev server to crash when compiling the page route. Split the entire file into 19 modular component files under `src/components/moon/` and rewrote `page.tsx` as a 79-line minimal shell using `React.lazy()` for code splitting.

### Changes Made

#### Files Created (19 new files in `src/components/moon/`)

| File | Purpose | Lines |
|------|---------|-------|
| `types.ts` | Shared TypeScript interfaces (StatusItem, Profile, TriggerItem, ChatType, AutomationRule, etc.) | ~65 |
| `store.ts` | Zustand store (`useMoonStore`) | ~18 |
| `constants.ts` | STATUS_COLORS, LEVEL_COLORS, MATCH_TYPES, CHAT_TYPES, SIDEBAR_ITEMS, mock data, chart data | ~170 |
| `action-icons.ts` | ACTION_ICONS record for automation page | ~18 |
| `helpers.tsx` | Shared UI components: StatusBadge, EmptyState, GlassCard, SectionHeader, PageWrapper | ~70 |
| `Layout.tsx` | TopBar, Sidebar, BottomStatusBar (layout chrome) | ~170 |
| `DashboardPage.tsx` | Dashboard view with status cards, CPU/RAM, events, quick actions | ~140 |
| `ProfilesPage.tsx` | Profile CRUD with dialog | ~130 |
| `ChatsPage.tsx` | Chat filter toggles | ~60 |
| `TriggersPage.tsx` | Trigger table with search, editor dialog | ~190 |
| `TelegramPage.tsx` | Telegram settings, notifications | ~140 |
| `AgentPage.tsx` | Agent status, heartbeat chart | ~140 |
| `AutomationPage.tsx` | Automation rules with expandable action chains | ~180 |
| `SchedulerPage.tsx` | Scheduled tasks list | ~60 |
| `EventsPage.tsx` | Event log with filters and detail dialog | ~140 |
| `StatisticsPage.tsx` | 4 Recharts visualizations | ~120 |
| `SettingsPage.tsx` | Settings with 5 tabs | ~160 |
| `BackupPage.tsx` | Backup management | ~70 |
| `AboutPage.tsx` | System info and architecture | ~70 |

#### Files Modified
- **`src/app/page.tsx`** — Rewritten from 2430 lines to **79 lines**. Now a minimal shell that:
  - Uses `React.lazy()` + `Suspense` to dynamically import all 13 page components
  - Maps active page state to the correct lazy component via `PAGE_MAP`
  - Contains `QueryProvider` (React Query) and `PageContent` router
  - Renders `TopBar`, `Sidebar`, `PageContent`, and `BottomStatusBar`

### Key Design Decisions
- **`React.lazy()`** for code splitting: Each page component is loaded on demand, dramatically reducing the initial compilation bundle
- **Shared helpers** in `helpers.tsx`: `GlassCard`, `PageWrapper`, `StatusBadge`, `EmptyState`, `SectionHeader` used by all pages
- **Centralized constants** in `constants.ts`: Mock data, color maps, sidebar items, chart data
- **`action-icons.ts`** separated to avoid circular/large imports in constants
- All Russian text, styling, and functionality preserved exactly as in the original
- ESLint passes with zero errors

---

## Task 6: MoonLoader Lua Agent Script (MoonAgent.lua)

**Date**: 2025-07-09
**Status**: ✅ Completed

### Summary
Created a complete, single-file MoonLoader Lua agent script (`agent/MoonAgent.lua`) that runs inside the GTA V SAMP MoonLoader mod framework. The agent communicates with Moon Core via a custom WebSocket implementation and provides real-time chat monitoring, trigger detection, and event forwarding. 1594 lines, fully self-contained (no external `require()` for sub-modules).

### File Created

| File | Purpose | Lines |
|------|---------|-------|
| `agent/MoonAgent.lua` | Complete MoonLoader agent with WebSocket, chat parser, trigger engine, heartbeat, event queue | 1594 |

### Features Implemented

#### 1. WebSocket Client (Inline, LuaSocket-based)
- Minimal RFC 6455 WebSocket client using `socket.core` (LuaSocket) available in MoonLoader
- HTTP Upgrade handshake with `Sec-WebSocket-Key` generation
- Client-side frame masking (required by the protocol)
- Text send/receive with proper opcode handling (TEXT, BINARY, PING/PONG, CLOSE)
- Non-blocking receive for use in the main game loop
- Auto-reconnect with exponential backoff: 1s → 2s → 4s → 8s → ... → 60s max
- Configurable timeouts (connect: 5s, receive: non-blocking)

#### 2. JSON Encoder/Decoder (Inline)
- Full inline JSON module (no external dependencies) — 250+ lines
- Encoder: handles nil→null, booleans, numbers, strings with escape sequences, arrays, objects
- Decoder: recursive descent parser supporting objects, arrays, strings (with unicode surrogate pairs), numbers, booleans, null
- Handles whitespace and single-line comments

#### 3. Chat Parser (SAMP)
- Hooks into `sampev.onServerMessage` for real-time chat message interception
- Parses chat type from message prefix using regex patterns
- Supported prefixes: `[Gov]`, `[Government]`, `[Faction]`, `[Fam]`, `[Family]`, `[Global]`, `[OOC]`, `[NonRP]`, `[VR]`, `[SMS]`, `[Radio]`, `[Admin]`, `[A]`
- Extracts nickname and message text from format: `[Prefix] Nickname: message text`
- Returns structured result: `{chatType, nickname, message}`

#### 4. Trigger Engine
- Receives trigger list from Moon Core via `ReloadConfiguration` or handshake response
- Supports all 5 match types: `contains`, `equals`, `startsWith`, `endsWith`, `regex`
- Case insensitive mode (default) and whole-word matching (Lua frontier patterns)
- Per-trigger cooldown system (tracks last fire time, skips within cooldown window)
- Priority-based evaluation (higher priority triggers checked first)
- All trigger matching wrapped in `pcall()` for crash safety

#### 5. Event Queue (Offline Buffering)
- Queues events when WebSocket is disconnected
- Sends batched events on reconnect via `flush_event_queue()`
- Maximum 100 events in buffer; oldest dropped when full (FIFO)
- Separate tracking of sent/failed events during flush

#### 6. Heartbeat
- Sends heartbeat every 5 seconds (configurable) with: `fps`, `ping`, `nickname`, `server`
- FPS calculated using frame time delta (recomputed every 1 second)
- Ping retrieved via `sampGetPlayerPing()`
- Server name retrieved via `sampGetServerName()` (cached)
- Player nickname retrieved via `sampGetPlayerNickname()`

#### 7. Configuration Reload
- Listens for `ReloadConfiguration` event from Moon Core
- Reloads triggers list and chat filters without restarting
- Resets all trigger cooldowns on config reload
- Also accepts `HandshakeResponse` / `Config` events

#### 8. Reconnect Command
- Listens for `Reconnect` event from Moon Core with optional `delay` parameter
- Executes game reconnect: `sampDisconnect()` → wait → `sampConnect()`
- Sends `ReconnectStarted` and `ReconnectCompleted` status events
- Error handling with `pcall()` and error event reporting

#### 9. Error Handling
- Error categories: `Parser`, `Connection`, `Trigger`, `Reconnect`, `MoonLoader`, `Internal`
- Every critical code path wrapped in `pcall()` — never crashes the game
- Errors sent as events to Moon Core: `{"event":"Error","category":"...","message":"...","details":"..."}`
- Separate error handlers for: chat parsing, WebSocket I/O, heartbeat, connection management

#### 10. Local Log Buffer
- In-memory circular buffer of last 100 events
- Each entry: `{time, level, message, details}`
- Levels: `debug`, `info`, `warning`, `error`
- Viewable in-game via `/moonlog [count]` command

### Chat Commands (In-Game Debug)
| Command | Description |
|---------|-------------|
| `/moon` | Show agent status (connected, triggers, queue, FPS) |
| `/moontest` | Send test message to Moon Core |
| `/moondebug` | Toggle debug mode (verbose console output) |
| `/moonreconnect` | Force reconnect to Moon Core |
| `/moonlog [N]` | Show last N log entries (default 10) |
| `/moonqueue` | Show pending event queue contents |

### JSON Protocol
- **Handshake**: `{"event":"Handshake","version":"0.1.0","agent":"MoonAgent"}`
- **TriggerDetected**: `{"event":"TriggerDetected","profile":"...","chat":"...","nickname":"...","message":"...","trigger":"...","triggerId":"...","time":"HH:MM:SS"}`
- **Heartbeat**: `{"event":"Heartbeat","fps":60,"ping":41,"nickname":"Mike_Mouse","server":"Arizona RP"}`
- **Error**: `{"event":"Error","category":"Connection","message":"...","details":"..."}`

### Design Decisions
- **Single file**: No `require()` for sub-modules (MoonLoader loads .lua files directly)
- **Inline JSON**: Full encoder/decoder embedded (no external JSON library dependency)
- **Inline WebSocket**: Minimal RFC 6455 client using LuaSocket (no external WS library)
- **Inline Base64**: Used only for WebSocket key generation
- **All comments in Russian**: Per project requirements
- **Non-blocking I/O**: WebSocket receive uses `settimeout(0)` to avoid blocking the game loop
- **Configurable**: All settings in top-level `CONFIG` table

---

## Task 7: WebSocket Bridge Mini-Service

**Date**: 2025-07-08
**Status**: ✅ Completed

### Summary
Created the WebSocket bridge mini-service that acts as the communication layer between the Lua Agent (MoonLoader) and the Next.js backend (Moon Core). The bridge listens for WebSocket connections from the Lua Agent, routes events to the HTTP API, and provides outbound command capabilities.

### Architecture
```
Lua Agent (MoonLoader) ←→ WebSocket (port 8765) ←→ HTTP API (port 3000)
```

### Files Created

#### `mini-services/ws-bridge/package.json`
- Package `moon-ws-bridge` v0.1.0
- Dependencies: `ws@^8.18.0`
- Dev dependencies: `@types/ws@^8.5.0`, `bun-types@^1.3.4`
- Dev script: `bun --hot index.ts`

#### `mini-services/ws-bridge/tsconfig.json`
- ESNext target with bundler module resolution
- Strict TypeScript enabled

#### `mini-services/ws-bridge/index.ts` (~310 lines)
The main bridge server with two network listeners:

**WebSocket Server (port 8765):**
- Accepts JSON message frames from the Lua Agent
- Maximum 1 agent connection (rejects duplicates with close code 1008)
- Sends a `Welcome` message on connection
- Routes incoming events by `event` field:
  - `Handshake` → Logs connection, fetches config from API (triggers, chat filters), sends `Configuration` response back to agent, creates event log
  - `Heartbeat` → Updates in-memory agent state (fps, ping, nickname, server, lastHeartbeat), POSTs to `/api/agent/heartbeat`
  - `TriggerDetected` → POSTs event to `/api/events`, then POSTs to `/api/automation/check` for rule evaluation
  - `Error` → POSTs error event to `/api/events` with level=error
  - `ReconnectFinished` → POSTs result event to `/api/events`
- Sends `Error` event to agent on disconnection
- Graceful JSON parse error handling (logs warning, doesn't crash)
- Unknown event types logged as warnings

**HTTP Status Endpoint (port 8766) via `Bun.serve()`:**
- `GET /` → Returns agent connection state as JSON:
  ```json
  { "connected": true, "version": "0.1.0", "lastHeartbeat": "...", "fps": 93, "ping": 41, "nickname": "Mike_Mouse", "server": "Arizona RP", "uptime": 3600 }
  ```
- `POST /reconnect` → Sends `{"event":"Reconnect","delay":60}` to agent
- `POST /ping` → Sends `{"event":"Ping"}` to agent
- `POST /reload-configuration` → Sends `{"event":"ReloadConfiguration"}` to agent
- CORS headers on all responses

**Logging:**
- Color-coded console output: green=connect, red=error, yellow=warning, cyan=info, blue=event
- ISO timestamps with event type labels

**Graceful Shutdown:**
- SIGTERM/SIGINT handlers close WebSocket server cleanly
- 5-second forced exit timeout as safety net

### Files Modified (API Endpoints)

#### `src/app/api/events/route.ts` — Added POST handler
- Accepts `{ level, source, event, title, message, jsonData }` body
- Creates `Event` record in database
- Returns 201 with created event, or 400 if `event` field missing

#### `src/app/api/agent/heartbeat/route.ts` — New file
- POST endpoint for the bridge to send heartbeat data
- Updates `ApplicationState` with `luaStatus: "connected"` and `lastPing`
- Uses upsert to create state if not exists

#### `src/app/api/automation/check/route.ts` — New file
- POST endpoint called when triggers are detected
- Accepts `{ triggerId, triggerName, text, chatType, sender }`
- Evaluates all enabled automation rules linked to the trigger ID
- Checks conditions: chat type, nickname, time range, day of week
- Logs matched rules as events and command history entries
- Returns `{ matched, rulesFired, rules }`

### Notes
- Dependencies installed successfully (ws@8.21.0, @types/ws@8.18.1, bun-types@1.3.14)
- ESLint passes with zero errors on the main project
- The bridge server is NOT started (per instructions — started later)
---
Task ID: 8
Agent: Main Coordinator
Task: Add Lua Agent script, WebSocket bridge, and Installation page with hosting recommendations

Work Log:
- Created complete MoonLoader Lua Agent (agent/MoonAgent.lua, 1594 lines)
  - Self-contained with inline JSON encoder/decoder and WebSocket client
  - Chat parser for 12 chat types (Government, Faction, Family, etc.)
  - Trigger engine with 5 match types + cooldown system
  - Event queue for offline buffering (max 100 events)
  - Heartbeat every 5 seconds (FPS, ping, nickname, server)
  - 6 in-game commands: /moon, /moontest, /moondebug, /moonreconnect, /moonlog, /moonqueue
- Created WebSocket bridge mini-service (mini-services/ws-bridge/)
  - Port 8765: WebSocket server for Lua Agent
  - Port 8766: HTTP status endpoint
  - Routes events to Next.js API
  - Color-coded logging
- Created InstallPage.tsx (758 lines) with:
  - System requirements (Computer, Agent, Server)
  - Download links (Node.js, Bun, Git, MoonLoader, SAMPFUNCS)
  - 8-step installation guide (collapsible sections)
  - Project structure diagram
  - Architecture flow diagram
  - 6 hosting options with pricing and features:
    1. Oracle Cloud Free Tier (БЕСПЛАТНО, recommended)
    2. Google Cloud Free Tier (БЕСПЛАТНО)
    3. Render.com (БЕСПЛАТНО, serverless)
    4. Railway.app ($5 кредит/мес)
    5. Аэза (99₽/мес, Russian VPS)
    6. Timeweb Cloud (199₽/мес)
  - VPS deployment guide (5 steps with code blocks)
  - Ports table
  - Troubleshooting section (5 common issues)
- Added "Установка" to sidebar navigation
- Added InstallPage to page.tsx lazy imports
- Verified all pages work in browser

Stage Summary:
- Lua Agent: /home/z/my-project/agent/MoonAgent.lua (1594 lines)
- WS Bridge: /home/z/my-project/mini-services/ws-bridge/
- Install Page: /home/z/my-project/src/components/moon/InstallPage.tsx (758 lines)
- All linting passes
- Browser verification: Dashboard, Profiles, Install page all render correctly

---

## Task ID: qa-3 — Fix bugs and improve Dashboard, helpers, and status bar

**Date**: 2025-07-09
**Status**: ✅ Completed

### Summary
Fixed 3 bugs (uptime formatting, hardcoded status bar, progress bar colors) and implemented 5 visual/styling enhancements (status cards gradient borders, quick actions redesign, events list overhaul, GlassCard enhancement, StatusBadge enhancement).

### Bugs Fixed

#### 1. Uptime Formatting (DashboardPage.tsx)
- **Problem**: Uptime displayed raw seconds (e.g. "64241") instead of human-readable format
- **Fix**: Added `formatUptime()` function that converts seconds to "Xч Yм" or "Yм Zс" format
- Also fixed API field mapping: `statusData?.cpu` → `statusData?.cpuUsage`, `statusData?.ram` → `statusData?.ramUsage`, `statusData?.core?.status` → `statusData?.backendStatus`, etc.
- Events data mapping fixed: `eventsData?.events` → `eventsData?.data` with proper `mapApiEvents()` transformer

#### 2. Dynamic Status Bar (Layout.tsx)
- **Problem**: BottomStatusBar had all values hardcoded (ONLINE, CONNECTED, 1524 events, Government profile)
- **Fix**: Added `useQuery` to fetch from `/api/status` and `/api/events?limit=1`
- Shows real backend/lua/telegram/db statuses from API
- Shows real event count from `pagination.total`
- Shows actual active profile name from `currentProfile`
- Shows loading skeletons while data is loading
- Added `StatusIndicator` helper component for consistent status dot + text rendering

#### 3. CPU/RAM Progress Bar Colors (DashboardPage.tsx)
- **Problem**: CPU bar was always blue, RAM bar was always emerald
- **Fix**: Added `getProgressColor()` function: green (< 50%), yellow (50-80%), red (> 80%)

### Styling Improvements

#### 4. Status Cards Enhancement (DashboardPage.tsx)
- Added `gradientBorder` prop to each card (subtle gradient border via wrapper technique)
- StatusBadge now uses `animate-pulse-dot` (opacity pulse) instead of `animate-ping` (scale pulse)
- Hover scale effect (`scale-[1.02]`) already present, enhanced with `hover:brightness-[1.08]`
- Background icon: large icon rendered at absolute position with `text-white/[0.03]` opacity

#### 5. Quick Actions Section (DashboardPage.tsx)
- Replaced plain Button components with styled card-like buttons in a 3-column grid
- Each button has: colored icon background circle, title, subtitle, hover border/brightness effects
- Color-coded icons: amber (reconnect), purple (telegram), emerald (backup)

#### 6. Events List Enhancement (DashboardPage.tsx)
- Each event row has a colored left border based on level (INFO=blue, WARNING=yellow, ERROR=red, SYSTEM=purple)
- Source badges colored by source: Lua=blue, Telegram=purple, System=gray, Database=green
- Time column uses `font-mono tabular-nums` for monospace display
- Fade gradient at bottom of scrollable list
- Custom scrollbar styling (4px width, subtle colors)

#### 7. GlassCard Enhancement (helpers.tsx)
- Added `gradientBorder` prop: wraps card in a gradient-bg container with 1px padding
- Added `hover` brightness effect: `hover:brightness-[1.08]` on inner card
- Added `glow` prop: applies colored box-shadow (e.g. `glow="#3B82F6"`)
- Restructured: inner div holds card styles, outer motion.div handles animations
- Added `transition-colors duration-200` for smooth hover transitions

#### 8. StatusBadge Enhancement (helpers.tsx)
- Uses custom `animate-pulse-dot` animation (subtle opacity pulse) instead of `animate-ping`
- Better padding: `px-3 py-1` (was `px-2.5 py-0.5`)
- Font: `text-[11px] font-semibold tracking-wide` (was `text-xs font-medium`)
- Already had `rounded-full` pill shape — preserved

### CSS Additions (globals.css)
- `@keyframes pulse-dot` + `.animate-pulse-dot` class
- `.custom-scrollbar` — 4px width scrollbar with subtle colors for dark theme

### Files Modified
- `src/app/globals.css` — Added pulse-dot animation + custom scrollbar styles
- `src/components/moon/helpers.tsx` — Enhanced GlassCard (gradientBorder, glow, hover) and StatusBadge (pulse-dot, padding, font)
- `src/components/moon/DashboardPage.tsx` — Complete rewrite with all bug fixes and enhancements
- `src/components/moon/Layout.tsx` — Dynamic BottomStatusBar with useQuery, added StatusIndicator helper

### Notes
- ESLint passes with zero errors
- All existing functionality preserved
- All Russian text preserved
- Backward compatible: `gradientBorder` and `glow` props are optional (default false/undefined)
- GlassCard restructuring is transparent to all 14 pages that use it

---
Task ID: qa-round-1
Agent: Auto Dev Review (Cron)
Task: QA testing, bug fixes, styling improvements, and new features

Work Log:
- Reviewed worklog.md — assessed project has 14 pages, API routes, Lua agent, WS bridge, all functional
- QA tested all 14 pages via agent-browser — zero console errors on any page
- Identified bugs: uptime shows raw seconds, status bar hardcoded, CPU/RAM bars no color coding
- Identified missing features: no clock, no working search, no Lua download, no profile switcher

### Bugs Fixed (Task qa-3)
- **Uptime formatting**: Added formatUptime() to DashboardPage — "64241" now shows "17ч 50м"
- **Dynamic status bar**: BottomStatusBar now fetches real data from /api/status and /api/events via useQuery, shows loading skeletons
- **CPU/RAM progress bars**: Dynamic color coding — green (<50%), yellow (50-80%), red (>80%)

### Styling Improvements (Task qa-3)
- **Status cards**: Added gradient border effect, background watermark icons at 3% opacity, hover scale+glow
- **Quick actions**: Redesigned as 3-column card grid with colored icon backgrounds, subtitles, hover border glow
- **Events list**: Level-based left border colors, source-colored badges, monospace time, bottom fade gradient
- **GlassCard**: New gradientBorder and glow props (backward compatible)
- **StatusBadge**: Pulsing dot animation, improved padding

### New Features (Task qa-5)
- **Live clock** in TopBar — updates every second, monospace font, HH:MM:SS format
- **Command palette** (Ctrl+P) — full search modal with:
  - All 14 pages as searchable items
  - Quick actions: Create backup, Test Telegram, Reconnect agent, Download Lua script
  - Arrow key navigation, Enter to select, Escape to close
  - Keyboard shortcut hints in footer
- **Profile switcher** in TopBar — click active profile badge to open dropdown, lists all profiles, activate with one click
- **Notification counter** on Bell icon — shows count of recent events as red badge
- **Lua script download** on Agent page:
  - New API endpoint GET /api/agent/script (returns MoonAgent.lua as downloadable file)
  - Prominent download card with file info (version 0.1.0, WebSocket protocol, 12 chat types, ~30KB)
- **Sidebar active indicator** — animated blue left border bar (3px, spring animation) replaces old dot
- **Sidebar logo glow** — added shadow-blue-500/20 to logo icon

### Files Modified
- `src/components/moon/Layout.tsx` — Complete rewrite with all new features (469 lines)
- `src/components/moon/DashboardPage.tsx` — Bug fixes + styling improvements
- `src/components/moon/helpers.tsx` — GlassCard glow/gradientBorder, StatusBadge pulse
- `src/components/moon/AgentPage.tsx` — Added Lua download card section
- `src/app/api/agent/script/route.ts` — New: Lua script download endpoint

### Verification
- bun run lint: ✅ zero errors
- Server compile: ✅ 200 OK, stays alive for multiple requests
- All 14 pages: ✅ no console errors

Stage Summary:
- 3 bugs fixed, 6 styling improvements, 6 new features added
- All code passes lint
- Server stable and responsive
