// Moon Control — WebSocket Bridge
// Bridges the Lua Agent (MoonLoader) ↔ WebSocket (8765) ↔ HTTP API (3000)

import { WebSocketServer, WebSocket } from "ws";

// ============================================================
// Types
// ============================================================

interface AgentState {
  connected: boolean;
  version: string;
  lastHeartbeat: Date | null;
  fps: number | null;
  ping: number | null;
  nickname: string | null;
  server: string | null;
  connectedAt: Date | null;
}

interface IncomingMessage {
  event: string;
  [key: string]: unknown;
}

interface HandshakeMessage extends IncomingMessage {
  event: "Handshake";
  version?: string;
  nickname?: string;
  server?: string;
  fps?: number;
  ping?: number;
}

interface HeartbeatMessage extends IncomingMessage {
  event: "Heartbeat";
  fps?: number;
  ping?: number;
  nickname?: string;
  server?: string;
}

interface TriggerDetectedMessage extends IncomingMessage {
  event: "TriggerDetected";
  triggerId?: string;
  triggerName?: string;
  text?: string;
  chatType?: string;
  sender?: string;
}

interface ErrorMessage extends IncomingMessage {
  event: "Error";
  message?: string;
  code?: string;
  stack?: string;
}

interface ReconnectFinishedMessage extends IncomingMessage {
  event: "ReconnectFinished";
  success?: boolean;
  duration?: number;
  server?: string;
}

// ============================================================
// Constants
// ============================================================

const WS_PORT = 8765;
const HTTP_STATUS_PORT = 8766;
const API_BASE = "http://127.0.0.1:3000/api";

// ANSI color codes
const COLORS = {
  reset: "\x1b[0m",
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  cyan: "\x1b[36m",
  gray: "\x1b[90m",
  dim: "\x1b[2m",
  bold: "\x1b[1m",
};

// ============================================================
// Agent State
// ============================================================

const agentState: AgentState = {
  connected: false,
  version: "",
  lastHeartbeat: null,
  fps: null,
  ping: null,
  nickname: null,
  server: null,
  connectedAt: null,
};

let agentSocket: WebSocket | null = null;

// ============================================================
// Logging
// ============================================================

function log(level: "info" | "success" | "warn" | "error" | "event", message: string) {
  const timestamp = new Date().toISOString();
  const colorMap = {
    info: COLORS.cyan,
    success: COLORS.green,
    warn: COLORS.yellow,
    error: COLORS.red,
    event: COLORS.blue,
  };
  const labelMap = {
    info: "INFO",
    success: "CONN",
    warn: "WARN",
    error: "ERR!",
    event: "EVT ",
  };
  const color = colorMap[level];
  const label = labelMap[level];
  console.log(`${COLORS.dim}${timestamp}${COLORS.reset} ${color}${COLORS.bold}[${label}]${COLORS.reset} ${message}`);
}

// ============================================================
// HTTP helpers — communicate with Next.js API
// ============================================================

async function apiPost(path: string, body: unknown): Promise<boolean> {
  try {
    const url = `${API_BASE}${path}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      log("warn", `API POST ${path} returned ${res.status}: ${text.slice(0, 200)}`);
      return false;
    }
    return true;
  } catch (err) {
    log("warn", `API POST ${path} failed: ${(err as Error).message}`);
    return false;
  }
}

async function apiGet<T = unknown>(path: string): Promise<T | null> {
  try {
    const url = `${API_BASE}${path}`;
    const res = await fetch(url);
    if (!res.ok) {
      log("warn", `API GET ${path} returned ${res.status}`);
      return null;
    }
    return (await res.json()) as T;
  } catch (err) {
    log("warn", `API GET ${path} failed: ${(err as Error).message}`);
    return null;
  }
}

// ============================================================
// Event Handlers
// ============================================================

async function handleHandshake(ws: WebSocket, msg: HandshakeMessage) {
  log("success", `Agent handshake — version: ${msg.version ?? "unknown"}, nickname: ${msg.nickname ?? "N/A"}, server: ${msg.server ?? "N/A"}`);

  agentState.connected = true;
  agentState.version = msg.version ?? "";
  agentState.nickname = msg.nickname ?? null;
  agentState.server = msg.server ?? null;
  agentState.fps = msg.fps ?? null;
  agentState.ping = msg.ping ?? null;
  agentState.lastHeartbeat = new Date();
  agentState.connectedAt = new Date();

  // Log the connection event
  await apiPost("/events", {
    level: "info",
    source: "lua",
    event: "handshake",
    title: "Lua Agent подключён",
    message: `Версия: ${msg.version ?? "неизвестна"}, Никнейм: ${msg.nickname ?? "N/A"}, Сервер: ${msg.server ?? "N/A"}`,
    jsonData: JSON.stringify({ version: msg.version, nickname: msg.nickname, server: msg.server, fps: msg.fps, ping: msg.ping }),
  });

  // Send current configuration to the agent
  const [triggersRes, chatFiltersRes] = await Promise.all([
    apiGet<{ data: unknown[] }>("/triggers"),
    apiGet<unknown[]>("/chat-filters"),
  ]);

  // Send config response
  const configResponse = {
    event: "Configuration",
    triggers: triggersRes?.data ?? [],
    chatFilters: chatFiltersRes ?? [],
    timestamp: new Date().toISOString(),
  };

  ws.send(JSON.stringify(configResponse));
  log("info", `Sent configuration to agent — ${Array.isArray(triggersRes?.data) ? (triggersRes as { data: unknown[] }).data.length : 0} triggers`);
}

async function handleHeartbeat(msg: HeartbeatMessage) {
  agentState.lastHeartbeat = new Date();
  agentState.fps = msg.fps ?? agentState.fps;
  agentState.ping = msg.ping ?? agentState.ping;
  agentState.nickname = msg.nickname ?? agentState.nickname;
  agentState.server = msg.server ?? agentState.server;

  // Update agent status via API
  await apiPost("/agent/heartbeat", {
    fps: msg.fps,
    ping: msg.ping,
    nickname: msg.nickname,
    server: msg.server,
  });
}

async function handleTriggerDetected(msg: TriggerDetectedMessage) {
  log("event", `Trigger detected — ${msg.triggerName ?? "unnamed"}: "${msg.text?.slice(0, 80) ?? ""}" from ${msg.sender ?? "unknown"}`);

  // Create event in database
  await apiPost("/events", {
    level: "info",
    source: "lua",
    event: "trigger_detected",
    title: `Триггер: ${msg.triggerName ?? "Безымянный"}`,
    message: msg.text ?? "",
    jsonData: JSON.stringify({
      triggerId: msg.triggerId,
      triggerName: msg.triggerName,
      chatType: msg.chatType,
      sender: msg.sender,
      text: msg.text,
    }),
  });

  // Check automation rules
  await apiPost("/automation/check", {
    triggerId: msg.triggerId,
    triggerName: msg.triggerName,
    text: msg.text,
    chatType: msg.chatType,
    sender: msg.sender,
  });
}

async function handleError(msg: ErrorMessage) {
  const errMsg = msg.message ?? "Неизвестная ошибка";
  log("error", `Agent error — ${msg.code ?? "no-code"}: ${errMsg}`);

  await apiPost("/events", {
    level: "error",
    source: "lua",
    event: "error",
    title: `Ошибка Lua агента${msg.code ? ` [${msg.code}]` : ""}`,
    message: errMsg,
    jsonData: JSON.stringify({ code: msg.code, stack: msg.stack }),
  });
}

async function handleReconnectFinished(msg: ReconnectFinishedMessage) {
  log(msg.success ? "success" : "warn", `Reconnect ${msg.success ? "succeeded" : "failed"} — server: ${msg.server ?? "N/A"}, duration: ${msg.duration ?? "N/A"}s`);

  await apiPost("/events", {
    level: msg.success ? "info" : "warning",
    source: "lua",
    event: "reconnect_finished",
    title: msg.success ? "Переподключение выполнено" : "Ошибка переподключения",
    message: msg.success
      ? `Подключение к серверу ${msg.server ?? ""} восстановлено за ${msg.duration ?? 0}с`
      : `Не удалось подключиться к серверу ${msg.server ?? ""}`,
    jsonData: JSON.stringify({ success: msg.success, duration: msg.duration, server: msg.server }),
  });
}

// ============================================================
// Outgoing Commands
// ============================================================

/** Send a command to the connected agent */
function sendToAgent(command: Record<string, unknown>): boolean {
  if (!agentSocket || agentSocket.readyState !== WebSocket.OPEN) {
    log("warn", "Cannot send command — agent not connected");
    return false;
  }
  agentSocket.send(JSON.stringify(command));
  log("info", `Sent command to agent: ${command.event}`);
  return true;
}

/** Send a reconnect command to the agent */
export function commandReconnect(delay: number = 60): boolean {
  return sendToAgent({ event: "Reconnect", delay });
}

/** Send a ping command to the agent */
export function commandPing(): boolean {
  return sendToAgent({ event: "Ping" });
}

/** Send a reload configuration command to the agent */
export function commandReloadConfiguration(): boolean {
  return sendToAgent({ event: "ReloadConfiguration" });
}

// ============================================================
// WebSocket Message Router
// ============================================================

function routeMessage(ws: WebSocket, raw: string) {
  let msg: IncomingMessage;
  try {
    msg = JSON.parse(raw) as IncomingMessage;
  } catch {
    log("warn", `Invalid JSON from agent: ${raw.slice(0, 100)}`);
    return;
  }

  if (!msg.event || typeof msg.event !== "string") {
    log("warn", `Message missing 'event' field: ${raw.slice(0, 100)}`);
    return;
  }

  switch (msg.event) {
    case "Handshake":
      handleHandshake(ws, msg as HandshakeMessage);
      break;
    case "Heartbeat":
      handleHeartbeat(msg as HeartbeatMessage);
      break;
    case "TriggerDetected":
      handleTriggerDetected(msg as TriggerDetectedMessage);
      break;
    case "Error":
      handleError(msg as ErrorMessage);
      break;
    case "ReconnectFinished":
      handleReconnectFinished(msg as ReconnectFinishedMessage);
      break;
    default:
      log("warn", `Unknown event type: ${msg.event}`);
  }
}

// ============================================================
// WebSocket Server (port 8765)
// ============================================================

function startWebSocketServer() {
  const wss = new WebSocketServer({ port: WS_PORT });

  wss.on("listening", () => {
    log("success", `WebSocket bridge listening on port ${WS_PORT}`);
  });

  wss.on("connection", (ws, req) => {
    const clientIp = req.socket.remoteAddress ?? "unknown";

    // Only allow 1 agent connection at a time
    if (agentSocket && agentSocket.readyState === WebSocket.OPEN) {
      log("warn", `Rejecting duplicate connection from ${clientIp} — agent already connected`);
      ws.send(JSON.stringify({ event: "Error", message: "Agent already connected. Only one connection allowed." }));
      ws.close(1008, "Agent already connected");
      return;
    }

    log("success", `Agent connected from ${clientIp}`);
    agentSocket = ws;

    ws.on("message", (data) => {
      const raw = data.toString();
      routeMessage(ws, raw);
    });

    ws.on("close", (code, reason) => {
      log("warn", `Agent disconnected — code: ${code}, reason: ${reason.toString() || "none"}`);
      agentState.connected = false;
      agentSocket = null;

      // Notify the API about disconnection
      apiPost("/events", {
        level: "warning",
        source: "lua",
        event: "disconnected",
        title: "Lua Agent отключён",
        message: `Код: ${code}, Причина: ${reason.toString() || "нет"}`,
      });
    });

    ws.on("error", (err) => {
      log("error", `WebSocket error: ${err.message}`);
    });

    // Send a welcome message
    ws.send(JSON.stringify({
      event: "Welcome",
      serverVersion: "0.1.0",
      timestamp: new Date().toISOString(),
    }));
  });

  wss.on("error", (err) => {
    log("error", `WebSocket server error: ${err.message}`);
  });

  return wss;
}

// ============================================================
// HTTP Status Endpoint (port 8766)
// ============================================================

function startHttpStatusServer() {
  const server = Bun.serve({
    port: HTTP_STATUS_PORT,
    fetch(req) {
      const url = new URL(req.url);

      // CORS headers
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      };

      // Handle CORS preflight
      if (req.method === "OPTIONS") {
        return new Response(null, { status: 204, headers });
      }

      // GET / — agent state
      if (url.pathname === "/" && req.method === "GET") {
        const uptime = agentState.connectedAt
          ? Math.floor((Date.now() - agentState.connectedAt.getTime()) / 1000)
          : 0;

        const state = {
          connected: agentState.connected,
          version: agentState.version,
          lastHeartbeat: agentState.lastHeartbeat?.toISOString() ?? null,
          fps: agentState.fps,
          ping: agentState.ping,
          nickname: agentState.nickname,
          server: agentState.server,
          uptime,
        };

        return new Response(JSON.stringify(state, null, 2), { headers });
      }

      // POST /reconnect — send reconnect command to agent
      if (url.pathname === "/reconnect" && req.method === "POST") {
        const success = commandReconnect(60);
        return new Response(JSON.stringify({ success }), { headers });
      }

      // POST /ping — send ping command to agent
      if (url.pathname === "/ping" && req.method === "POST") {
        const success = commandPing();
        return new Response(JSON.stringify({ success }), { headers });
      }

      // POST /reload-configuration — send reload config command to agent
      if (url.pathname === "/reload-configuration" && req.method === "POST") {
        const success = commandReloadConfiguration();
        return new Response(JSON.stringify({ success }), { headers });
      }

      return new Response(JSON.stringify({ error: "Not found" }), {
        status: 404,
        headers,
      });
    },
  });

  log("success", `HTTP status endpoint listening on port ${HTTP_STATUS_PORT}`);
  return server;
}

// ============================================================
// Graceful Shutdown
// ============================================================

function setupGracefulShutdown(wss: WebSocketServer) {
  const shutdown = (signal: string) => {
    log("info", `Received ${signal}, shutting down...`);
    wss.close(() => {
      log("info", "WebSocket server closed");
      process.exit(0);
    });

    // Force exit after 5 seconds
    setTimeout(() => {
      log("warn", "Forced shutdown after timeout");
      process.exit(1);
    }, 5000);
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

// ============================================================
// Main
// ============================================================

log("info", `${COLORS.bold}Moon Control — WebSocket Bridge${COLORS.reset}`);
log("info", `API target: ${API_BASE}`);

const wss = startWebSocketServer();
startHttpStatusServer();
setupGracefulShutdown(wss);