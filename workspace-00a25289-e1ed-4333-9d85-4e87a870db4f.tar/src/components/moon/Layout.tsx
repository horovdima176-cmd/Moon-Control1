'use client';

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Moon, ChevronLeft, ChevronRight, Search, Bell, Settings, Clock, Check, Download, Zap, HardDrive, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useMoonStore } from './store';
import { SIDEBAR_ITEMS } from './constants';
import type { LucideIcon } from 'lucide-react';

// ─── LIVE CLOCK ──────────────────────────────────────────────────────────

function LiveClock() {
  const [time, setTime] = useState('');
  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);
  return <span className="font-mono text-[11px] text-gray-500 tabular-nums">{time}</span>;
}

// ─── COMMAND PALETTE ──────────────────────────────────────────────────────

interface SearchItem {
  id: string; label: string; icon: LucideIcon; type: 'page' | 'action'; action?: () => void;
}

function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState('');
  const [localIndex, setLocalIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const { setActivePage } = useMoonStore();
  const queryClient = useQueryClient();

  const items = useMemo<SearchItem[]>(() => {
    const pages: SearchItem[] = SIDEBAR_ITEMS.map(item => ({
      id: item.id, label: item.label, icon: item.icon, type: 'page',
      action: () => { setActivePage(item.id); onClose(); },
    }));
    const actions: SearchItem[] = [
      { id: 'backup', label: 'Создать бэкап', icon: HardDrive, type: 'action', action: () => {
        fetch('/api/backups', { method: 'POST' }).then(() => { toast.success('Бэкап создан'); queryClient.invalidateQueries({ queryKey: ['backups'] }); }).catch(() => toast.error('Ошибка создания бэкапа'));
        onClose();
      }},
      { id: 'test-tg', label: 'Тест Telegram', icon: Zap, type: 'action', action: () => {
        fetch('/api/telegram/test', { method: 'POST' }).then(r => r.json()).then(d => toast.success(d.message || 'Тест отправлен')).catch(() => toast.error('Ошибка'));
        onClose();
      }},
      { id: 'reconnect', label: 'Переподключить агент', icon: RefreshCw, type: 'action', action: () => {
        fetch('/api/agent/reconnect', { method: 'POST' }).then(() => { toast.success('Реконнект отправлен'); queryClient.invalidateQueries({ queryKey: ['agent'] }); }).catch(() => toast.error('Ошибка реконнекта'));
        onClose();
      }},
      { id: 'download-lua', label: 'Скачать Lua скрипт', icon: Download, type: 'action', action: () => {
        window.open('/api/agent/script', '_blank');
        toast.success('Скачивание MoonAgent.lua');
        onClose();
      }},
    ];
    return [...pages, ...actions];
  }, [setActivePage, onClose, queryClient]);

  const filtered = useMemo(() => {
    if (!query.trim()) return items;
    const q = query.toLowerCase();
    return items.filter(i => i.label.toLowerCase().includes(q));
  }, [query, items]);

  const selectedIndex = filtered.length > 0 ? Math.min(localIndex, filtered.length - 1) : 0;

  const resetAndFocus = () => {
    setQuery('');
    setLocalIndex(0);
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  // Reset search when palette opens
  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => inputRef.current?.focus(), 0);
    return () => clearTimeout(timer);
  }, [open]);

  const handleSelect = (item: SearchItem) => { item.action?.(); };

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); setLocalIndex(i => Math.min(i + 1, filtered.length - 1)); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setLocalIndex(i => Math.max(i - 1, 0)); }
      else if (e.key === 'Enter' && filtered[selectedIndex]) { handleSelect(filtered[selectedIndex]); }
      else if (e.key === 'Escape') { onClose(); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, filtered, localIndex, onClose, handleSelect]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[15vh]" onClick={onClose}>
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: -8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: -8 }}
        transition={{ duration: 0.15 }}
        className="w-full max-w-lg bg-[#161B22] border border-white/10 rounded-xl shadow-2xl shadow-black/50 overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 px-4 border-b border-white/[0.06]">
          <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
          <Input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Поиск страниц и действий..."
            className="border-0 bg-transparent focus-visible:ring-0 text-gray-200 placeholder:text-gray-500 h-11 px-0 text-sm"
          />
          <kbd className="text-[10px] text-gray-600 bg-white/5 px-1.5 py-0.5 rounded border border-white/[0.06] flex-shrink-0">ESC</kbd>
        </div>
        <div className="max-h-72 overflow-y-auto p-2">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-gray-500 text-sm">Ничего не найдено</div>
          ) : (
            filtered.map((item, i) => {
              const Icon = item.icon;
              const isSelected = i === localIndex;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelect(item)}
                  onMouseEnter={() => setLocalIndex(i)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                    isSelected ? 'bg-blue-500/10 text-blue-300' : 'text-gray-300 hover:bg-white/[0.04]'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0 text-gray-500" />
                  <span className="flex-1">{item.label}</span>
                  <Badge variant="outline" className="text-[9px] px-1.5 py-0 border-white/[0.06] text-gray-600 capitalize">
                    {item.type === 'page' ? 'страница' : 'действие'}
                  </Badge>
                </button>
              );
            })
          )}
        </div>
        <div className="border-t border-white/[0.04] px-4 py-2 flex items-center gap-3 text-[10px] text-gray-600">
          <span className="flex gap-1"><kbd className="bg-white/5 px-1 rounded">↑↓</kbd> навигация</span>
          <span className="flex gap-1"><kbd className="bg-white/5 px-1 rounded">↵</kbd> выбрать</span>
          <span className="flex gap-1"><kbd className="bg-white/5 px-1 rounded">Esc</kbd> закрыть</span>
        </div>
      </motion.div>
    </div>
  );
}

// ─── PROFILE SWITCHER ─────────────────────────────────────────────────────

function ProfileSwitcher() {
  const { data: statusData } = useQuery({
    queryKey: ['profile-switcher-status'],
    queryFn: () => fetch('/api/status').then(r => r.json()).catch(() => null),
    refetchInterval: 15000,
  });
  const { data: profiles, isLoading } = useQuery({
    queryKey: ['profile-switcher-list'],
    queryFn: () => fetch('/api/profiles').then(r => r.json()).catch(() => []),
  });
  const queryClient = useQueryClient();
  const currentProfile = statusData?.currentProfile || '—';

  const activate = (id: string, name: string) => {
    fetch(`/api/profiles/${id}/activate`, { method: 'POST' })
      .then(() => { toast.success(`Профиль "${name}" активирован`); queryClient.invalidateQueries(); })
      .catch(() => toast.error('Ошибка смены профиля'));
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="flex items-center gap-2 px-2.5 py-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span className="text-[11px] text-emerald-400 font-medium">{currentProfile}</span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-2 bg-[#1E2530] border-white/10" side="bottom" align="center">
        <div className="text-[10px] text-gray-500 uppercase tracking-wider px-2 py-1 mb-1">Активный профиль</div>
        {isLoading ? (
          <div className="space-y-1"><Skeleton className="h-8 w-full bg-white/5" /><Skeleton className="h-8 w-full bg-white/5" /></div>
        ) : (
          <div className="space-y-0.5">
            {profiles?.map((p: { id: string; name: string; enabled: boolean }) => (
              <button
                key={p.id}
                onClick={() => activate(p.id, p.name)}
                disabled={!p.enabled}
                className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-xs transition-colors hover:bg-white/5 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <span className="flex-1 text-left text-gray-300">{p.name}</span>
                {p.name.toLowerCase() === currentProfile?.toLowerCase() && <Check className="w-3.5 h-3.5 text-blue-400" />}
              </button>
            ))}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

// ─── SIDEBAR ─────────────────────────────────────────────────────────────────

function Sidebar() {
  const { activePage, setActivePage, sidebarCollapsed, toggleSidebar } = useMoonStore();

  return (
    <motion.aside
      initial={false}
      animate={{ width: sidebarCollapsed ? 72 : 280 }}
      transition={{ duration: 0.25, ease: 'easeInOut' }}
      className="h-full flex flex-col border-r border-white/[0.06] bg-[#0D1117]/50 backdrop-blur-sm flex-shrink-0"
    >
      <div className="p-4 flex items-center justify-between min-h-[60px]">
        {!sidebarCollapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2.5"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Moon className="w-4.5 h-4.5 text-white" />
            </div>
            <span className="font-semibold text-gray-100 text-sm">Moon Control</span>
            <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-white/10 text-gray-400 font-normal">v0.1.0</Badge>
          </motion.div>
        )}
        <button
          onClick={toggleSidebar}
          className="w-8 h-8 rounded-lg hover:bg-white/5 flex items-center justify-center text-gray-400 hover:text-gray-200 transition-colors"
        >
          {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      <ScrollArea className="flex-1 px-2">
        <nav className="flex flex-col gap-1 pb-4">
          {SIDEBAR_ITEMS.map((item) => {
            const isActive = activePage === item.id;
            const Icon = item.icon;
            return (
              <Tooltip key={item.id} delayDuration={sidebarCollapsed ? 0 : 500}>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => setActivePage(item.id)}
                    className={`
                      w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 relative
                      ${isActive
                        ? 'bg-blue-500/10 text-blue-400'
                        : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                      }
                    `}
                  >
                    {isActive && (
                      <motion.div
                        layoutId="sidebar-indicator"
                        className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full bg-blue-400"
                        transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                      />
                    )}
                    <Icon className={`w-4.5 h-4.5 flex-shrink-0 ${isActive ? 'text-blue-400' : ''}`} />
                    {!sidebarCollapsed && (
                      <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.05 }}>
                        {item.label}
                      </motion.span>
                    )}
                  </button>
                </TooltipTrigger>
                {sidebarCollapsed && (
                  <TooltipContent side="right" className="bg-[#1E2530] border-white/10 text-gray-200 text-xs">
                    {item.label}
                  </TooltipContent>
                )}
              </Tooltip>
            );
          })}
        </nav>
      </ScrollArea>
    </motion.aside>
  );
}

// ─── TOP BAR ────────────────────────────────────────────────────────────────

function TopBar() {
  const { setActivePage } = useMoonStore();
  const [searchOpen, setSearchOpen] = useState(false);

  // Fetch recent event count for notification badge
  const { data: recentEvents } = useQuery({
    queryKey: ['recent-events-count'],
    queryFn: () => fetch('/api/events?limit=5').then(r => r.json()).catch(() => null),
    refetchInterval: 30000,
  });
  const notifCount = recentEvents?.data?.length ? Math.min(recentEvents.data.length, 9) : 0;

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        setSearchOpen(o => !o);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
        e.preventDefault();
        fetch('/api/backups', { method: 'POST' })
          .then(() => toast.success('Бэкап создан'))
          .catch(() => toast.error('Ошибка создания бэкапа'));
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  return (
    <header className="h-[60px] border-b border-white/[0.06] bg-[#0D1117]/50 backdrop-blur-sm flex items-center justify-between px-6 flex-shrink-0 relative z-40">
      {/* Left */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center lg:hidden shadow-lg shadow-blue-500/20">
          <Moon className="w-4 h-4 text-white" />
        </div>
        <h1 className="text-base font-semibold text-gray-100 hidden lg:block">Moon Control</h1>
        <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-white/10 text-gray-500 font-normal hidden sm:inline-flex">v0.1.0</Badge>
      </div>

      {/* Center: Profile + Clock */}
      <div className="flex items-center gap-4">
        <ProfileSwitcher />
        <Separator orientation="vertical" className="h-4 bg-white/[0.06] hidden sm:block" />
        <LiveClock />
      </div>

      {/* Right */}
      <div className="flex items-center gap-0.5">
        <TooltipProvider delayDuration={300}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 text-gray-400 hover:text-gray-200 hover:bg-white/5"
                onClick={() => setSearchOpen(true)}
              >
                <Search className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-[#1E2530] border-white/10 text-gray-200 text-xs">Поиск (Ctrl+P)</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 text-gray-400 hover:text-gray-200 hover:bg-white/5 relative"
                onClick={() => setActivePage('events')}
              >
                <Bell className="w-4 h-4" />
                {notifCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-[9px] font-bold text-white flex items-center justify-center leading-none">
                    {notifCount}
                  </span>
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-[#1E2530] border-white/10 text-gray-200 text-xs">Уведомления</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 text-gray-400 hover:text-gray-200 hover:bg-white/5"
                onClick={() => setActivePage('settings')}
              >
                <Settings className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent className="bg-[#1E2530] border-white/10 text-gray-200 text-xs">Настройки</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <CommandPalette open={searchOpen} onClose={() => setSearchOpen(false)} />
    </header>
  );
}

// ─── BOTTOM STATUS BAR ──────────────────────────────────────────────────────

function StatusIndicator({ label, status }: { label: string; status: string }) {
  const s = status?.toLowerCase() || '';
  const isOk = s === 'online' || s === 'connected' || s === 'ok';
  const dotColor = isOk ? 'bg-emerald-400' : 'bg-red-400';
  const textColor = isOk ? 'text-emerald-400' : 'text-red-400';
  return (
    <span className="flex items-center gap-1.5">
      <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />
      {label}: <span className={textColor}>{(status || '—').toUpperCase()}</span>
    </span>
  );
}

function BottomStatusBar() {
  const { data: statusData, isLoading: statusLoading } = useQuery({
    queryKey: ['status-bar'],
    queryFn: () => fetch('/api/status').then(r => r.json()).catch(() => null),
    refetchInterval: 15000,
  });

  const { data: eventsData } = useQuery({
    queryKey: ['status-bar-events'],
    queryFn: () => fetch('/api/events?limit=1').then(r => r.json()).catch(() => null),
    refetchInterval: 30000,
  });

  if (statusLoading) {
    return (
      <footer className="h-8 border-t border-white/[0.06] bg-[#0D1117]/80 backdrop-blur-sm flex items-center px-4 gap-4 flex-shrink-0 mt-auto">
        <Skeleton className="h-3 w-24 bg-white/5" />
        <Skeleton className="h-3 w-24 bg-white/5" />
        <Skeleton className="h-3 w-28 bg-white/5" />
        <Skeleton className="h-3 w-20 bg-white/5" />
        <Skeleton className="h-3 w-24 bg-white/5" />
        <Skeleton className="h-3 w-28 bg-white/5" />
      </footer>
    );
  }

  const backendStatus = statusData?.backendStatus || 'online';
  const luaStatus = statusData?.luaStatus || 'disconnected';
  const telegramStatus = statusData?.telegramStatus || 'disconnected';
  const eventCount = eventsData?.pagination?.total ?? '—';
  const profile = statusData?.currentProfile || '—';
  const version = statusData?.version || 'v0.1.0';

  return (
    <footer className="h-8 border-t border-white/[0.06] bg-[#0D1117]/80 backdrop-blur-sm flex items-center px-4 gap-4 text-[11px] text-gray-500 flex-shrink-0 mt-auto">
      <StatusIndicator label="Бэкенд" status={backendStatus} />
      <Separator orientation="vertical" className="h-3.5 bg-white/10" />
      <StatusIndicator label="Lua" status={luaStatus} />
      <Separator orientation="vertical" className="h-3.5 bg-white/10" />
      <StatusIndicator label="Telegram" status={telegramStatus} />
      <Separator orientation="vertical" className="h-3.5 bg-white/10" />
      <StatusIndicator label="БД" status="ok" />
      <Separator orientation="vertical" className="h-3.5 bg-white/10" />
      <span>События: <span className="text-gray-300">{eventCount}</span></span>
      <Separator orientation="vertical" className="h-3.5 bg-white/10" />
      <span>Профиль: <span className="text-gray-300">{profile}</span></span>
      <div className="ml-auto text-gray-600">{version}</div>
    </footer>
  );
}

export { Sidebar, TopBar, BottomStatusBar };