import type { LucideIcon } from 'lucide-react';

export interface StatusItem {
  name: string;
  status: string;
  icon: LucideIcon;
}

export interface Profile {
  id: string;
  name: string;
  description: string;
  triggerCount: number;
  chatFilterCount: number;
  lastUpdated: string;
  enabled: boolean;
  isActive: boolean;
}

export interface TriggerItem {
  id: string;
  name: string;
  triggerText: string;
  matchType: string;
  group: string;
  priority: number;
  cooldown: number;
  enabled: boolean;
  caseSensitive: boolean;
  wholeWord: boolean;
  description: string;
}

export interface ChatType {
  id: string;
  name: string;
  icon: LucideIcon;
  enabled: boolean;
}

export interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  actions: AutomationAction[];
  priority: number;
  cooldown: number;
  enabled: boolean;
}

export interface AutomationAction {
  id: string;
  type: string;
  params: Record<string, string>;
}

export interface ScheduledTask {
  id: string;
  name: string;
  scheduledTime: string;
  status: string;
  payload: string;
}

export interface EventItem {
  id: string;
  time: string;
  source: string;
  level: string;
  event: string;
  description: string;
  jsonData?: Record<string, unknown>;
}

export interface BackupItem {
  id: string;
  filename: string;
  date: string;
  size: string;
  comment: string;
}