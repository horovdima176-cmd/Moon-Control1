'use client';

import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { LEVEL_COLORS, MOCK_EVENTS } from './constants';
import type { EventItem } from './types';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function EventsPage() {
  const [levelFilter, setLevelFilter] = useState('ALL');
  const [sourceFilter, setSourceFilter] = useState('ALL');
  const [detailEvent, setDetailEvent] = useState<EventItem | null>(null);

  const { data: eventsData, isLoading } = useQuery({
    queryKey: ['events', levelFilter, sourceFilter],
    queryFn: () => {
      const params = new URLSearchParams({ limit: '50', page: '1' });
      if (levelFilter !== 'ALL') params.set('level', levelFilter.toLowerCase());
      if (sourceFilter !== 'ALL') params.set('source', sourceFilter.toLowerCase());
      return fetch(`/api/events?${params}`).then(r => r.json()).catch(() => null);
    },
    refetchInterval: 10000,
  });

  const events = eventsData?.events || MOCK_EVENTS;
  const sources = ['ALL', 'Lua', 'Telegram', 'System', 'Database'];

  const filtered = events.filter((e: EventItem) => {
    if (levelFilter !== 'ALL' && e.level !== levelFilter) return false;
    if (sourceFilter !== 'ALL' && e.source !== sourceFilter) return false;
    return true;
  });

  const clearMutation = useMutation({
    mutationFn: () => fetch('/api/events', { method: 'DELETE' }).then(r => r.json()),
    onSuccess: () => { toast.success('Журнал очищен'); },
  });

  return (
    <PageWrapper>
      <SectionHeader title="Журнал событий" description="Полный лог всех событий системы" action={
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button size="sm" variant="ghost" className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs h-8">
              <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Очистить всё
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-[#1E2530] border-white/10">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-gray-100">Очистить журнал?</AlertDialogTitle>
              <AlertDialogDescription className="text-gray-400">Все события будут удалены навсегда.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-white/5 border-white/10 text-gray-300 hover:bg-white/10">Отмена</AlertDialogCancel>
              <AlertDialogAction className="bg-red-500 hover:bg-red-600 text-white" onClick={() => clearMutation.mutate()}>Очистить</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      } />

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-4">
        <div className="flex gap-1 bg-[#161B22] rounded-lg p-1">
          {['ALL', 'INFO', 'WARNING', 'ERROR', 'SYSTEM'].map(lvl => (
            <button
              key={lvl}
              onClick={() => setLevelFilter(lvl)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                levelFilter === lvl
                  ? 'bg-white/10 text-gray-200'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {lvl === 'ALL' ? 'Все' : lvl}
            </button>
          ))}
        </div>
        <div className="flex gap-1 bg-[#161B22] rounded-lg p-1">
          {sources.map(src => (
            <button
              key={src}
              onClick={() => setSourceFilter(src)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                sourceFilter === src
                  ? 'bg-white/10 text-gray-200'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {src === 'ALL' ? 'Все источники' : src}
            </button>
          ))}
        </div>
      </div>

      {/* Events Table */}
      {isLoading ? (
        <div className="space-y-2">
          {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-10 bg-white/5 rounded-lg" />)}
        </div>
      ) : (
        <GlassCard className="overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-white/[0.06] hover:bg-transparent">
                  <TableHead className="text-gray-400 text-xs font-medium w-[100px]">Время</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium w-[100px]">Источник</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium w-[100px]">Уровень</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium">Событие</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium hidden md:table-cell">Описание</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((ev: EventItem) => (
                  <TableRow
                    key={ev.id}
                    className="border-white/[0.04] hover:bg-white/[0.02] transition-colors cursor-pointer"
                    onClick={() => setDetailEvent(ev)}
                  >
                    <TableCell className="text-gray-400 text-xs font-mono">{ev.time}</TableCell>
                    <TableCell>
                      <Badge className="text-[10px] px-1.5 py-0 bg-white/5 text-gray-400 border-0">{ev.source}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={`text-[10px] px-1.5 py-0 border-0 ${LEVEL_COLORS[ev.level] || LEVEL_COLORS.INFO}`}>{ev.level}</Badge>
                    </TableCell>
                    <TableCell className="text-gray-200 text-sm">{ev.event}</TableCell>
                    <TableCell className="text-gray-500 text-xs hidden md:table-cell max-w-[300px] truncate">{ev.description}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </GlassCard>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!detailEvent} onOpenChange={() => setDetailEvent(null)}>
        <DialogContent className="bg-[#1E2530] border-white/10 text-gray-200 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-gray-100">{detailEvent?.event}</DialogTitle>
          </DialogHeader>
          {detailEvent && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[11px] text-gray-500 mb-1">Время</div>
                  <div className="text-sm text-gray-200 font-mono">{detailEvent.time}</div>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[11px] text-gray-500 mb-1">Источник</div>
                  <div className="text-sm text-gray-200">{detailEvent.source}</div>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[11px] text-gray-500 mb-1">Уровень</div>
                  <Badge className={`text-[10px] px-1.5 py-0 border-0 ${LEVEL_COLORS[detailEvent.level]}`}>{detailEvent.level}</Badge>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[11px] text-gray-500 mb-1">ID</div>
                  <div className="text-sm text-gray-200 font-mono">{detailEvent.id}</div>
                </div>
              </div>
              <div className="bg-[#0D1117] rounded-lg p-3">
                <div className="text-[11px] text-gray-500 mb-1">Описание</div>
                <div className="text-sm text-gray-300">{detailEvent.description}</div>
              </div>
              {detailEvent.jsonData && (
                <div className="bg-[#0D1117] rounded-lg p-3">
                  <div className="text-[11px] text-gray-500 mb-1">JSON Data</div>
                  <pre className="text-xs text-gray-400 font-mono overflow-auto max-h-40">{JSON.stringify(detailEvent.jsonData, null, 2)}</pre>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PageWrapper>
  );
}

export default EventsPage;