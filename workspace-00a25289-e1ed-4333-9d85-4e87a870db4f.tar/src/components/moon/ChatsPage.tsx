'use client';

import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { CHAT_TYPES } from './constants';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function ChatsPage() {
  const queryClient = useQueryClient();
  const [chatStates, setChatStates] = useState<Record<string, boolean>>(
    Object.fromEntries(CHAT_TYPES.map(c => [c.id, c.enabled]))
  );

  const toggleChat = (id: string) => {
    setChatStates(prev => {
      const next = { ...prev, [id]: !prev[id] };
      fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatFilters: next }),
      }).then(() => {
        queryClient.invalidateQueries({ queryKey: ['settings'] });
        toast.success('Настройки сохранены');
      }).catch(() => toast.error('Ошибка сохранения'));
      return next;
    });
  };

  return (
    <PageWrapper>
      <SectionHeader title="Чаты" description="Управление типами чатов и фильтрами" />

      <div className="space-y-2">
        {CHAT_TYPES.map((chat, idx) => {
          const Icon = chat.icon;
          return (
            <motion.div
              key={chat.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.03 }}
            >
              <GlassCard className="flex items-center justify-between p-4 hover:bg-white/[0.03] transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-200">{chat.name}</h3>
                    <p className="text-[11px] text-gray-500">Фильтр чата: {chat.name.toLowerCase()}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className={`text-[10px] px-2 py-0.5 border-0 ${chatStates[chat.id] ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'}`}>
                    {chatStates[chat.id] ? 'Включён' : 'Отключён'}
                  </Badge>
                  <Switch checked={chatStates[chat.id]} onCheckedChange={() => toggleChat(chat.id)} />
                </div>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>
    </PageWrapper>
  );
}

export default ChatsPage;