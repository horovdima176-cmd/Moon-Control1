'use client';

import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { HardDrive, Database, Clock, Download, Trash2, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { MOCK_BACKUPS } from './constants';
import type { BackupItem } from './types';
import { PageWrapper, SectionHeader, GlassCard, EmptyState } from './helpers';

function BackupPage() {
  const queryClient = useQueryClient();

  const { data: backupsData, isLoading } = useQuery({
    queryKey: ['backups'],
    queryFn: () => fetch('/api/backups').then(r => r.json()).catch(() => null),
  });

  const createMutation = useMutation({
    mutationFn: () => fetch('/api/backups', { method: 'POST' }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['backups'] }); toast.success('Бэкап создан'); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => fetch(`/api/backups/${id}`, { method: 'DELETE' }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['backups'] }); toast.success('Бэкап удалён'); },
  });

  const backups = backupsData?.backups || MOCK_BACKUPS;

  return (
    <PageWrapper>
      <SectionHeader title="Бэкапы" description="Управление резервными копиями" action={
        <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white text-xs h-8" onClick={() => createMutation.mutate()}>
          <Download className="w-3.5 h-3.5 mr-1.5" /> Создать бэкап
        </Button>
      } />

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 bg-white/5 rounded-lg" />)}
        </div>
      ) : backups.length === 0 ? (
        <EmptyState icon={HardDrive} title="Нет бэкапов" description="Создайте первый бэкап базы данных" />
      ) : (
        <div className="space-y-2">
          {backups.map((b: BackupItem) => (
            <GlassCard key={b.id} className="flex items-center justify-between p-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                  <Database className="w-5 h-5 text-gray-400" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-200 font-mono text-xs">{b.filename}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[11px] text-gray-500 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {b.date}
                    </span>
                    <span className="text-[11px] text-gray-600">•</span>
                    <span className="text-[11px] text-gray-500">{b.size}</span>
                    <span className="text-[11px] text-gray-600">•</span>
                    <span className="text-[11px] text-gray-500">{b.comment}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <TooltipProvider delayDuration={300}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-gray-500 hover:text-gray-300" disabled>
                        <Upload className="w-3.5 h-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent className="bg-[#1E2530] border-white/10 text-gray-200 text-xs">Восстановить (скоро)</TooltipContent>
                  </Tooltip>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-gray-500 hover:text-red-400"
                        onClick={() => deleteMutation.mutate(b.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent className="bg-[#1E2530] border-white/10 text-gray-200 text-xs">Удалить</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </PageWrapper>
  );
}

export default BackupPage;