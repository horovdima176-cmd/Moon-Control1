'use client';

import React from 'react';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { Zap, BarChart3, Cpu, RefreshCw } from 'lucide-react';
import { STAT_CHART_DATA, PIE_DATA, RESOURCE_DATA, RECONNECT_DATA } from './constants';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function StatisticsPage() {
  return (
    <PageWrapper>
      <SectionHeader title="Статистика" description="Графики и аналитика системы" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Triggers per day */}
        <GlassCard className="p-5">
          <h3 className="text-sm font-medium text-gray-200 mb-4 flex items-center gap-2">
            <Zap className="w-4 h-4 text-blue-400" /> Триггеры за неделю
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={STAT_CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} width={35} />
                <RTooltip
                  contentStyle={{ background: '#1E2530', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#E6EDF3' }}
                />
                <Bar dataKey="triggers" fill="#3B82F6" radius={[4, 4, 0, 0]} maxBarSize={36} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Events by source */}
        <GlassCard className="p-5">
          <h3 className="text-sm font-medium text-gray-200 mb-4 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-purple-400" /> События по источникам
          </h3>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={PIE_DATA}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {PIE_DATA.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} stroke="transparent" />
                  ))}
                </Pie>
                <RTooltip
                  contentStyle={{ background: '#1E2530', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#E6EDF3' }}
                />
                <Legend
                  verticalAlign="bottom"
                  iconType="circle"
                  iconSize={8}
                  formatter={(value: string) => <span className="text-gray-400 text-xs">{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* CPU/RAM */}
        <GlassCard className="p-5">
          <h3 className="text-sm font-medium text-gray-200 mb-4 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" /> CPU / RAM
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={RESOURCE_DATA}>
                <defs>
                  <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="ramGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#22C55E" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} width={35} />
                <RTooltip
                  contentStyle={{ background: '#1E2530', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#E6EDF3' }}
                />
                <Legend
                  verticalAlign="bottom"
                  iconType="line"
                  iconSize={8}
                  formatter={(value: string) => <span className="text-gray-400 text-xs">{value === 'cpu' ? 'CPU %' : 'RAM %'}</span>}
                />
                <Area type="monotone" dataKey="cpu" stroke="#3B82F6" fill="url(#cpuGrad)" strokeWidth={2} />
                <Area type="monotone" dataKey="ram" stroke="#22C55E" fill="url(#ramGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Reconnects */}
        <GlassCard className="p-5">
          <h3 className="text-sm font-medium text-gray-200 mb-4 flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-yellow-400" /> Переподключения
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={RECONNECT_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} axisLine={false} tickLine={false} width={25} />
                <RTooltip
                  contentStyle={{ background: '#1E2530', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#E6EDF3' }}
                />
                <Line type="stepAfter" dataKey="count" stroke="#F59E0B" strokeWidth={2} dot={{ r: 4, fill: '#F59E0B', stroke: '#1E2530', strokeWidth: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>
    </PageWrapper>
  );
}

export default StatisticsPage;