'use client';

import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CalendarClock, Clock, X } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { MOCK_SCHEDULED } from './constants';
import type { ScheduledTask } from './types';
import { PageWrapper, SectionHeader, GlassCard, EmptyState, StatusBadge } from './helpers';

function SchedulerPage() {
  const queryClient = useQueryClient();

  const { data: schedulerData, isLoading } = useQuery({
    queryKey: ['scheduler'],
    queryFn: () => fetch('/api/scheduler').then(r => r.json()).catch(() => null),
    refetchInterval: 5000,
  });

  const cancelMutation = useMutation({
    mutationFn: (id: string) => fetch(`/api/scheduler/${id}`, { method: 'DELETE' }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['scheduler'] }); toast.success('Задача отменена'); },
  });

  const tasks = schedulerData?.tasks || MOCK_SCHEDULED;

  return (
    <PageWrapper>
      <SectionHeader title="Планировщик" description="Запланированные задачи" />

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 bg-white/5 rounded-lg" />)}
        </div>
      ) : tasks.length === 0 ? (
        <EmptyState icon={CalendarClock} title="Нет задач" description="Запланированные задачи отсутствуют" />
      ) : (
        <div className="space-y-2">
          {tasks.map((task: ScheduledTask) => (
            <GlassCard key={task.id} className="flex items-center justify-between p-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                  <CalendarClock className="w-5 h-5 text-gray-400" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-200">{task.name}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[11px] text-gray-500 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {task.scheduledTime}
                    </span>
                    <span className="text-[11px] text-gray-600">•</span>
                    <span className="text-[11px] text-gray-500 font-mono max-w-[200px] truncate">{task.payload}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge status={task.status} />
                {task.status === 'PENDING' && (
                  <Button size="sm" variant="ghost" className="text-xs text-gray-500 hover:text-red-400 h-7"
                    onClick={() => cancelMutation.mutate(task.id)}>
                    <X className="w-3 h-3 mr-1" /> Отменить
                  </Button>
                )}
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </PageWrapper>
  );
}

export default SchedulerPage;