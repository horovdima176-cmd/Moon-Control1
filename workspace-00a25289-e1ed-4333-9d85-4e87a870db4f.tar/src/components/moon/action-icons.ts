import {
  Send, Timer, ZapOff, RefreshCw, FileText, Terminal, Bell,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export const ACTION_ICONS: Record<string, { icon: LucideIcon; label: string; color: string }> = {
  telegram: { icon: Send, label: 'Telegram', color: 'text-blue-400' },
  delay: { icon: Timer, label: 'Задержка', color: 'text-yellow-400' },
  disconnect: { icon: ZapOff, label: 'Отключение', color: 'text-red-400' },
  reconnect: { icon: RefreshCw, label: 'Переподключение', color: 'text-emerald-400' },
  log: { icon: FileText, label: 'Запись в лог', color: 'text-purple-400' },
  command: { icon: Terminal, label: 'Команда', color: 'text-cyan-400' },
  notification: { icon: Bell, label: 'Уведомление', color: 'text-orange-400' },
};