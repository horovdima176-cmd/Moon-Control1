'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { UserCircle, Zap, MessageSquare, Plus, Pencil, Copy, Trash2, Play } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { MOCK_PROFILES } from './constants';
import type { Profile } from './types';
import { PageWrapper, SectionHeader, GlassCard, EmptyState } from './helpers';

function ProfilesPage() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState<Profile | null>(null);
  const [formName, setFormName] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formEnabled, setFormEnabled] = useState(true);

  const { data: profilesData, isLoading } = useQuery({
    queryKey: ['profiles'],
    queryFn: () => fetch('/api/profiles').then(r => r.json()).catch(() => null),
  });

  const createMutation = useMutation({
    mutationFn: (data: { name: string; description: string; enabled: boolean }) =>
      fetch('/api/profiles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['profiles'] }); setDialogOpen(false); toast.success('Профиль создан'); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => fetch(`/api/profiles/${id}`, { method: 'DELETE' }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['profiles'] }); toast.success('Профиль удалён'); },
  });

  const profiles = profilesData?.profiles || MOCK_PROFILES;

  const openCreate = () => {
    setEditingProfile(null);
    setFormName(''); setFormDesc(''); setFormEnabled(true);
    setDialogOpen(true);
  };

  const openEdit = (p: Profile) => {
    setEditingProfile(p);
    setFormName(p.name); setFormDesc(p.description); setFormEnabled(p.enabled);
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formName.trim()) { toast.error('Введите название профиля'); return; }
    createMutation.mutate({ name: formName, description: formDesc, enabled: formEnabled });
  };

  return (
    <PageWrapper>
      <SectionHeader title="Профили" description="Управление профилями конфигурации" action={
        <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white text-xs h-8" onClick={openCreate}>
          <Plus className="w-3.5 h-3.5 mr-1.5" /> Создать профиль
        </Button>
      } />

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-40 bg-white/5 rounded-xl" />)}
        </div>
      ) : profiles.length === 0 ? (
        <EmptyState icon={UserCircle} title="Нет профилей" description="Создайте первый профиль для начала работы" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {profiles.map((p: Profile) => (
            <GlassCard key={p.id} hover className={`p-5 ${p.isActive ? 'border-blue-500/30 ring-1 ring-blue-500/20' : ''}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                    <UserCircle className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-100">{p.name}</h3>
                    {p.isActive && <Badge className="text-[10px] px-1.5 py-0 bg-blue-500/20 text-blue-400 border-0">Активный</Badge>}
                  </div>
                </div>
                <Badge className={`text-[10px] px-1.5 py-0 border-0 ${p.enabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'}`}>
                  {p.enabled ? 'Вкл' : 'Выкл'}
                </Badge>
              </div>
              <p className="text-xs text-gray-500 mb-4 line-clamp-2">{p.description || 'Нет описания'}</p>
              <div className="flex items-center gap-4 text-[11px] text-gray-500 mb-4">
                <span className="flex items-center gap-1"><Zap className="w-3 h-3" /> {p.triggerCount} триггеров</span>
                <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> {p.chatFilterCount} чатов</span>
              </div>
              <div className="flex items-center gap-1.5 pt-3 border-t border-white/[0.06]">
                <Button size="sm" variant="ghost" className="h-7 text-[11px] text-gray-400 hover:text-blue-400" onClick={() => toast.success('Профиль активирован', { description: `Профиль "${p.name}" теперь активен` })}>
                  <Play className="w-3 h-3 mr-1" /> Открыть
                </Button>
                <Button size="sm" variant="ghost" className="h-7 text-[11px] text-gray-400 hover:text-gray-200" onClick={() => openEdit(p)}>
                  <Pencil className="w-3 h-3 mr-1" /> Изменить
                </Button>
                <Button size="sm" variant="ghost" className="h-7 text-[11px] text-gray-400 hover:text-gray-200" onClick={() => { navigator.clipboard.writeText(JSON.stringify(p)); toast.success('Скопировано'); }}>
                  <Copy className="w-3 h-3 mr-1" /> Копия
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="ghost" className="h-7 text-[11px] text-gray-400 hover:text-red-400 ml-auto">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-[#1E2530] border-white/10">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-gray-100">Удалить профиль?</AlertDialogTitle>
                      <AlertDialogDescription className="text-gray-400">
                        Профиль &quot;{p.name}&quot; будет удалён навсегда. Это действие нельзя отменить.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-white/5 border-white/10 text-gray-300 hover:bg-white/10">Отмена</AlertDialogCancel>
                      <AlertDialogAction className="bg-red-500 hover:bg-red-600 text-white" onClick={() => deleteMutation.mutate(p.id)}>Удалить</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#1E2530] border-white/10 text-gray-200 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-gray-100">{editingProfile ? 'Редактировать профиль' : 'Создать профиль'}</DialogTitle>
            <DialogDescription className="text-gray-400">
              {editingProfile ? 'Измените настройки профиля' : 'Заполните данные для нового профиля'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Название</Label>
              <Input value={formName} onChange={e => setFormName(e.target.value)} placeholder="Название профиля" className="bg-[#0D1117] border-white/10 text-gray-200" />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Описание</Label>
              <Textarea value={formDesc} onChange={e => setFormDesc(e.target.value)} placeholder="Описание профиля" className="bg-[#0D1117] border-white/10 text-gray-200 min-h-[80px]" />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-gray-300 text-sm">Включён</Label>
              <Switch checked={formEnabled} onCheckedChange={setFormEnabled} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" className="bg-white/5 border-white/10 text-gray-300 hover:bg-white/10" onClick={() => setDialogOpen(false)}>Отмена</Button>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white" onClick={handleSave}>
              {editingProfile ? 'Сохранить' : 'Создать'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageWrapper>
  );
}

export default ProfilesPage;