import { create } from 'zustand';

interface MoonStore {
  activePage: string;
  setActivePage: (page: string) => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  refreshKey: number;
  triggerRefresh: () => void;
}

export const useMoonStore = create<MoonStore>((set) => ({
  activePage: 'dashboard',
  setActivePage: (page) => set({ activePage: page }),
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  refreshKey: 0,
  triggerRefresh: () => set((s) => ({ refreshKey: s.refreshKey + 1 })),
}));