'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useMoonStore } from './store';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function SettingsPage() {
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState({
    sidebarCollapsed: false,
    animations: true,
    autoUpdate: false,
  });

  const { data: settingsData } = useQuery({
    queryKey: ['settings'],
    queryFn: () => fetch('/api/settings').then(r => r.json()).catch(() => null),
  });

  const { data: modulesData } = useQuery({
    queryKey: ['modules'],
    queryFn: () => fetch('/api/modules').then(r => r.json()).catch(() => null),
  });

  const { data: systemInfo } = useQuery({
    queryKey: ['system-info'],
    queryFn: () => fetch('/api/system-info').then(r => r.json()).catch(() => null),
  });

  const saveMutation = useMutation({
    mutationFn: (data: Record<string, unknown>) =>
      fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['settings'] }); toast.success('Настройки сохранены'); },
  });

  const { toggleSidebar } = useMoonStore();

  const modules = modulesData?.modules || [
    { id: 'telegram', name: 'Telegram', description: 'Управление Telegram ботом', enabled: true },
    { id: 'automation', name: 'Автоматизация', description: 'Движок автоматизации', enabled: true },
    { id: 'scheduler', name: 'Планировщик', description: 'Отложенные задачи', enabled: true },
    { id: 'backup', name: 'Бэкапы', description: 'Автоматические бэкапы БД', enabled: true },
    { id: 'lua-agent', name: 'Lua Agent', description: 'Подключение к Lua агенту', enabled: true },
  ];

  const resetDb = () => {
    toast.success('База данных сброшена', { description: 'Все данные удалены, система перезапущена' });
  };

  return (
    <PageWrapper>
      <SectionHeader title="Настройки" description="Конфигурация системы" />

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="bg-[#161B22] border border-white/[0.06] rounded-lg p-1 h-auto flex-wrap">
          {[
            { value: 'general', label: 'Общие' },
            { value: 'appearance', label: 'Внешний вид' },
            { value: 'database', label: 'База данных' },
            { value: 'modules', label: 'Модули' },
            { value: 'developer', label: 'Разработчик' },
          ].map(tab => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="text-xs text-gray-400 data-[state=active]:text-gray-200 data-[state=active]:bg-white/10 rounded-md px-3 py-1.5 h-auto"
            >
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="general">
          <GlassCard className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Тема</div>
                <div className="text-[11px] text-gray-500">Внешний вид интерфейса</div>
              </div>
              <Badge className="text-xs px-2 py-0.5 bg-white/5 text-gray-400 border-0">Тёмная (единственная)</Badge>
            </div>
            <Separator className="bg-white/[0.06]" />
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Язык</div>
                <div className="text-[11px] text-gray-500">Язык интерфейса</div>
              </div>
              <Badge className="text-xs px-2 py-0.5 bg-white/5 text-gray-400 border-0">Русский</Badge>
            </div>
            <Separator className="bg-white/[0.06]" />
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Авто-обновление</div>
                <div className="text-[11px] text-gray-500">Автоматическая проверка обновлений</div>
              </div>
              <Switch
                checked={settings.autoUpdate}
                onCheckedChange={v => setSettings(s => ({ ...s, autoUpdate: v }))}
              />
            </div>
          </GlassCard>
        </TabsContent>

        <TabsContent value="appearance">
          <GlassCard className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Свернуть боковую панель</div>
                <div className="text-[11px] text-gray-500">Показывать только иконки в боковой панели</div>
              </div>
              <Switch
                checked={settings.sidebarCollapsed}
                onCheckedChange={v => { setSettings(s => ({ ...s, sidebarCollapsed: v })); toggleSidebar(); }}
              />
            </div>
            <Separator className="bg-white/[0.06]" />
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Анимации</div>
                <div className="text-[11px] text-gray-500">Плавные переходы и анимации интерфейса</div>
              </div>
              <Switch
                checked={settings.animations}
                onCheckedChange={v => setSettings(s => ({ ...s, animations: v }))}
              />
            </div>
          </GlassCard>
        </TabsContent>

        <TabsContent value="database">
          <GlassCard className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Путь к БД</div>
                <div className="text-[11px] text-gray-500 font-mono">./db/moon_control.db</div>
              </div>
              <Badge className="text-xs px-2 py-0.5 bg-emerald-500/20 text-emerald-400 border-0">OK</Badge>
            </div>
            <Separator className="bg-white/[0.06]" />
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-200">Размер БД</div>
                <div className="text-[11px] text-gray-500">Текущий размер файла базы данных</div>
              </div>
              <span className="text-sm text-gray-300">2.4 МБ</span>
            </div>
            <Separator className="bg-white/[0.06]" />
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: 'События', value: '1,524' },
                { label: 'Триггеры', value: '48' },
                { label: 'Бэкапы', value: '3' },
              ].map(item => (
                <div key={item.label} className="bg-[#0D1117] rounded-lg p-3 text-center">
                  <div className="text-lg font-semibold text-gray-200">{item.value}</div>
                  <div className="text-[11px] text-gray-500">{item.label}</div>
                </div>
              ))}
            </div>
            <Separator className="bg-white/[0.06]" />
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" className="bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-400 border border-yellow-500/20 text-xs h-8"
                onClick={() => { toast.success('События очищены'); }}>
                Очистить события
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button size="sm" variant="ghost" className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs h-8">
                    Сбросить БД
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-[#1E2530] border-white/10">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-gray-100">Сбросить базу данных?</AlertDialogTitle>
                    <AlertDialogDescription className="text-gray-400">ВСЕ данные будут удалены. Это действие нельзя отменить.</AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-white/5 border-white/10 text-gray-300 hover:bg-white/10">Отмена</AlertDialogCancel>
                    <AlertDialogAction className="bg-red-500 hover:bg-red-600 text-white" onClick={resetDb}>Сбросить</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </GlassCard>
        </TabsContent>

        <TabsContent value="modules">
          <GlassCard className="p-5">
            <h3 className="text-sm font-medium text-gray-200 mb-4">Установленные модули</h3>
            <div className="space-y-3">
              {modules.map((mod: { id: string; name: string; description: string; enabled: boolean }) => (
                <div key={mod.id} className="flex items-center justify-between py-2">
                  <div>
                    <div className="text-sm text-gray-200">{mod.name}</div>
                    <div className="text-[11px] text-gray-500">{mod.description}</div>
                  </div>
                  <Switch defaultChecked={mod.enabled} />
                </div>
              ))}
            </div>
          </GlassCard>
        </TabsContent>

        <TabsContent value="developer">
          <GlassCard className="p-5 space-y-4">
            <h3 className="text-sm font-medium text-gray-200 mb-2">Информация для разработчика</h3>
            {[
              { label: 'API Base URL', value: '/api' },
              { label: 'WebSocket URL', value: 'ws://localhost:3001' },
              { label: 'Версия Moon Core', value: systemInfo?.version || '0.1.0' },
              { label: 'Версия Node.js', value: systemInfo?.nodeVersion || process.env.NODE_VERSION || 'v20.x' },
              { label: 'Версия SQLite', value: systemInfo?.sqliteVersion || '3.44.0' },
              { label: 'Среда', value: process.env.NODE_ENV || 'development' },
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between py-1.5">
                <span className="text-sm text-gray-400">{item.label}</span>
                <code className="text-xs text-gray-200 bg-[#0D1117] px-2 py-1 rounded font-mono">{item.value}</code>
              </div>
            ))}
          </GlassCard>
        </TabsContent>
      </Tabs>
    </PageWrapper>
  );
}

export default SettingsPage;