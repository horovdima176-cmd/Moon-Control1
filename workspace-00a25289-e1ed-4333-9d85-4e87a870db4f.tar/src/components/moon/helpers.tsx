'use client';

import React from 'react';
import type { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { useMoonStore } from './store';
import { STATUS_COLORS } from './constants';

export function StatusBadge({ status, pulse = false }: { status: string; pulse?: boolean }) {
  const isOnline = status === 'ONLINE' || status === 'CONNECTED' || status === 'OK';
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold tracking-wide uppercase border ${STATUS_COLORS[status] || STATUS_COLORS.OK}`}
    >
      {isOnline && pulse && (
        <span className="relative flex h-2 w-2 flex-shrink-0">
          <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
        </span>
      )}
      {status}
    </span>
  );
}

export function EmptyState({ icon: Icon, title, description }: { icon: LucideIcon; title: string; description: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 text-center"
    >
      <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-4">
        <Icon className="w-8 h-8 text-gray-500" />
      </div>
      <h3 className="text-gray-300 font-medium text-lg mb-1">{title}</h3>
      <p className="text-gray-500 text-sm max-w-sm">{description}</p>
    </motion.div>
  );
}

export function GlassCard({
  children,
  className = '',
  hover = false,
  glow,
  gradientBorder = false,
  ...props
}: React.ComponentProps<'div'> & {
  hover?: boolean;
  glow?: string;
  gradientBorder?: boolean;
}) {
  const glowStyle = glow
    ? { boxShadow: `0 0 20px ${glow}40, 0 0 40px ${glow}20` }
    : undefined;

  const innerContent = (
    <div
      className={[
        'backdrop-blur-sm transition-colors duration-200',
        gradientBorder
          ? 'bg-[#1E2530]/95 rounded-[10px]'
          : 'bg-[#1E2530]/80 rounded-xl border border-white/[0.06]',
        hover ? 'hover:brightness-[1.08]' : '',
        className,
      ].filter(Boolean).join(' ')}
    >
      {children}
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      whileHover={hover ? { scale: 1.02, y: -2 } : undefined}
      className={gradientBorder ? 'p-[1px] rounded-xl bg-gradient-to-br from-white/10 via-transparent to-white/5' : ''}
      style={glowStyle}
      {...props}
    >
      {innerContent}
    </motion.div>
  );
}

export function SectionHeader({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-100">{title}</h2>
        {description && <p className="text-sm text-gray-400 mt-0.5">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      key={useMoonStore(s => s.activePage)}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
    >
      {children}
    </motion.div>
  );
}