'use client';

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Moon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function AboutPage() {
  const { data: systemInfo } = useQuery({
    queryKey: ['system-info'],
    queryFn: () => fetch('/api/system-info').then(r => r.json()).catch(() => null),
  });

  return (
    <PageWrapper>
      <SectionHeader title="О системе" description="Информация о Moon Control" />

      {/* Logo & Name */}
      <GlassCard className="p-8 mb-4 text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15 }}
          className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/20"
        >
          <Moon className="w-10 h-10 text-white" />
        </motion.div>
        <h2 className="text-2xl font-bold text-gray-100 mb-1">Moon Control</h2>
        <p className="text-sm text-gray-400 mb-4">Персональная система управления игровым агентом</p>
        <Badge className="text-xs px-3 py-1 bg-blue-500/20 text-blue-400 border-0">v0.1.0</Badge>
      </GlassCard>

      {/* System Info */}
      <GlassCard className="p-5 mb-4">
        <h3 className="text-sm font-medium text-gray-200 mb-4">Информация о системе</h3>
        <div className="space-y-3">
          {[
            { label: 'Версия Moon Control', value: '0.1.0' },
            { label: 'Сборка', value: systemInfo?.build || '2024.01.15' },
            { label: 'Node.js', value: systemInfo?.nodeVersion || 'v20.11.0' },
            { label: 'SQLite', value: systemInfo?.sqliteVersion || '3.44.0' },
            { label: 'Moon Agent', value: systemInfo?.agentVersion || '1.2.5' },
            { label: 'ОС', value: systemInfo?.os || 'Linux x64' },
          ].map(item => (
            <div key={item.label} className="flex items-center justify-between py-1.5">
              <span className="text-sm text-gray-400">{item.label}</span>
              <code className="text-xs text-gray-200 bg-[#0D1117] px-2 py-1 rounded font-mono">{item.value}</code>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Architecture */}
      <GlassCard className="p-5 mb-4">
        <h3 className="text-sm font-medium text-gray-200 mb-4">Архитектура</h3>
        <div className="bg-[#0D1117] rounded-lg p-4 font-mono text-xs text-gray-400 space-y-1">
          <div>Moon Control (Desktop)</div>
          <div className="text-gray-600">│</div>
          <div className="text-gray-600">├── Moon Core (Backend)</div>
          <div className="text-gray-600">├── Telegram Module</div>
          <div className="text-gray-600">├── Moon Agent (Lua)</div>
          <div className="text-gray-600">├── Local Database (SQLite)</div>
          <div className="text-gray-600">├── Event Engine</div>
          <div className="text-gray-600">└── Automation Engine</div>
        </div>
      </GlassCard>

      {/* Credits */}
      <GlassCard className="p-5">
        <h3 className="text-sm font-medium text-gray-200 mb-2">Разработано с</h3>
        <p className="text-xs text-gray-500 leading-relaxed">
          Next.js 16 • TypeScript • Tailwind CSS • shadcn/ui • Prisma • Zustand • React Query • Framer Motion • Recharts • Sonner
        </p>
      </GlassCard>
    </PageWrapper>
  );
}

export default AboutPage;