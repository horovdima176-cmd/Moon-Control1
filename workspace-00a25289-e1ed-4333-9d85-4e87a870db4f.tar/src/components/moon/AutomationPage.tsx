'use client';

import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Workflow, Plus, Pencil, Trash2, Play, ChevronRight, ArrowUp, ArrowDown, Code } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { MOCK_AUTOMATION, ACTION_ICONS } from './constants';
import type { AutomationRule } from './types';
import { PageWrapper, SectionHeader, GlassCard, EmptyState } from './helpers';

function AutomationPage() {
  const queryClient = useQueryClient();
  const [expandedRule, setExpandedRule] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: automationData, isLoading } = useQuery({
    queryKey: ['automation'],
    queryFn: () => fetch('/api/automation').then(r => r.json()).catch(() => null),
  });

  const rules = automationData?.rules || MOCK_AUTOMATION;

  return (
    <PageWrapper>
      <SectionHeader title="Автоматизация" description="Правила автоматизации и цепочки действий" action={
        <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white text-xs h-8" onClick={() => setDialogOpen(true)}>
          <Plus className="w-3.5 h-3.5 mr-1.5" /> Создать правило
        </Button>
      } />

      {isLoading ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 bg-white/5 rounded-lg" />)}
        </div>
      ) : rules.length === 0 ? (
        <EmptyState icon={Workflow} title="Нет правил" description="Создайте первое правило автоматизации" />
      ) : (
        <div className="space-y-3">
          {rules.map((rule: AutomationRule) => {
            const isExpanded = expandedRule === rule.id;
            return (
              <GlassCard key={rule.id} className="overflow-hidden">
                <button
                  className="w-full flex items-center justify-between p-4 hover:bg-white/[0.02] transition-colors text-left"
                  onClick={() => setExpandedRule(isExpanded ? null : rule.id)}
                >
                  <div className="flex items-center gap-3">
                    <Workflow className="w-4 h-4 text-purple-400 flex-shrink-0" />
                    <div>
                      <div className="text-sm font-medium text-gray-200">{rule.name}</div>
                      <div className="text-[11px] text-gray-500">Триггер: &quot;{rule.trigger}&quot; • {rule.actions.length} действий</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className={`text-[10px] px-1.5 py-0 border-0 ${rule.enabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-500'}`}>
                      {rule.enabled ? 'Вкл' : 'Выкл'}
                    </Badge>
                    <ChevronRight className={`w-4 h-4 text-gray-500 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                  </div>
                </button>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="border-t border-white/[0.06] p-4">
                        {/* Action Chain */}
                        <div className="bg-[#0D1117] rounded-lg p-4 mb-4 space-y-2">
                          <div className="flex items-center gap-2 text-xs text-gray-400 mb-2">
                            <span className="bg-white/5 px-2 py-0.5 rounded text-gray-300 font-mono">{rule.trigger}</span>
                            <span className="text-gray-600">↓</span>
                          </div>
                          {rule.actions.map((act, idx) => {
                            const actionInfo = ACTION_ICONS[act.type] || { icon: Code, label: act.type, color: 'text-gray-400' };
                            const Icon = actionInfo.icon;
                            return (
                              <div key={act.id} className="flex items-center gap-3 group">
                                <div className="flex items-center gap-1.5 text-gray-600">
                                  <span className="w-5 h-5 rounded bg-white/5 flex items-center justify-center text-[10px] text-gray-500">{idx + 1}</span>
                                  <ChevronRight className="w-3 h-3" />
                                </div>
                                <div className="flex-1 flex items-center gap-2 bg-white/[0.03] rounded-lg px-3 py-2 group-hover:bg-white/[0.05] transition-colors">
                                  <Icon className={`w-4 h-4 ${actionInfo.color}`} />
                                  <span className="text-sm text-gray-300">{actionInfo.label}</span>
                                  {act.params.message && (
                                    <span className="text-xs text-gray-500 truncate ml-auto max-w-[200px]">{act.params.message}</span>
                                  )}
                                  {act.params.seconds && (
                                    <span className="text-xs text-gray-500">{act.params.seconds} сек</span>
                                  )}
                                </div>
                                <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <Button size="icon" variant="ghost" className="w-6 h-6 text-gray-500 hover:text-gray-300"><ArrowUp className="w-3 h-3" /></Button>
                                  <Button size="icon" variant="ghost" className="w-6 h-6 text-gray-500 hover:text-gray-300"><ArrowDown className="w-3 h-3" /></Button>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Meta */}
                        <div className="flex items-center gap-4 text-[11px] text-gray-500 mb-3">
                          <span>Приоритет: {rule.priority}</span>
                          <span>Кулдаун: {rule.cooldown > 0 ? `${rule.cooldown}с` : 'нет'}</span>
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-xs h-7" onClick={() => toast.success('Тест', { description: 'Правило выполнено (dry run)' })}>
                            <Play className="w-3 h-3 mr-1" /> Dry Run
                          </Button>
                          <Button size="sm" variant="ghost" className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 text-xs h-7">
                            <Pencil className="w-3 h-3 mr-1" /> Изменить
                          </Button>
                          <Button size="sm" variant="ghost" className="bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs h-7 ml-auto"
                            onClick={() => { toast.success('Правило удалено'); queryClient.invalidateQueries({ queryKey: ['automation'] }); }}>
                            <Trash2 className="w-3 h-3 mr-1" /> Удалить
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </GlassCard>
            );
          })}
        </div>
      )}

      {/* Create Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#1E2530] border-white/10 text-gray-200 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-gray-100">Создать правило</DialogTitle>
            <DialogDescription className="text-gray-400">Настройте новое правило автоматизации</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Название</Label>
              <Input placeholder="Название правила" className="bg-[#0D1117] border-white/10 text-gray-200" />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Триггер</Label>
              <Input placeholder="Текст или событие триггера" className="bg-[#0D1117] border-white/10 text-gray-200 font-mono" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300 text-sm">Приоритет</Label>
                <Input type="number" defaultValue={1} className="bg-[#0D1117] border-white/10 text-gray-200" />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300 text-sm">Кулдаун (сек)</Label>
                <Input type="number" defaultValue={0} className="bg-[#0D1117] border-white/10 text-gray-200" />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-gray-300 text-sm">Включено</Label>
              <Switch defaultChecked />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" className="bg-white/5 border-white/10 text-gray-300 hover:bg-white/10" onClick={() => setDialogOpen(false)}>Отмена</Button>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white" onClick={() => { setDialogOpen(false); toast.success('Правило создано'); }}>
              Создать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageWrapper>
  );
}

export default AutomationPage;