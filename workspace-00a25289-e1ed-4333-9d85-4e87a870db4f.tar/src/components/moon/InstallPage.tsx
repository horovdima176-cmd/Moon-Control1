'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Download, Globe, Server, Moon, Terminal, ChevronDown, ChevronRight,
  ExternalLink, CheckCircle2, AlertCircle, Copy, Check, Zap, Shield,
  Cloud, Monitor, Smartphone, ArrowRight, Package, Database,
  FileCode, Plug, Rocket, Star, CircleDollarSign, Gift, Crown,
  Container, HardDrive, Cpu, Wifi, Gamepad2
} from 'lucide-react';
import { GlassCard, PageWrapper, SectionHeader } from './helpers';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

// ─── COLLAPSIBLE STEP ────────────────────────────────────────────────────

function Step({ number, title, children, defaultOpen = false }: {
  number: number; title: string; children: React.ReactNode; defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="group">
      <CollapsibleTrigger className="w-full text-left">
        <div className="flex items-center gap-3 p-4 rounded-xl hover:bg-white/[0.03] transition-colors cursor-pointer">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
            <span className="text-blue-400 font-mono text-sm font-bold">{number}</span>
          </div>
          <span className="text-gray-200 font-medium text-sm flex-1">{title}</span>
          {open ? <ChevronDown className="w-4 h-4 text-gray-500" /> : <ChevronRight className="w-4 h-4 text-gray-500" />}
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="pb-4 pl-14 pr-4">
          {children}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

// ─── CODE BLOCK ──────────────────────────────────────────────────────────

function CodeBlock({ code, lang = 'bash' }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    toast.success('Скопировано в буфер обмена');
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="relative group rounded-lg overflow-hidden">
      <div className="absolute top-2 right-2 z-10">
        <Button
          variant="ghost" size="icon"
          className="w-7 h-7 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-gray-200 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={handleCopy}
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
        </Button>
      </div>
      <div className="bg-[#0D1117] border border-white/[0.06] rounded-lg p-4 font-mono text-[12.5px] leading-relaxed overflow-x-auto">
        <div className="text-gray-500 text-[10px] mb-2 uppercase tracking-wider">{lang}</div>
        <pre className="text-gray-300 whitespace-pre">{code}</pre>
      </div>
    </div>
  );
}

// ─── HOSTING CARD ────────────────────────────────────────────────────────

function HostingCard({ name, price, priceNote, url, pros, cons, badge, recommended }: {
  name: string; price: string; priceNote?: string; url: string;
  pros: string[]; cons?: string[]; badge?: string; recommended?: boolean;
}) {
  return (
    <GlassCard className={`p-5 relative ${recommended ? 'ring-1 ring-emerald-500/30' : ''}`}>
      {recommended && (
        <Badge className="absolute -top-2.5 right-4 bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-[10px] gap-1">
          <Star className="w-3 h-3" /> Рекомендуем
        </Badge>
      )}
      {badge && !recommended && (
        <Badge variant="outline" className="absolute -top-2.5 right-4 border-white/10 text-gray-400 text-[10px]">
          {badge}
        </Badge>
      )}
      <div className="flex items-start justify-between mb-3">
        <div>
          <h4 className="text-gray-100 font-semibold text-sm">{name}</h4>
          {priceNote && <p className="text-gray-500 text-xs mt-0.5">{priceNote}</p>}
        </div>
        <div className="text-right">
          <div className="text-emerald-400 font-bold text-lg">{price}</div>
        </div>
      </div>
      <div className="space-y-1.5 mb-4">
        {pros.map((p, i) => (
          <div key={i} className="flex items-start gap-2 text-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
            <span className="text-gray-300">{p}</span>
          </div>
        ))}
        {cons?.map((c, i) => (
          <div key={i} className="flex items-start gap-2 text-xs">
            <AlertCircle className="w-3.5 h-3.5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <span className="text-gray-500">{c}</span>
          </div>
        ))}
      </div>
      <a href={url} target="_blank" rel="noopener noreferrer">
        <Button variant="outline" size="sm" className="w-full border-white/10 text-gray-300 hover:bg-white/5 hover:text-gray-100 text-xs gap-2">
          Перейти <ExternalLink className="w-3 h-3" />
        </Button>
      </a>
    </GlassCard>
  );
}

// ─── DOWNLOAD ITEM ───────────────────────────────────────────────────────

function DownloadItem({ name, version, url, desc, size }: {
  name: string; version: string; url: string; desc: string; size?: string;
}) {
  return (
    <div className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/[0.03] transition-colors group">
      <div className="w-10 h-10 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0">
        <Package className="w-5 h-5 text-blue-400" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-gray-200 text-sm font-medium">{name}</span>
          <Badge variant="outline" className="text-[9px] px-1.5 py-0 border-white/10 text-gray-500">{version}</Badge>
          {size && <span className="text-gray-600 text-[10px]">{size}</span>}
        </div>
        <p className="text-gray-500 text-xs mt-0.5 truncate">{desc}</p>
      </div>
      <a href={url} target="_blank" rel="noopener noreferrer">
        <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 text-xs gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
          <Download className="w-3.5 h-3.5" /> Скачать
        </Button>
      </a>
    </div>
  );
}

// ─── MAIN PAGE ───────────────────────────────────────────────────────────

export default function InstallPage() {
  return (
    <PageWrapper>
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
        <SectionHeader
          title="Установка"
          description="Полное руководство по установке и развертыванию Moon Control"
        />

        {/* ── SYSTEM REQUIREMENTS ──────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blue-400" /> Системные требования
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <GlassCard className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Monitor className="w-4 h-4 text-blue-400" />
                <span className="text-gray-300 text-xs font-medium">Компьютер</span>
              </div>
              <ul className="text-[11px] text-gray-400 space-y-1">
                <li>• ОС: Windows 10/11</li>
                <li>• RAM: 4 ГБ+ (рек. 8 ГБ)</li>
                <li>• Диск: 500 МБ свободного места</li>
                <li>• Интернет-соединение</li>
              </ul>
            </GlassCard>
            <GlassCard className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Gamepad2 className="w-4 h-4 text-emerald-400" />
                <span className="text-gray-300 text-xs font-medium">Для агента</span>
              </div>
              <ul className="text-[11px] text-gray-400 space-y-1">
                <li>• GTA V (Steam / Epic / Rockstar)</li>
                <li>• MoonLoader (последняя версия)</li>
                <li>• SAMPFUNCS / SAMP.lua</li>
                <li>• Working chat (RP сервер)</li>
              </ul>
            </GlassCard>
            <GlassCard className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Server className="w-4 h-4 text-purple-400" />
                <span className="text-gray-300 text-xs font-medium">Для сервера</span>
              </div>
              <ul className="text-[11px] text-gray-400 space-y-1">
                <li>• Node.js 18+ или Bun 1.0+</li>
                <li>• Git</li>
                <li>• Telegram Bot Token (опционально)</li>
                <li>• Или хостинг (см. ниже)</li>
              </ul>
            </GlassCard>
          </div>
        </div>

        {/* ── DOWNLOADS ────────────────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <Download className="w-4 h-4 text-blue-400" /> Что нужно скачать
          </h3>
          <GlassCard className="divide-y divide-white/[0.04]">
            <DownloadItem
              name="Node.js" version="20 LTS"
              url="https://nodejs.org/ru/download"
              desc="JavaScript runtime — нужен для запуска сервера Moon Control"
              size="~30 МБ"
            />
            <DownloadItem
              name="Bun" version="1.x"
              url="https://bun.sh/"
              desc="Быстрый JavaScript runtime (альтернатива Node.js, работает быстрее)"
              size="~80 МБ"
            />
            <DownloadItem
              name="Git" version="2.x"
              url="https://git-scm.com/download/win"
              desc="Система контроля версий для клонирования проекта"
              size="~60 МБ"
            />
            <DownloadItem
              name="MoonLoader" version="0.27+"
              url="https://www.blast.hk/threads/133506/"
              desc="Загрузчик Lua-скриптов для GTA V (SAMP/CRMP)"
              size="~2 МБ"
            />
            <DownloadItem
              name="SAMPFUNCS" version="5.x"
              url="https://www.blast.hk/threads/17/"
              desc="Библиотека функций SAMP для MoonLoader"
              size="~1 МБ"
            />
          </GlassCard>
        </div>

        {/* ── INSTALLATION STEPS ───────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <Rocket className="w-4 h-4 text-blue-400" /> Пошаговая установка
          </h3>
          <GlassCard className="p-2">
            <Step number={1} title="Установить Node.js и Git" defaultOpen>
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Скачайте и установите Node.js (LTS версию) с официального сайта. Проверьте установку:
                </p>
                <CodeBlock code={`node --version   # v20.x.x\nnpm --version    # 10.x.x\ngit --version    # 2.x.x`} />
                <div className="flex items-start gap-2 bg-yellow-500/5 border border-yellow-500/10 rounded-lg p-3">
                  <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                  <p className="text-yellow-300/80 text-[11px]">
                    Альтернатива: установите <a href="https://bun.sh/" className="underline text-yellow-300">Bun</a> вместо Node.js — он работает быстрее и не требует отдельной установки npm.
                  </p>
                </div>
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={2} title="Клонировать Moon Control">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Склонируйте репозиторий проекта и установите зависимости:
                </p>
                <CodeBlock code={`git clone https://github.com/your-username/moon-control.git\ncd moon-control\n\n# Если используете npm:\nnpm install\n\n# Если используете Bun (рекомендуется):\nbun install`} />
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={3} title="Инициализировать базу данных">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Создайте файл <code className="bg-white/5 px-1.5 py-0.5 rounded text-gray-300">.env</code> в корне проекта:
                </p>
                <CodeBlock code={`DATABASE_URL="file:./db/custom.db"`} />
                <p className="text-gray-400 text-xs leading-relaxed mt-2">Затем выполните миграцию и заполните базу тестовыми данными:</p>
                <CodeBlock code={`# Применить схему базы данных\nbun run db:push\n\n# Запустить сервер разработки\nbun run dev\n\n# В браузере откройте и нажмите кнопку "Загрузить демо-данные"\n# или отправьте POST запрос:\ncurl -X POST http://localhost:3000/api/seed`} />
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={4} title="Установить Lua Agent в MoonLoader">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Скопируйте файл агента в папку скриптов MoonLoader:
                </p>
                <CodeBlock code={`# Путь к папке скриптов MoonLoader (обычно):\n# GTA V/moonloader/\n\n# Скопировать агент:\ncp agent/MoonAgent.lua "C:/Games/GTA V/moonloader/MoonAgent.lua"`} />
                <p className="text-gray-400 text-xs leading-relaxed">
                  Или просто скопируйте файл <code className="bg-white/5 px-1.5 py-0.5 rounded text-gray-300">MoonAgent.lua</code> вручную в папку <code className="bg-white/5 px-1.5 py-0.5 rounded text-gray-300">moonloader/</code> внутри директории GTA V.
                </p>
                <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/10 rounded-lg p-3">
                  <Zap className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <p className="text-blue-300/80 text-[11px]">
                    Файл агента можно скачать прямо из раздела «Агент» в Moon Control (кнопка «Скачать скрипт»), или найти в папке <code className="bg-white/5 px-1 rounded">agent/</code> проекта.
                  </p>
                </div>
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={5} title="Запустить WebSocket мост">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  WebSocket-мост нужен для связи между Lua Agent и веб-панелью:
                </p>
                <CodeBlock code={`# Установить зависимости моста\ncd mini-services/ws-bridge\nbun install\n\n# Запустить мост\nbun run dev\n\n# Мост запустится на порту 8765 (WebSocket) и 8766 (HTTP статус)`} />
                <p className="text-gray-400 text-xs leading-relaxed">
                  Lua Agent подключается к <code className="bg-white/5 px-1.5 py-0.5 rounded text-gray-300">ws://127.0.0.1:8765</code> автоматически.
                </p>
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={6} title="Настроить Telegram (опционально)">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Для удалённых уведомлений и управления через Telegram:
                </p>
                <ol className="text-xs text-gray-400 space-y-2 list-decimal list-inside">
                  <li>Откройте <a href="https://t.me/BotFather" className="text-blue-400 underline" target="_blank" rel="noopener noreferrer">@BotFather</a> в Telegram</li>
                  <li>Отправьте <code className="bg-white/5 px-1.5 py-0.5 rounded text-gray-300">/newbot</code> и следуйте инструкциям</li>
                  <li>Скопируйте полученный <strong className="text-gray-300">Bot Token</strong></li>
                  <li>Напишите боту и отправьте любое сообщение</li>
                  <li>Перейдите на <code className="bg-white/5 px-1.5 py-0.5 rounded text-gray-300">https://api.telegram.org/bot&lt;TOKEN&gt;/getUpdates</code></li>
                  <li>Найдите <strong className="text-gray-300">chat.id</strong> в ответе</li>
                  <li>В Moon Control: раздел «Telegram» → введите Token и Chat ID</li>
                </ol>
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={7} title="Запустить всё и проверить">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Запустите все компоненты в правильном порядке:
                </p>
                <CodeBlock code={`# Терминал 1 — WebSocket мост\ncd moon-control/mini-services/ws-bridge\nbun run dev\n\n# Терминал 2 — Moon Control (веб-панель)\ncd moon-control\nbun run dev\n\n# Терминал 3 — (опционально) Запустите GTA V с MoonLoader\n# Агент подключится автоматически`} />
                <div className="flex items-start gap-2 bg-emerald-500/5 border border-emerald-500/10 rounded-lg p-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                  <p className="text-emerald-300/80 text-[11px]">
                    Откройте <code className="bg-white/5 px-1 rounded">http://localhost:3000</code> в браузере. На дашборде должны отображаться статусы всех компонентов.
                  </p>
                </div>
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={8} title="Игровые команды агента">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  В игре доступны следующие чат-команды для управления агентом:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { cmd: '/moon', desc: 'Показать статус подключения' },
                    { cmd: '/moontest', desc: 'Отправить тестовый триггер' },
                    { cmd: '/moondebug', desc: 'Включить/выключить отладку' },
                    { cmd: '/moonreconnect', desc: 'Переподключиться к серверу' },
                    { cmd: '/moonlog', desc: 'Показать последние события' },
                    { cmd: '/moonqueue', desc: 'Показать очередь событий' },
                  ].map(item => (
                    <div key={item.cmd} className="flex items-center gap-2 bg-white/[0.02] rounded-lg px-3 py-2">
                      <code className="text-blue-400 text-xs font-mono">{item.cmd}</code>
                      <span className="text-gray-500 text-[11px]">— {item.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            </Step>
          </GlassCard>
        </div>

        {/* ── PROJECT STRUCTURE ─────────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <FileCode className="w-4 h-4 text-blue-400" /> Структура проекта
          </h3>
          <GlassCard className="p-4">
            <pre className="font-mono text-[11px] text-gray-400 leading-relaxed overflow-x-auto">
{`moon-control/
├── src/                        # Веб-панель (Next.js)
│   ├── app/
│   │   ├── api/                # API маршруты
│   │   ├── page.tsx            # Главная страница
│   │   └── layout.tsx          # Корневой layout
│   ├── components/
│   │   ├── moon/               # Компоненты Moon Control
│   │   └── ui/                 # shadcn/ui компоненты
│   └── lib/
│       ├── db.ts               # Prisma клиент
│       └── utils.ts
├── agent/
│   └── MoonAgent.lua           # ⭐ Lua-скрипт агента
├── mini-services/
│   └── ws-bridge/              # WebSocket мост
│       ├── index.ts
│       └── package.json
├── prisma/
│   └── schema.prisma           # Схема базы данных
├── db/
│   └── custom.db               # SQLite база данных
├── public/                     # Статические файлы
├── package.json
└── worklog.md                  # Журнал разработки`}
            </pre>
          </GlassCard>
        </div>

        {/* ── ARCHITECTURE DIAGRAM ──────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <Plug className="w-4 h-4 text-blue-400" /> Как всё связано
          </h3>
          <GlassCard className="p-5">
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-purple-500/10 border border-purple-500/20">
                <Gamepad2 className="w-4 h-4 text-purple-400" />
                <span className="text-purple-300 text-xs font-medium">GTA V + MoonLoader</span>
              </div>
              <div className="flex flex-col items-center text-gray-600">
                <div className="w-px h-4 bg-gray-700" />
                <span className="text-[9px] text-gray-600 bg-[#0D1117] px-1.5">WebSocket :8765</span>
                <div className="w-px h-4 bg-gray-700" />
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <Moon className="w-4 h-4 text-blue-400" />
                <span className="text-blue-300 text-xs font-medium">MoonAgent.lua</span>
              </div>
              <div className="flex flex-col items-center text-gray-600">
                <div className="w-px h-4 bg-gray-700" />
                <span className="text-[9px] text-gray-600 bg-[#0D1117] px-1.5">События JSON</span>
                <div className="w-px h-4 bg-gray-700" />
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <Wifi className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-300 text-xs font-medium">WS Bridge (Bun)</span>
              </div>
              <div className="flex flex-col items-center text-gray-600">
                <div className="w-px h-4 bg-gray-700" />
                <span className="text-[9px] text-gray-600 bg-[#0D1117] px-1.5">HTTP API :3000</span>
                <div className="w-px h-4 bg-gray-700" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <Globe className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-blue-300 text-[11px]">Веб-панель</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <Database className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-blue-300 text-[11px]">SQLite</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <Smartphone className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-blue-300 text-[11px]">Telegram</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <Terminal className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-blue-300 text-[11px]">API</span>
                </div>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* ── HOSTING ──────────────────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-1 flex items-center gap-2">
            <Cloud className="w-4 h-4 text-blue-400" /> Хостинг — куда загрузить сервер
          </h3>
          <p className="text-gray-500 text-xs mb-4">
            Чтобы открыть Moon Control с любого устройства, нужен сервер в интернете. Вот лучшие варианты до ~100₽/мес:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <HostingCard
              name="Oracle Cloud Free Tier"
              price="Бесплатно"
              priceNote="Навсегда, без кредитной карты"
              url="https://cloud.oracle.com/free"
              recommended
              pros={[
                '4 ARM ядра, 24 ГБ RAM — полностью бесплатно',
                '1 ГБ диска + до 200 ГБ объектного хранилища',
                'Постоянно включён (не засыпает)',
                'Ubuntu 22.04/24.04 — идеален для Node.js',
                'Можно поставить Docker + Bun + всё что нужно',
              ]}
              cons={[
                'Регистрация может занять время (верификация)',
                'Иногда нет свободных серверов в регионе — нужно пробовать разные',
              ]}
            />
            <HostingCard
              name="Google Cloud Free Tier"
              price="Бесплатно"
              priceNote="e2-micro, 1 ГБ RAM"
              url="https://cloud.google.com/free"
              badge="Always Free"
              pros={[
                'e2-micro инстанс — бесплатно навсегда',
                '1 ГБ RAM, 30 ГБ диска',
                'Постоянно включён',
                'Легко деплоить через Google Cloud Shell',
              ]}
              cons={[
                'Нужна кредитная карта для верификации (списывают и возвращают $1)',
                'Мало RAM (1 ГБ) — SQLite будет работать, но плотно',
              ]}
            />
            <HostingCard
              name="Render.com"
              price="Бесплатно"
              priceNote="750 часов/мес"
              url="https://render.com"
              badge="Serverless"
              pros={[
                'Автоматический деплой из Git',
                'Бесплатный план с 512 MB RAM',
                'Легко настроить за 5 минут',
                'Не нужна кредитная карта',
              ]}
              cons={[
                'Засыпает после 15 мин неактивности (холодный старт ~30 сек)',
                'SQLite не подходит — нужна внешняя БД',
                'Ограничение 750 часов/мес',
              ]}
            />
            <HostingCard
              name="Railway.app"
              price="Бесплатно"
              priceNote="$5 кредит/мес"
              url="https://railway.app"
              badge="Dev Platform"
              pros={[
                '$5 бесплатного кредита каждый месяц',
                'Docker-деплой, автодеплой из Git',
                'Private networking между сервисами',
                'Удобный дашборд',
              ]}
              cons={[
                'Кредит заканчивается — сервис останавливается',
                'Не для production 24/7 на бесплатном плане',
              ]}
            />
            <HostingCard
              name="Аэза (Aéza)"
              price="~99₽/мес"
              priceNote="VPS 1 vCPU, 1 ГБ RAM"
              url="https://aeza.ru"
              pros={[
                'Российский хостинг — низкий пинг из РФ',
                'От 99₽/мес за базовый VPS',
                'Мгновенное развертывание',
                'Оплата картой, криптой, ЮMoney',
              ]}
              cons={[
                'Платный (но дёшево)',
                'Нужна регистрация',
              ]}
            />
            <HostingCard
              name="Timeweb Cloud"
              price="~199₽/мес"
              priceNote="VPS 1 vCPU, 1 ГБ RAM"
              url="https://timeweb.com"
              badge="Надёжный"
              pros={[
                'Популярный российский хостинг',
                'Хорошая техподдержка на русском',
                'Удобная панель управления',
                'Бэкапы включены',
              ]}
              cons={[
                'Дороже (199₽/мес за базовый)',
                'Немного выше бюджета',
              ]}
            />
          </div>

          {/* Hosting Recommendation */}
          <GlassCard className="p-5 border-emerald-500/20 bg-emerald-500/[0.03]">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center flex-shrink-0">
                <Crown className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h4 className="text-gray-100 font-semibold text-sm mb-1">Рекомендация: Oracle Cloud Free Tier</h4>
                <p className="text-gray-400 text-xs leading-relaxed mb-3">
                  Это лучший вариант — <strong className="text-gray-300">полностью бесплатно, навсегда</strong>, с отличными характеристиками (4 ядра, 24 ГБ RAM).
                  Единственная сложность — регистрация. Если Oracle не подходит, берите <strong className="text-gray-300">Аэза за 99₽/мес</strong> —
                  это российский VPS с низким пингом.
                </p>
                <div className="flex items-center gap-2 text-[11px]">
                  <Badge variant="outline" className="border-white/10 text-gray-400 gap-1">
                    <Gift className="w-3 h-3" /> Бесплатно
                  </Badge>
                  <Badge variant="outline" className="border-white/10 text-gray-400 gap-1">
                    <Shield className="w-3 h-3" /> Надёжно
                  </Badge>
                  <Badge variant="outline" className="border-white/10 text-gray-400 gap-1">
                    <Rocket className="w-3 h-3" /> Быстро
                  </Badge>
                </div>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* ── DEPLOY TO HOSTING ────────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <Container className="w-4 h-4 text-blue-400" /> Развертывание на сервере (VPS)
          </h3>
          <GlassCard className="p-2">
            <Step number={1} title="Подготовить сервер">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Подключитесь к VPS по SSH и установите зависимости:
                </p>
                <CodeBlock code={`# Обновить систему\nsudo apt update && sudo apt upgrade -y\n\n# Установить Node.js 20\ncurl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -\nsudo apt install -y nodejs\n\n# Или установить Bun (рекомендуется)\ncurl -fsSL https://bun.sh/install | bash\n\n# Установить Git\nsudo apt install -y git\n\n# Установить PM2 для автозапуска\nnpm install -g pm2`} />
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={2} title="Загрузить проект">
              <div className="space-y-3">
                <CodeBlock code={`# Клонировать проект\ngit clone https://github.com/your-username/moon-control.git\ncd moon-control\n\n# Установить зависимости\nbun install  # или npm install\n\n# Инициализировать БД\nbun run db:push\n\n# Загрузить демо-данные\nbun run dev &\nsleep 10\ncurl -X POST http://localhost:3000/api/seed\npkill -f "next dev"`} />
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={3} title="Настроить автозапуск">
              <div className="space-y-3">
                <CodeBlock code={`# Запустить WebSocket мост через PM2\ncd mini-services/ws-bridge\npm install\npm start\n\n# Вернуться в корень и запустить Moon Control\ncd ../..\npm run build\npm start\n\n# Или через PM2:\npm2 start npm --name "moon-control" -- start\npm2 start npm --name "ws-bridge" -- start --prefix mini-services/ws-bridge\npm2 save\npm2 startup  # автозапуск при перезагрузке`} />
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={4} title="Настроить домен (опционально)">
              <div className="space-y-3">
                <p className="text-gray-400 text-xs leading-relaxed">
                  Если у вас есть домен, настройте его на IP сервера и установите Nginx + SSL:
                </p>
                <CodeBlock code={`sudo apt install -y nginx certbot python3-certbot-nginx\n\n# Настроить Nginx\nsudo nano /etc/nginx/sites-available/moon-control\n\n# Содержимое конфига:\n# server {\n#     listen 80;\n#     server_name your-domain.com;\n#     location / {\n#         proxy_pass http://127.0.0.1:3000;\n#         proxy_http_version 1.1;\n#         proxy_set_header Upgrade $http_upgrade;\n#         proxy_set_header Connection "upgrade";\n#         proxy_set_header Host $host;\n#     }\n# }\n\nsudo ln -s /etc/nginx/sites-available/moon-control /etc/nginx/sites-enabled/\nsudo certbot --nginx -d your-domain.com`} />
              </div>
            </Step>

            <Separator className="bg-white/[0.04] mx-4" />

            <Step number={5} title="Открыть порты в фаерволе">
              <div className="space-y-3">
                <CodeBlock code={`# Открыть порты для веб-панели и WebSocket\nsudo ufw allow 80/tcp\nsudo ufw allow 443/tcp\nsudo ufw allow 8765/tcp   # WebSocket для Lua Agent\nsudo ufw allow 8766/tcp   # HTTP статус агента\nsudo ufw enable\n\n# Проверить\nsudo ufw status`} />
                <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/10 rounded-lg p-3">
                  <Zap className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <p className="text-blue-300/80 text-[11px]">
                    Если используете Oracle Cloud, также откройте порты в <strong>Network Security Lists</strong> в консоли OCI (порт 80, 443, 8765).
                  </p>
                </div>
              </div>
            </Step>
          </GlassCard>
        </div>

        {/* ── PORTS TABLE ───────────────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <Wifi className="w-4 h-4 text-blue-400" /> Порты и сервисы
          </h3>
          <GlassCard className="overflow-hidden">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  <th className="text-left p-3 text-gray-400 font-medium">Порт</th>
                  <th className="text-left p-3 text-gray-400 font-medium">Сервис</th>
                  <th className="text-left p-3 text-gray-400 font-medium">Протокол</th>
                  <th className="text-left p-3 text-gray-400 font-medium">Описание</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {[
                  ['3000', 'Moon Control', 'HTTP', 'Веб-панель и API'],
                  ['8765', 'WS Bridge', 'WebSocket', 'Связь с Lua Agent'],
                  ['8766', 'WS Bridge', 'HTTP', 'Статус агента (JSON)'],
                ].map(([port, service, proto, desc]) => (
                  <tr key={port} className="hover:bg-white/[0.02]">
                    <td className="p-3"><code className="text-blue-400 font-mono">{port}</code></td>
                    <td className="p-3 text-gray-300">{service}</td>
                    <td className="p-3"><Badge variant="outline" className="text-[9px] px-1.5 py-0 border-white/10 text-gray-500">{proto}</Badge></td>
                    <td className="p-3 text-gray-400">{desc}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </GlassCard>
        </div>

        {/* ── TROUBLESHOOTING ───────────────────────────────────────── */}
        <div className="mb-8">
          <h3 className="text-gray-200 font-semibold text-sm mb-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-yellow-400" /> Частые проблемы
          </h3>
          <GlassCard className="divide-y divide-white/[0.04]">
            {[
              {
                q: 'Lua Agent не подключается к WebSocket',
                a: 'Убедитесь что WS Bridge запущен (порт 8765). Проверьте в игре командой /moon. Если показывает DISCONNECTED — проверьте что мост запущен и порт не занят.',
              },
              {
                q: 'Веб-панель не открывается',
                a: 'Проверьте что сервер запущен: pm2 status. Проверьте порты: ss -tlnp | grep 3000. Проверьте фаервол: sudo ufw status.',
              },
              {
                q: 'Telegram не отправляет уведомления',
                a: 'Проверьте Bot Token и Chat ID. Нажмите «Тест» в разделе Telegram. Убедитесь что бот добавлен в чат и имеет права на отправку сообщений.',
              },
              {
                q: 'База данных пустая после деплоя',
                a: 'Запустите: curl -X POST http://localhost:3000/api/seed. Убедитесь что файл .env содержит DATABASE_URL="file:./db/custom.db".',
              },
              {
                q: 'Oracle Cloud — нет свободных серверов',
                a: 'Попробуйте изменить регион (US, EU, AP). Или подождите и попробуйте позже — серверы освобождаются. Можно также попробовать Google Cloud Free Tier.',
              },
            ].map((item, i) => (
              <Step key={i} number={i + 1} title={item.q}>
                <p className="text-gray-400 text-xs leading-relaxed">{item.a}</p>
              </Step>
            ))}
          </GlassCard>
        </div>

      </motion.div>
    </PageWrapper>
  );
}