'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Send, Bell, Eye, Play } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function TelegramPage() {
  const queryClient = useQueryClient();
  const [showToken, setShowToken] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  const { data: telegramData } = useQuery({
    queryKey: ['telegram'],
    queryFn: () => fetch('/api/telegram').then(r => r.json()).catch(() => null),
  });

  const botToken = telegramData?.botToken || '';
  const chatId = telegramData?.chatId || '';
  const ownerName = telegramData?.ownerName || '';
  const notifications = telegramData?.notifications || {
    triggers: true, errors: true, startup: true, shutdown: true, reconnect: true, logs: false, screenshots: false,
  };
  const monitorOnly = telegramData?.monitorOnly || false;

  const [localToken, setLocalToken] = useState('');
  const [localChatId, setLocalChatId] = useState('');
  const [localOwnerName, setLocalOwnerName] = useState('');
  const [localNotifications, setLocalNotifications] = useState(notifications);
  const [localMonitorOnly, setLocalMonitorOnly] = useState(monitorOnly);

  const saveMutation = useMutation({
    mutationFn: (data: Record<string, unknown>) =>
      fetch('/api/telegram', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['telegram'] }); toast.success('Настройки Telegram сохранены'); },
  });

  const handleTest = () => {
    setTestResult(null);
    fetch('/api/telegram/test', { method: 'POST' })
      .then(r => r.json())
      .then(d => { setTestResult('success'); toast.success('Тестовое сообщение отправлено'); })
      .catch(() => { setTestResult('error'); toast.error('Ошибка отправки тестового сообщения'); });
  };

  const handleSave = () => {
    saveMutation.mutate({ botToken: localToken, chatId: localChatId, ownerName: localOwnerName, notifications: localNotifications, monitorOnly: localMonitorOnly });
  };

  return (
    <PageWrapper>
      <SectionHeader title="Telegram" description="Настройка Telegram бота и уведомлений" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Connection */}
        <GlassCard className="p-5">
          <h3 className="text-sm font-medium text-gray-200 mb-4 flex items-center gap-2">
            <Send className="w-4 h-4 text-blue-400" /> Подключение
          </h3>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Bot Token</Label>
              <div className="relative">
                <Input
                  type={showToken ? 'text' : 'password'}
                  value={localToken}
                  onChange={e => setLocalToken(e.target.value)}
                  placeholder="123456:ABC-DEF..."
                  className="bg-[#0D1117] border-white/10 text-gray-200 pr-10 font-mono text-sm"
                />
                <button className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300" onClick={() => setShowToken(!showToken)}>
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Chat ID</Label>
              <Input value={localChatId} onChange={e => setLocalChatId(e.target.value)} placeholder="-100123456789" className="bg-[#0D1117] border-white/10 text-gray-200 font-mono text-sm" />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Имя владельца</Label>
              <Input value={localOwnerName} onChange={e => setLocalOwnerName(e.target.value)} placeholder="Username" className="bg-[#0D1117] border-white/10 text-gray-200" />
            </div>
            <div className="flex items-center gap-2 pt-2">
              <div className="flex items-center gap-2 mr-auto">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs text-emerald-400">Подключён</span>
              </div>
              <Button size="sm" variant="ghost" className="text-xs text-gray-400 h-8" onClick={handleTest}>
                <Play className="w-3.5 h-3.5 mr-1.5" /> Тест
              </Button>
              <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white text-xs h-8" onClick={handleSave}>
                Сохранить
              </Button>
            </div>
            {testResult && (
              <div className={`text-xs p-2 rounded-lg ${testResult === 'success' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                {testResult === 'success' ? '✅ Сообщение отправлено успешно' : '❌ Ошибка отправки сообщения'}
              </div>
            )}
          </div>
        </GlassCard>

        {/* Notifications */}
        <GlassCard className="p-5">
          <h3 className="text-sm font-medium text-gray-200 mb-4 flex items-center gap-2">
            <Bell className="w-4 h-4 text-yellow-400" /> Уведомления
          </h3>
          <div className="space-y-3">
            {[
              { key: 'triggers', label: 'Триггеры', desc: 'Уведомления о срабатывании триггеров' },
              { key: 'errors', label: 'Ошибки', desc: 'Критические ошибки системы' },
              { key: 'startup', label: 'Запуск', desc: 'Уведомление при запуске системы' },
              { key: 'shutdown', label: 'Остановка', desc: 'Уведомление при остановке системы' },
              { key: 'reconnect', label: 'Переподключение', desc: 'События подключения/отключения' },
              { key: 'logs', label: 'Логи', desc: 'Все лог-сообщения (много)' },
              { key: 'screenshots', label: 'Скриншоты', desc: 'Автоматические скриншоты (скоро)' },
            ].map(item => (
              <div key={item.key} className="flex items-center justify-between py-1">
                <div>
                  <div className="text-sm text-gray-200">{item.label}</div>
                  <div className="text-[11px] text-gray-500">{item.desc}</div>
                </div>
                <Switch
                  checked={localNotifications[item.key as keyof typeof localNotifications]}
                  onCheckedChange={v => setLocalNotifications(prev => ({ ...prev, [item.key]: v }))}
                  disabled={item.key === 'screenshots'}
                />
              </div>
            ))}
          </div>
          <Separator className="my-4 bg-white/[0.06]" />
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-200">Режим мониторинга</div>
              <div className="text-[11px] text-gray-500">Только получение, без отправки</div>
            </div>
            <Switch checked={localMonitorOnly} onCheckedChange={setLocalMonitorOnly} />
          </div>
        </GlassCard>
      </div>
    </PageWrapper>
  );
}

export default TelegramPage;