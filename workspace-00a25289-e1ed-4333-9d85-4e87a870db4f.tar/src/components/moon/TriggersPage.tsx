'use client';

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Zap, Plus, Pencil, Trash2, Search, X } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { MATCH_TYPES, MOCK_TRIGGERS } from './constants';
import type { TriggerItem } from './types';
import { PageWrapper, SectionHeader, GlassCard, EmptyState } from './helpers';

function TriggersPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingTrigger, setEditingTrigger] = useState<TriggerItem | null>(null);
  const [form, setForm] = useState<Partial<TriggerItem>>({});

  const { data: triggersData, isLoading } = useQuery({
    queryKey: ['triggers'],
    queryFn: () => fetch('/api/triggers').then(r => r.json()).catch(() => null),
  });

  const saveMutation = useMutation({
    mutationFn: (data: Partial<TriggerItem>) =>
      fetch(editingTrigger ? `/api/triggers/${editingTrigger.id}` : '/api/triggers', {
        method: editingTrigger ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['triggers'] }); setEditorOpen(false); toast.success(editingTrigger ? 'Триггер обновлён' : 'Триггер создан'); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => fetch(`/api/triggers/${id}`, { method: 'DELETE' }).then(r => r.json()),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['triggers'] }); toast.success('Триггер удалён'); },
  });

  const triggers = triggersData?.triggers || MOCK_TRIGGERS;

  const filtered = triggers.filter((t: TriggerItem) =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.triggerText.toLowerCase().includes(search.toLowerCase()) ||
    t.group.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditingTrigger(null);
    setForm({ name: '', triggerText: '', matchType: 'Contains', priority: 1, cooldown: 0, enabled: true, caseSensitive: false, wholeWord: false, description: '', group: '' });
    setEditorOpen(true);
  };

  const openEdit = (t: TriggerItem) => {
    setEditingTrigger(t);
    setForm(t);
    setEditorOpen(true);
  };

  return (
    <PageWrapper>
      <SectionHeader title="Триггеры" description="Управление триггерами сообщений" action={
        <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white text-xs h-8" onClick={openCreate}>
          <Plus className="w-3.5 h-3.5 mr-1.5" /> Добавить триггер
        </Button>
      } />

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Поиск по триггерам..."
          className="pl-10 bg-[#0D1117] border-white/10 text-gray-200 placeholder:text-gray-500 h-9"
        />
        {search && (
          <button className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300" onClick={() => setSearch('')}>
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 bg-white/5 rounded-lg" />)}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState icon={Zap} title="Триггеры не найдены" description={search ? 'Попробуйте изменить поисковый запрос' : 'Создайте первый триггер'} />
      ) : (
        <GlassCard className="overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-white/[0.06] hover:bg-transparent">
                  <TableHead className="text-gray-400 text-xs font-medium">Название</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium">Текст</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium hidden md:table-cell">Тип</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium hidden lg:table-cell">Группа</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium hidden lg:table-cell">Приоритет</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium hidden xl:table-cell">КД</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium">Статус</TableHead>
                  <TableHead className="text-gray-400 text-xs font-medium w-[100px]">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((t: TriggerItem) => (
                  <TableRow key={t.id} className="border-white/[0.04] hover:bg-white/[0.02] transition-colors">
                    <TableCell className="text-gray-200 text-sm font-medium">{t.name}</TableCell>
                    <TableCell className="text-gray-400 text-sm font-mono text-xs max-w-[200px] truncate">{t.triggerText}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <Badge className="text-[10px] px-1.5 py-0 bg-white/5 text-gray-400 border-0">{t.matchType}</Badge>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      {t.group && <Badge className="text-[10px] px-1.5 py-0 bg-purple-500/20 text-purple-400 border-0">{t.group}</Badge>}
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-gray-400 text-xs">{t.priority}</TableCell>
                    <TableCell className="hidden xl:table-cell text-gray-400 text-xs">{t.cooldown > 0 ? `${t.cooldown}с` : '—'}</TableCell>
                    <TableCell>
                      <Badge className={`text-[10px] px-1.5 py-0 border-0 ${t.enabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-500'}`}>
                        {t.enabled ? 'Вкл' : 'Выкл'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-0.5">
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-gray-500 hover:text-blue-400" onClick={() => openEdit(t)}>
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-gray-500 hover:text-red-400" onClick={() => deleteMutation.mutate(t.id)}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </GlassCard>
      )}

      {/* Editor Dialog */}
      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        <DialogContent className="bg-[#1E2530] border-white/10 text-gray-200 max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-gray-100">{editingTrigger ? 'Редактировать триггер' : 'Новый триггер'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Название</Label>
              <Input value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Название триггера" className="bg-[#0D1117] border-white/10 text-gray-200" />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Текст триггера</Label>
              <Input value={form.triggerText || ''} onChange={e => setForm({ ...form, triggerText: e.target.value })} placeholder="Текст для сопоставления" className="bg-[#0D1117] border-white/10 text-gray-200 font-mono" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300 text-sm">Тип сопоставления</Label>
                <Select value={form.matchType} onValueChange={v => setForm({ ...form, matchType: v })}>
                  <SelectTrigger className="bg-[#0D1117] border-white/10 text-gray-200"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1E2530] border-white/10">
                    {MATCH_TYPES.map(mt => <SelectItem key={mt} value={mt} className="text-gray-200">{mt}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300 text-sm">Группа</Label>
                <Input value={form.group || ''} onChange={e => setForm({ ...form, group: e.target.value })} placeholder="Группа" className="bg-[#0D1117] border-white/10 text-gray-200" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300 text-sm">Приоритет</Label>
                <Input type="number" value={form.priority || 1} onChange={e => setForm({ ...form, priority: parseInt(e.target.value) || 1 })} className="bg-[#0D1117] border-white/10 text-gray-200" />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300 text-sm">Кулдаун (сек)</Label>
                <Input type="number" value={form.cooldown || 0} onChange={e => setForm({ ...form, cooldown: parseInt(e.target.value) || 0 })} className="bg-[#0D1117] border-white/10 text-gray-200" />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300 text-sm">Описание</Label>
              <Textarea value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Описание триггера" className="bg-[#0D1117] border-white/10 text-gray-200 min-h-[60px]" />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Checkbox checked={form.caseSensitive} onCheckedChange={v => setForm({ ...form, caseSensitive: !!v })} />
                  <Label className="text-gray-400 text-xs">Чувств. к регистру</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox checked={form.wholeWord} onCheckedChange={v => setForm({ ...form, wholeWord: !!v })} />
                  <Label className="text-gray-400 text-xs">Целое слово</Label>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Label className="text-gray-300 text-xs">Включён</Label>
                <Switch checked={form.enabled} onCheckedChange={v => setForm({ ...form, enabled: !!v })} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" className="bg-white/5 border-white/10 text-gray-300 hover:bg-white/10" onClick={() => setEditorOpen(false)}>Отмена</Button>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white" onClick={() => saveMutation.mutate(form)}>
              {editingTrigger ? 'Сохранить' : 'Создать'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageWrapper>
  );
}

export default TriggersPage;