import type { LucideIcon } from 'lucide-react';
import {
  Shield, Users, Heart, Globe, AlertTriangle, Eye, Phone, Radio, Lock, Star,
  LayoutDashboard, UserCircle, MessageSquare, Zap, Send, Gamepad2,
  Workflow, CalendarClock, ScrollText, BarChart3, Settings, HardDrive, Info,
  Download,
} from 'lucide-react';
import type { ChatType, TriggerItem, Profile, EventItem, AutomationRule, ScheduledTask, BackupItem } from './types';
import { ACTION_ICONS } from './action-icons';

export { ACTION_ICONS };

// ─── STATUS COLORS ──────────────────────────────────────────────────────────

export const STATUS_COLORS: Record<string, string> = {
  ONLINE: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  CONNECTED: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  OK: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  OFFLINE: 'bg-red-500/20 text-red-400 border-red-500/30',
  DISCONNECTED: 'bg-red-500/20 text-red-400 border-red-500/30',
  WARNING: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  ERROR: 'bg-red-500/20 text-red-400 border-red-500/30',
  PENDING: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  COMPLETED: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
};

export const LEVEL_COLORS: Record<string, string> = {
  INFO: 'bg-blue-500/20 text-blue-400',
  WARNING: 'bg-yellow-500/20 text-yellow-400',
  ERROR: 'bg-red-500/20 text-red-400',
  SYSTEM: 'bg-purple-500/20 text-purple-400',
  DEBUG: 'bg-gray-500/20 text-gray-400',
};

// ─── MATCH TYPES ────────────────────────────────────────────────────────────

export const MATCH_TYPES = ['Contains', 'Equals', 'StartsWith', 'EndsWith', 'Regex'];

// ─── CHAT TYPES ─────────────────────────────────────────────────────────────

export const CHAT_TYPES: ChatType[] = [
  { id: 'government', name: 'Government', icon: Shield, enabled: true },
  { id: 'faction', name: 'Faction', icon: Users, enabled: true },
  { id: 'family', name: 'Family', icon: Heart, enabled: false },
  { id: 'global', name: 'Global', icon: Globe, enabled: true },
  { id: 'nonrp', name: 'NonRP', icon: AlertTriangle, enabled: false },
  { id: 'vr', name: 'VR', icon: Eye, enabled: true },
  { id: 'sms', name: 'SMS', icon: Phone, enabled: true },
  { id: 'radio', name: 'Radio', icon: Radio, enabled: false },
  { id: 'admin', name: 'Admin', icon: Lock, enabled: true },
  { id: 'custom', name: 'Custom', icon: Star, enabled: false },
];

// ─── SIDEBAR ITEMS ──────────────────────────────────────────────────────────

export const SIDEBAR_ITEMS: { id: string; label: string; icon: LucideIcon }[] = [
  { id: 'dashboard', label: 'Дашборд', icon: LayoutDashboard },
  { id: 'profiles', label: 'Профили', icon: UserCircle },
  { id: 'chats', label: 'Чаты', icon: MessageSquare },
  { id: 'triggers', label: 'Триггеры', icon: Zap },
  { id: 'telegram', label: 'Telegram', icon: Send },
  { id: 'agent', label: 'Агент', icon: Gamepad2 },
  { id: 'automation', label: 'Автоматизация', icon: Workflow },
  { id: 'scheduler', label: 'Планировщик', icon: CalendarClock },
  { id: 'events', label: 'Журнал', icon: ScrollText },
  { id: 'statistics', label: 'Статистика', icon: BarChart3 },
  { id: 'settings', label: 'Настройки', icon: Settings },
  { id: 'backup', label: 'Бэкапы', icon: HardDrive },
  { id: 'about', label: 'О системе', icon: Info },
  { id: 'install', label: 'Установка', icon: Download },
];

// ─── MOCK DATA ──────────────────────────────────────────────────────────────

export const MOCK_TRIGGERS: TriggerItem[] = [
  { id: '1', name: 'Приветствие', triggerText: 'привет', matchType: 'Contains', group: 'Общие', priority: 1, cooldown: 5, enabled: true, caseSensitive: false, wholeWord: false, description: 'Ответ на приветствие' },
  { id: '2', name: 'Помощь', triggerText: '!помощь', matchType: 'Equals', group: 'Команды', priority: 2, cooldown: 3, enabled: true, caseSensitive: false, wholeWord: false, description: 'Вывод справки' },
  { id: '3', name: 'РП проверка', triggerText: 'проверка', matchType: 'Contains', group: 'РП', priority: 1, cooldown: 0, enabled: true, caseSensitive: false, wholeWord: true, description: 'Проверка РП ситуации' },
  { id: '4', name: 'Админ команда', triggerText: '/admin', matchType: 'StartsWith', group: 'Команды', priority: 5, cooldown: 10, enabled: false, caseSensitive: true, wholeWord: false, description: 'Админ-команда' },
  { id: '5', name: 'Regex тест', triggerText: '^\\d{3}$', matchType: 'Regex', group: 'Тесты', priority: 3, cooldown: 2, enabled: true, caseSensitive: false, wholeWord: false, description: 'Трехзначные числа' },
  { id: '6', name: 'Прощание', triggerText: 'пока', matchType: 'EndsWith', group: 'Общие', priority: 1, cooldown: 5, enabled: true, caseSensitive: false, wholeWord: false, description: 'Ответ на прощание' },
];

export const MOCK_PROFILES: Profile[] = [
  { id: '1', name: 'Government', description: 'Профиль для Government чата', triggerCount: 12, chatFilterCount: 3, lastUpdated: '2024-01-15', enabled: true, isActive: true },
  { id: '2', name: 'Faction', description: 'Профиль для Faction чата', triggerCount: 8, chatFilterCount: 2, lastUpdated: '2024-01-14', enabled: true, isActive: false },
  { id: '3', name: 'Global RP', description: 'Общий РП профиль', triggerCount: 24, chatFilterCount: 5, lastUpdated: '2024-01-13', enabled: false, isActive: false },
];

export const MOCK_EVENTS: EventItem[] = [
  { id: '1', time: '12:45:32', source: 'Lua', level: 'INFO', event: 'Триггер активирован', description: 'Триггер "Приветствие" сработал в чате Government' },
  { id: '2', time: '12:45:28', source: 'Telegram', level: 'INFO', event: 'Сообщение отправлено', description: 'Уведомление о триггере отправлено в Telegram' },
  { id: '3', time: '12:44:15', source: 'System', level: 'SYSTEM', event: 'Подключение восстановлено', description: 'WebSocket соединение с Lua Agent восстановлено' },
  { id: '4', time: '12:43:00', source: 'Lua', level: 'WARNING', event: 'Высокий пинг', description: 'Пинг до сервера превысил 200мс' },
  { id: '5', time: '12:42:33', source: 'System', level: 'ERROR', event: 'Ошибка подключения', description: 'Не удалось подключиться к Lua Agent: таймаут' },
  { id: '6', time: '12:40:00', source: 'System', level: 'SYSTEM', event: 'Запуск системы', description: 'Moon Core запущен успешно' },
  { id: '7', time: '12:39:55', source: 'Database', level: 'INFO', event: 'База данных открыта', description: 'SQLite база данных инициализирована' },
  { id: '8', time: '12:45:35', source: 'Lua', level: 'INFO', event: 'Автоматизация запущена', description: 'Правило "РП проверка" выполнено успешно' },
  { id: '9', time: '12:46:01', source: 'Telegram', level: 'WARNING', event: 'Лимит сообщений', description: 'Близок к лимиту Telegram API (25/30 в секунду)' },
  { id: '10', time: '12:46:10', source: 'System', level: 'INFO', event: 'Бэкап создан', description: 'Автоматический бэкап базы данных: backup_2024_01_15.db' },
];

export const MOCK_AUTOMATION: AutomationRule[] = [
  {
    id: '1', name: 'РП проверка', trigger: 'проверка', priority: 1, cooldown: 60, enabled: true,
    actions: [
      { id: 'a1', type: 'telegram', params: { message: 'Начинаю проверку...' } },
      { id: 'a2', type: 'delay', params: { seconds: '5' } },
      { id: 'a3', type: 'disconnect', params: {} },
      { id: 'a4', type: 'delay', params: { seconds: '60' } },
      { id: 'a5', type: 'reconnect', params: {} },
      { id: 'a6', type: 'log', params: { message: 'Проверка завершена' } },
    ],
  },
  {
    id: '2', name: 'Перезапуск при ошибке', trigger: 'ERROR', priority: 5, cooldown: 300, enabled: true,
    actions: [
      { id: 'b1', type: 'telegram', params: { message: 'Обнаружена ошибка, перезапуск...' } },
      { id: 'b2', type: 'delay', params: { seconds: '10' } },
      { id: 'b3', type: 'reconnect', params: {} },
    ],
  },
  {
    id: '3', name: 'Уведомление о запуске', trigger: 'STARTUP', priority: 3, cooldown: 0, enabled: true,
    actions: [
      { id: 'c1', type: 'telegram', params: { message: 'Система запущена ✅' } },
      { id: 'c2', type: 'log', params: { message: 'Стартовое уведомление отправлено' } },
    ],
  },
];

export const MOCK_SCHEDULED: ScheduledTask[] = [
  { id: '1', name: 'Переподключение', scheduledTime: '12:50:00', status: 'PENDING', payload: '{"action":"reconnect"}' },
  { id: '2', name: 'Бэкап БД', scheduledTime: '13:00:00', status: 'PENDING', payload: '{"action":"backup"}' },
  { id: '3', name: 'Тестовый пинг', scheduledTime: '12:30:00', status: 'COMPLETED', payload: '{"action":"ping"}' },
];

export const MOCK_BACKUPS: BackupItem[] = [
  { id: '1', filename: 'backup_2024_01_15_120000.db', date: '15.01.2024 12:00', size: '2.4 МБ', comment: 'Автоматический бэкап' },
  { id: '2', filename: 'backup_2024_01_14_180000.db', date: '14.01.2024 18:00', size: '2.3 МБ', comment: 'Перед обновлением' },
  { id: '3', filename: 'backup_2024_01_13_000000.db', date: '13.01.2024 00:00', size: '2.2 МБ', comment: 'Ежедневный бэкап' },
];

// ─── CHART DATA ─────────────────────────────────────────────────────────────

export const STAT_CHART_DATA = [
  { day: 'Пн', triggers: 45, events: 120 },
  { day: 'Вт', triggers: 32, events: 95 },
  { day: 'Ср', triggers: 58, events: 140 },
  { day: 'Чт', triggers: 41, events: 110 },
  { day: 'Пт', triggers: 67, events: 165 },
  { day: 'Сб', triggers: 89, events: 210 },
  { day: 'Вс', triggers: 35, events: 88 },
];

export const PIE_DATA = [
  { name: 'Lua', value: 45, color: '#22C55E' },
  { name: 'Telegram', value: 20, color: '#3B82F6' },
  { name: 'System', value: 25, color: '#A855F7' },
  { name: 'Database', value: 10, color: '#F59E0B' },
];

export const RESOURCE_DATA = [
  { time: '10:00', cpu: 12, ram: 45 },
  { time: '10:30', cpu: 18, ram: 48 },
  { time: '11:00', cpu: 15, ram: 52 },
  { time: '11:30', cpu: 22, ram: 55 },
  { time: '12:00', cpu: 35, ram: 60 },
  { time: '12:30', cpu: 28, ram: 58 },
  { time: '13:00', cpu: 20, ram: 54 },
];

export const RECONNECT_DATA = [
  { time: '10:00', count: 0 },
  { time: '10:30', count: 1 },
  { time: '11:00', count: 0 },
  { time: '11:30', count: 2 },
  { time: '12:00', count: 0 },
  { time: '12:30', count: 1 },
  { time: '13:00', count: 0 },
];