'use client';

import React from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Cpu, Send, Gamepad2, Monitor, Database, Wifi, MemoryStick, Clock, RefreshCw, Download } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { useMoonStore } from './store';
import { MOCK_EVENTS } from './constants';
import type { StatusItem, EventItem } from './types';
import { PageWrapper, SectionHeader, GlassCard, StatusBadge } from './helpers';

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function formatUptime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}ч ${m}м`;
  if (m > 0) return `${m}м ${s}с`;
  return `${s}с`;
}

function getProgressColor(value: number): string {
  if (value > 80) return '[&>div]:bg-red-500';
  if (value > 50) return '[&>div]:bg-yellow-500';
  return '[&>div]:bg-emerald-500';
}

function capitalizeStatus(s?: string | null): string {
  return s?.toUpperCase() || 'UNKNOWN';
}

const SOURCE_COLORS: Record<string, string> = {
  lua: 'bg-blue-500/20 text-blue-400',
  telegram: 'bg-purple-500/20 text-purple-400',
  system: 'bg-gray-500/20 text-gray-400',
  core: 'bg-gray-500/20 text-gray-400',
  automation: 'bg-amber-500/20 text-amber-400',
  database: 'bg-emerald-500/20 text-emerald-400',
  desktop: 'bg-cyan-500/20 text-cyan-400',
};

const LEVEL_BORDER_COLORS: Record<string, string> = {
  INFO: 'border-l-blue-500/70',
  WARNING: 'border-l-yellow-500/70',
  ERROR: 'border-l-red-500/70',
  SYSTEM: 'border-l-purple-500/70',
  DEBUG: 'border-l-gray-500/70',
};

function mapApiEvents(rawEvents: Record<string, unknown>[]): EventItem[] {
  return rawEvents.map((ev) => {
    const timestamp = ev.timestamp as string;
    const time = timestamp
      ? new Date(timestamp).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      : '';
    const source = String(ev.source || 'system');
    return {
      id: String(ev.id || ''),
      time,
      source: source.charAt(0).toUpperCase() + source.slice(1),
      level: String(ev.level || 'info').toUpperCase(),
      event: String(ev.event || ''),
      description: String(ev.message || ev.title || ''),
    };
  });
}

// ─── COMPONENT ───────────────────────────────────────────────────────────────

function DashboardPage() {
  const queryClient = useQueryClient();
  const refreshKey = useMoonStore(s => s.refreshKey);

  const { data: statusData, isLoading: statusLoading } = useQuery({
    queryKey: ['status', refreshKey],
    queryFn: () => fetch('/api/status').then(r => r.json()).catch(() => null),
    refetchInterval: 10000,
  });

  const { data: eventsData, isLoading: eventsLoading } = useQuery({
    queryKey: ['events-recent', refreshKey],
    queryFn: () => fetch('/api/events?limit=10').then(r => r.json()).catch(() => null),
    refetchInterval: 10000,
  });

  // Map status data from API
  const cpuValue = statusData?.cpuUsage != null ? Math.round(statusData.cpuUsage) : 23;
  const ramValue = statusData?.ramUsage != null ? Math.round(statusData.ramUsage) : 42;
  const uptimeRaw = typeof statusData?.uptime === 'number' ? statusData.uptime : null;
  const uptimeDisplay = uptimeRaw != null ? formatUptime(uptimeRaw) : '—';

  const statusItems: StatusItem[] = [
    { name: 'Moon Core', status: capitalizeStatus(statusData?.backendStatus), icon: Cpu },
    { name: 'Telegram', status: capitalizeStatus(statusData?.telegramStatus), icon: Send },
    { name: 'Moon Agent', status: capitalizeStatus(statusData?.luaStatus), icon: Gamepad2 },
    { name: 'Desktop', status: capitalizeStatus(statusData?.desktopStatus), icon: Monitor },
    { name: 'SQLite', status: 'OK', icon: Database },
    { name: 'WebSocket', status: capitalizeStatus(statusData?.websocketStatus), icon: Wifi },
  ];

  // Map events from API or fall back to mock
  const apiEvents = eventsData?.data ? mapApiEvents(eventsData.data as Record<string, unknown>[]) : [];
  const events: EventItem[] = apiEvents.length > 0 ? apiEvents : MOCK_EVENTS;

  return (
    <PageWrapper>
      <SectionHeader title="Дашборд" description="Обзор состояния системы" />

      {/* ─── Status Cards ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {statusItems.map((item) => {
          const Icon = item.icon;
          return (
            <GlassCard key={item.name} hover gradientBorder className="p-4 relative overflow-hidden">
              {/* Background icon (very low opacity) */}
              <Icon className="absolute -right-1 -top-1 w-14 h-14 text-white/[0.03] pointer-events-none" />
              <div className="flex items-center gap-2.5 mb-3">
                <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center">
                  <Icon className="w-4.5 h-4.5 text-gray-400" />
                </div>
                <span className="text-xs font-medium text-gray-400">{item.name}</span>
              </div>
              {statusLoading ? (
                <Skeleton className="h-6 w-20 bg-white/5" />
              ) : (
                <StatusBadge status={item.status} pulse />
              )}
            </GlassCard>
          );
        })}
      </div>

      {/* ─── Info Cards (CPU / RAM / Uptime) ─────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <GlassCard className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-400 flex items-center gap-2">
              <Cpu className="w-4 h-4" /> CPU
            </span>
            <span className="text-lg font-semibold text-gray-100">
              {statusLoading ? '—' : `${cpuValue}%`}
            </span>
          </div>
          <Progress
            value={statusLoading ? 0 : cpuValue}
            className={`h-2 bg-white/5 ${getProgressColor(cpuValue)}`}
          />
        </GlassCard>
        <GlassCard className="p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-400 flex items-center gap-2">
              <MemoryStick className="w-4 h-4" /> RAM
            </span>
            <span className="text-lg font-semibold text-gray-100">
              {statusLoading ? '—' : `${ramValue}%`}
            </span>
          </div>
          <Progress
            value={statusLoading ? 0 : ramValue}
            className={`h-2 bg-white/5 ${getProgressColor(ramValue)}`}
          />
        </GlassCard>
        <GlassCard className="p-5">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-400 flex items-center gap-2">
              <Clock className="w-4 h-4" /> Аптайм
            </span>
            <span className="text-lg font-semibold text-gray-100">
              {statusLoading ? '—' : uptimeDisplay}
            </span>
          </div>
        </GlassCard>
      </div>

      {/* ─── Recent Events ──────────────────────────────────────────────── */}
      <GlassCard className="mb-6 overflow-hidden">
        <div className="p-5 pb-0 flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-200">Последние события</h3>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-gray-400 hover:text-gray-200 h-7"
            onClick={() => useMoonStore.getState().setActivePage('events')}
          >
            Все события →
          </Button>
        </div>
        <div className="p-3">
          {eventsLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-10 bg-white/5" />)}
            </div>
          ) : (
            <div className="relative max-h-80 overflow-y-auto">
              <div className="space-y-1 custom-scrollbar">
                {events.slice(0, 10).map((ev) => {
                  const levelKey = ev.level.toUpperCase();
                  const sourceKey = ev.source.toLowerCase();
                  return (
                    <div
                      key={ev.id}
                      className={`flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/[0.03] transition-colors border-l-2 ${LEVEL_BORDER_COLORS[levelKey] || 'border-l-gray-500/70'}`}
                    >
                      <span className="text-[11px] text-gray-500 font-mono w-16 flex-shrink-0 tabular-nums">
                        {ev.time}
                      </span>
                      <Badge
                        className={`text-[10px] px-1.5 py-0 border-0 font-medium ${SOURCE_COLORS[sourceKey] || SOURCE_COLORS.system}`}
                      >
                        {ev.source}
                      </Badge>
                      <span className="text-sm text-gray-300 truncate flex-1">{ev.event}</span>
                    </div>
                  );
                })}
              </div>
              {/* Fade effect at bottom */}
              <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-[#1E2530] to-transparent pointer-events-none" />
            </div>
          )}
        </div>
      </GlassCard>

      {/* ─── Quick Actions ──────────────────────────────────────────────── */}
      <GlassCard className="p-5">
        <h3 className="text-sm font-medium text-gray-200 mb-4">Быстрые действия</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            className="group flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:bg-white/[0.06] hover:border-white/[0.12] transition-all duration-200 text-left"
            onClick={() => {
              fetch('/api/agent/reconnect', { method: 'POST' }).then(() => {
                toast.success('Переподключение', { description: 'Команда переподключения отправлена' });
                queryClient.invalidateQueries({ queryKey: ['status'] });
              }).catch(() => toast.error('Ошибка', { description: 'Не удалось переподключиться' }));
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center group-hover:bg-amber-500/20 transition-colors flex-shrink-0">
              <RefreshCw className="w-4.5 h-4.5 text-amber-400" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium text-gray-200 group-hover:text-gray-100 transition-colors">Переподключить</div>
              <div className="text-xs text-gray-500">Перезапуск агента</div>
            </div>
          </button>
          <button
            type="button"
            className="group flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:bg-white/[0.06] hover:border-white/[0.12] transition-all duration-200 text-left"
            onClick={() => {
              fetch('/api/telegram/test', { method: 'POST' }).then(() => {
                toast.success('Telegram', { description: 'Тестовое сообщение отправлено' });
              }).catch(() => toast.error('Ошибка', { description: 'Не удалось отправить тест' }));
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center group-hover:bg-purple-500/20 transition-colors flex-shrink-0">
              <Send className="w-4.5 h-4.5 text-purple-400" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium text-gray-200 group-hover:text-gray-100 transition-colors">Тест Telegram</div>
              <div className="text-xs text-gray-500">Проверка бота</div>
            </div>
          </button>
          <button
            type="button"
            className="group flex items-center gap-3 p-4 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:bg-white/[0.06] hover:border-white/[0.12] transition-all duration-200 text-left"
            onClick={() => {
              fetch('/api/backups', { method: 'POST' }).then(() => {
                toast.success('Бэкап', { description: 'Бэкап создан успешно' });
                queryClient.invalidateQueries({ queryKey: ['backups'] });
              }).catch(() => toast.error('Ошибка', { description: 'Не удалось создать бэкап' }));
            }}
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center group-hover:bg-emerald-500/20 transition-colors flex-shrink-0">
              <Download className="w-4.5 h-4.5 text-emerald-400" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium text-gray-200 group-hover:text-gray-100 transition-colors">Создать бэкап</div>
              <div className="text-xs text-gray-500">Резервная копия БД</div>
            </div>
          </button>
        </div>
      </GlassCard>
    </PageWrapper>
  );
}

export default DashboardPage;