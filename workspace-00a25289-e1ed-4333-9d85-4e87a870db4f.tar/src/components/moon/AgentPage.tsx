'use client';

import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, ResponsiveContainer,
} from 'recharts';
import { Wifi, WifiOff, RefreshCw, Play, UserCircle, Monitor, Clock, Layers, Server, Activity, ZapOff, Download, FileCode, Plug } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useMoonStore } from './store';
import { PageWrapper, SectionHeader, GlassCard } from './helpers';

function AgentPage() {
  const queryClient = useQueryClient();
  const [heartbeats, setHeartbeats] = useState<number[]>([45, 52, 48, 38, 42, 55, 60, 47, 39, 44]);

  const { data: agentData, isLoading } = useQuery({
    queryKey: ['agent'],
    queryFn: () => fetch('/api/agent').then(r => r.json()).catch(() => null),
    refetchInterval: 5000,
  });

  const isConnected = agentData?.connected ?? true;

  const action = (name: string, url: string) => {
    fetch(url, { method: 'POST' })
      .then(() => { toast.success(name); queryClient.invalidateQueries({ queryKey: ['agent'] }); })
      .catch(() => toast.error(`Ошибка: ${name}`));
  };

  const infoItems = [
    { label: 'Версия', value: agentData?.version || '1.2.5', icon: Layers },
    { label: 'Пинг', value: agentData?.ping ? `${agentData.ping}мс` : '42мс', icon: Activity },
    { label: 'Сервер', value: agentData?.server || 'Ruby RP', icon: Server },
    { label: 'Никнейм', value: agentData?.nickname || 'Player_Name', icon: UserCircle },
    { label: 'FPS', value: agentData?.fps ? `${agentData.fps}` : '60', icon: Monitor },
    { label: 'Последний пакет', value: agentData?.lastPacket || '2 сек назад', icon: Clock },
  ];

  return (
    <PageWrapper>
      <SectionHeader title="Moon Agent" description="Статус и управление Lua-агентом" />

      {/* Connection Status */}
      <GlassCard className="p-6 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${isConnected ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
              {isConnected ? (
                <Wifi className="w-8 h-8 text-emerald-400" />
              ) : (
                <WifiOff className="w-8 h-8 text-red-400" />
              )}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-100">
                {isConnected ? 'Подключён' : 'Отключён'}
              </h2>
              <p className="text-sm text-gray-400">
                {isConnected ? 'Lua Agent активен и работает' : 'Нет связи с Lua Agent'}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs" onClick={() => action('Переподключение', '/api/agent/reconnect')}>
              <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Переподключить
            </Button>
            <Button size="sm" className="bg-white/5 hover:bg-white/10 text-gray-300 border border-white/[0.06] text-xs" onClick={() => action('Перезапуск', '/api/agent/reconnect')}>
              <Play className="w-3.5 h-3.5 mr-1.5" /> Перезапуск
            </Button>
          </div>
        </div>
      </GlassCard>

      {/* Info Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
        {infoItems.map(item => {
          const Icon = item.icon;
          return (
            <GlassCard key={item.label} className="p-4" hover>
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4 text-gray-500" />
                <span className="text-[11px] text-gray-500 uppercase tracking-wider">{item.label}</span>
              </div>
              <span className="text-sm font-medium text-gray-200">{item.value}</span>
            </GlassCard>
          );
        })}
      </div>

      {/* Lua Script Download */}
      <GlassCard className="p-5 mb-4" glow="blue">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
              <FileCode className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-100">MoonAgent.lua</h3>
              <p className="text-xs text-gray-500 mt-0.5">Скрипт агента для MoonLoader</p>
            </div>
          </div>
          <Button
            className="bg-blue-500 hover:bg-blue-600 text-white text-xs gap-2"
            onClick={() => { window.open('/api/agent/script', '_blank'); toast.success('Скачивание MoonAgent.lua начато'); }}
          >
            <Download className="w-3.5 h-3.5" /> Скачать скрипт
          </Button>
        </div>
        <Separator className="my-4 bg-white/[0.04]" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Версия', value: '0.1.0' },
            { label: 'Протокол', value: 'WebSocket' },
            { label: 'Чатов', value: '12 типов' },
            { label: 'Размер', value: '~30 КБ' },
          ].map(s => (
            <div key={s.label} className="text-center">
              <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">{s.label}</div>
              <div className="text-xs font-medium text-gray-300">{s.value}</div>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Actions */}
      <GlassCard className="p-5 mb-4">
        <h3 className="text-sm font-medium text-gray-200 mb-3">Действия</h3>
        <div className="flex flex-wrap gap-2">
          {[
            { label: 'Перезагрузить конфиг', icon: RefreshCw, action: 'reload-config' },
            { label: 'Пинг', icon: Activity, action: 'ping' },
            { label: 'Отключить', icon: ZapOff, action: 'disconnect' },
          ].map(btn => (
            <Button key={btn.action} size="sm" variant="ghost" className="bg-white/5 hover:bg-white/10 text-gray-300 border border-white/[0.06] text-xs h-8"
              onClick={() => action(btn.label, '/api/agent/reconnect')}>
              <btn.icon className="w-3.5 h-3.5 mr-1.5" /> {btn.label}
            </Button>
          ))}
        </div>
      </GlassCard>

      {/* Heartbeats */}
      <GlassCard className="p-5">
        <h3 className="text-sm font-medium text-gray-200 mb-4">Пульс (пинг, мс)</h3>
        <div className="h-32">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={heartbeats.map((h, i) => ({ i: i + 1, ping: h }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="i" tick={{ fontSize: 10, fill: '#6B7280' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#6B7280' }} axisLine={false} tickLine={false} width={35} />
              <RTooltip
                contentStyle={{ background: '#1E2530', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#E6EDF3' }}
                labelStyle={{ color: '#9CA3AF' }}
              />
              <Bar dataKey="ping" fill="#3B82F6" radius={[4, 4, 0, 0]} maxBarSize={24} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </GlassCard>
    </PageWrapper>
  );
}

export default AgentPage;