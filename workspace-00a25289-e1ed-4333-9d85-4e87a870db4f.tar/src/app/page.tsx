'use client';

import React, { useState, lazy, Suspense } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Sidebar, TopBar, BottomStatusBar } from '@/components/moon/Layout';
import { useMoonStore } from '@/components/moon/store';

const DashboardPage = lazy(() => import('@/components/moon/DashboardPage'));
const ProfilesPage = lazy(() => import('@/components/moon/ProfilesPage'));
const ChatsPage = lazy(() => import('@/components/moon/ChatsPage'));
const TriggersPage = lazy(() => import('@/components/moon/TriggersPage'));
const TelegramPage = lazy(() => import('@/components/moon/TelegramPage'));
const AgentPage = lazy(() => import('@/components/moon/AgentPage'));
const AutomationPage = lazy(() => import('@/components/moon/AutomationPage'));
const SchedulerPage = lazy(() => import('@/components/moon/SchedulerPage'));
const EventsPage = lazy(() => import('@/components/moon/EventsPage'));
const StatisticsPage = lazy(() => import('@/components/moon/StatisticsPage'));
const SettingsPage = lazy(() => import('@/components/moon/SettingsPage'));
const BackupPage = lazy(() => import('@/components/moon/BackupPage'));
const AboutPage = lazy(() => import('@/components/moon/AboutPage'));
const InstallPage = lazy(() => import('@/components/moon/InstallPage'));

const PAGE_MAP: Record<string, React.LazyExoticComponent<React.ComponentType>> = {
  dashboard: DashboardPage,
  profiles: ProfilesPage,
  chats: ChatsPage,
  triggers: TriggersPage,
  telegram: TelegramPage,
  agent: AgentPage,
  automation: AutomationPage,
  scheduler: SchedulerPage,
  events: EventsPage,
  statistics: StatisticsPage,
  settings: SettingsPage,
  backup: BackupPage,
  about: AboutPage,
  install: InstallPage,
};

function QueryProvider({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: { staleTime: 10000, retry: 1, refetchOnWindowFocus: false },
    },
  }));
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}

function PageContent() {
  const activePage = useMoonStore(s => s.activePage);
  const PageComponent = PAGE_MAP[activePage] || DashboardPage;

  return (
    <ScrollArea className="flex-1 h-full">
      <main className="p-6 max-w-7xl mx-auto w-full" role="main">
        <Suspense fallback={<div className="space-y-4"><Skeleton className="h-8 w-48 bg-white/5" /><Skeleton className="h-64 w-full bg-white/5 rounded-xl" /></div>}>
          <PageComponent />
        </Suspense>
      </main>
    </ScrollArea>
  );
}

export default function Home() {
  return (
    <QueryProvider>
      <TooltipProvider delayDuration={200}>
        <div className="h-screen flex flex-col overflow-hidden bg-[#0D1117]">
          <TopBar />
          <div className="flex-1 flex overflow-hidden">
            <Sidebar />
            <PageContent />
          </div>
          <BottomStatusBar />
        </div>
      </TooltipProvider>
    </QueryProvider>
  );
}