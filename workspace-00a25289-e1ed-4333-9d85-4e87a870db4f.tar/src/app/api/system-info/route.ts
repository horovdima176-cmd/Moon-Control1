import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    let info = await db.systemInfo.findUnique({ where: { id: "main" } });

    if (!info) {
      info = await db.systemInfo.create({
        data: {
          id: "main",
          os: "Windows 10 Pro 22H2",
          pythonVersion: "3.12.4",
          nodeVersion: "20.14.0",
          rustVersion: "1.78.0",
          cpu: "AMD Ryzen 5 5600X 6-Core",
          ram: "16 GB DDR4",
          gpu: "NVIDIA GeForce RTX 3060",
          hostname: "DESKTOP-MOON01",
        },
      });
    }

    return NextResponse.json(info);
  } catch (error) {
    console.error("Failed to get system info:", error);
    return NextResponse.json({ error: "Failed to get system info" }, { status: 500 });
  }
}