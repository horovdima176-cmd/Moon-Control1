import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const profileId = searchParams.get("profileId") ?? "";

    const where: Record<string, unknown> = {};
    if (profileId) {
      where.profileId = profileId;
    }

    const groups = await db.triggerGroup.findMany({
      where,
      include: {
        profile: {
          select: { id: true, name: true },
        },
        _count: {
          select: { triggers: true },
        },
      },
      orderBy: { priority: "asc" },
    });

    return NextResponse.json(groups);
  } catch (error) {
    console.error("Failed to get trigger groups:", error);
    return NextResponse.json({ error: "Failed to get trigger groups" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { profileId, groupName, enabled, priority } = body;

    if (!profileId || !groupName) {
      return NextResponse.json(
        { error: "profileId and groupName are required" },
        { status: 400 }
      );
    }

    const group = await db.triggerGroup.create({
      data: {
        profileId,
        groupName,
        enabled: enabled ?? true,
        priority: priority ?? 0,
      },
      include: {
        profile: true,
        _count: {
          select: { triggers: true },
        },
      },
    });

    return NextResponse.json(group, { status: 201 });
  } catch (error) {
    console.error("Failed to create trigger group:", error);
    return NextResponse.json({ error: "Failed to create trigger group" }, { status: 500 });
  }
}