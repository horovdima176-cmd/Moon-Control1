import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") ?? "";
    const profileId = searchParams.get("profileId") ?? "";

    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { triggerText: { contains: search } },
        { description: { contains: search } },
      ];
    }

    if (profileId) {
      where.group = { profileId };
    }

    const triggers = await db.trigger.findMany({
      where,
      include: {
        group: {
          include: {
            profile: {
              select: { id: true, name: true },
            },
          },
        },
        automationRules: true,
      },
      orderBy: { priority: "asc" },
    });

    return NextResponse.json(triggers);
  } catch (error) {
    console.error("Failed to get triggers:", error);
    return NextResponse.json({ error: "Failed to get triggers" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      groupId,
      name,
      triggerText,
      matchType,
      caseSensitive,
      wholeWord,
      enabled,
      priority,
      cooldown,
      description,
    } = body;

    if (!groupId || !name || !triggerText) {
      return NextResponse.json(
        { error: "groupId, name, and triggerText are required" },
        { status: 400 }
      );
    }

    const trigger = await db.trigger.create({
      data: {
        groupId,
        name,
        triggerText,
        matchType: matchType ?? "contains",
        caseSensitive: caseSensitive ?? false,
        wholeWord: wholeWord ?? false,
        enabled: enabled ?? true,
        priority: priority ?? 0,
        cooldown: cooldown ?? 0,
        description: description ?? null,
      },
      include: {
        group: true,
      },
    });

    return NextResponse.json(trigger, { status: 201 });
  } catch (error) {
    console.error("Failed to create trigger:", error);
    return NextResponse.json({ error: "Failed to create trigger" }, { status: 500 });
  }
}