import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const trigger = await db.trigger.findUnique({
      where: { id },
      include: {
        group: {
          include: {
            profile: true,
          },
        },
        automationRules: true,
      },
    });

    if (!trigger) {
      return NextResponse.json({ error: "Trigger not found" }, { status: 404 });
    }

    return NextResponse.json(trigger);
  } catch (error) {
    console.error("Failed to get trigger:", error);
    return NextResponse.json({ error: "Failed to get trigger" }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const trigger = await db.trigger.update({
      where: { id },
      data: body,
      include: {
        group: true,
        automationRules: true,
      },
    });

    return NextResponse.json(trigger);
  } catch (error) {
    console.error("Failed to update trigger:", error);
    return NextResponse.json({ error: "Failed to update trigger" }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.trigger.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to delete trigger:", error);
    return NextResponse.json({ error: "Failed to delete trigger" }, { status: 500 });
  }
}