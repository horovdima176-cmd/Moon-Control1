import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const rules = await db.automationRule.findMany({
      include: {
        trigger: {
          include: {
            group: {
              include: {
                profile: {
                  select: { id: true, name: true },
                },
              },
            },
          },
        },
        profile: {
          select: { id: true, name: true },
        },
      },
      orderBy: { priority: "desc" },
    });

    return NextResponse.json(rules);
  } catch (error) {
    console.error("Failed to get automation rules:", error);
    return NextResponse.json({ error: "Failed to get automation rules" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, triggerId, profileId, ...rest } = body;

    if (!name) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const rule = await db.automationRule.create({
      data: {
        name,
        triggerId: triggerId ?? null,
        profileId: profileId ?? null,
        ...rest,
      },
      include: {
        trigger: true,
        profile: {
          select: { id: true, name: true },
        },
      },
    });

    return NextResponse.json(rule, { status: 201 });
  } catch (error) {
    console.error("Failed to create automation rule:", error);
    return NextResponse.json({ error: "Failed to create automation rule" }, { status: 500 });
  }
}