import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * POST /api/automation/check
 * Called by the WebSocket bridge when a trigger is detected.
 * Evaluates all enabled automation rules and fires matching actions.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { triggerId, triggerName, text, chatType, sender } = body;

    if (!triggerId) {
      return NextResponse.json({ error: "triggerId is required" }, { status: 400 });
    }

    // Find all enabled automation rules linked to this trigger
    const rules = await db.automationRule.findMany({
      where: {
        triggerId,
        enabled: true,
      },
      orderBy: { priority: "desc" },
    });

    if (rules.length === 0) {
      return NextResponse.json({ matched: false, rulesFired: 0 });
    }

    const firedRules: string[] = [];

    for (const rule of rules) {
      // Check conditions
      if (rule.conditionChatType && rule.conditionChatType !== chatType) continue;
      if (rule.conditionNickname && rule.conditionNickname !== sender) continue;

      // Check time conditions
      if (rule.conditionTimeStart || rule.conditionTimeEnd) {
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();

        if (rule.conditionTimeStart) {
          const [h, m] = rule.conditionTimeStart.split(":").map(Number);
          if (currentMinutes < h * 60 + m) continue;
        }
        if (rule.conditionTimeEnd) {
          const [h, m] = rule.conditionTimeEnd.split(":").map(Number);
          if (currentMinutes > h * 60 + m) continue;
        }
      }

      // Check day conditions
      if (rule.conditionDays) {
        const dayNames = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
        const today = dayNames[new Date().getDay()];
        if (!rule.conditionDays.split(",").map((d: string) => d.trim()).includes(today)) continue;
      }

      // Rule matched — record it
      firedRules.push(rule.id);

      // Log the automation execution
      await db.event.create({
        data: {
          level: "info",
          source: "automation",
          event: "rule_fired",
          title: `Автоматизация: ${rule.name}`,
          message: `Триггер: ${triggerName ?? triggerId} | Действия: ${buildActionList(rule)}`,
          jsonData: JSON.stringify({ ruleId: rule.id, triggerId, triggerName, text, chatType, sender, dryRun: rule.dryRun }),
        },
      });

      // Create command history entry
      await db.commandHistory.create({
        data: {
          source: "automation",
          command: `rule:${rule.name}`,
          result: rule.dryRun ? "dry-run (no actions executed)" : buildActionList(rule),
          duration: 0.001,
        },
      });
    }

    return NextResponse.json({
      matched: firedRules.length > 0,
      rulesFired: firedRules.length,
      rules: firedRules,
    });
  } catch (error) {
    console.error("Failed to check automation rules:", error);
    return NextResponse.json({ error: "Failed to check automation rules" }, { status: 500 });
  }
}

function buildActionList(rule: Record<string, unknown>): string {
  const actions: string[] = [];
  if (rule.sendTelegram) actions.push("telegram");
  if (rule.disconnect) actions.push("disconnect");
  if (rule.reconnect) actions.push("reconnect");
  if (rule.playSound) actions.push("sound");
  if (rule.popup) actions.push("popup");
  if (rule.takeScreenshot) actions.push("screenshot");
  if (rule.customCommand) actions.push(`cmd:${rule.customCommand}`);
  return actions.join(", ") || "log";
}