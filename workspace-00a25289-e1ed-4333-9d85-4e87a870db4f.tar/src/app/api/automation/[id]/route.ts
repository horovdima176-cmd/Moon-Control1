import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const rule = await db.automationRule.update({
      where: { id },
      data: body,
      include: {
        trigger: true,
        profile: {
          select: { id: true, name: true },
        },
      },
    });

    return NextResponse.json(rule);
  } catch (error) {
    console.error("Failed to update automation rule:", error);
    return NextResponse.json({ error: "Failed to update automation rule" }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.automationRule.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Failed to delete automation rule:", error);
    return NextResponse.json({ error: "Failed to delete automation rule" }, { status: 500 });
  }
}