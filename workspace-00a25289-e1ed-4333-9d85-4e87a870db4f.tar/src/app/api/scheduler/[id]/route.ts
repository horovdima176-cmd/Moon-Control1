import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const task = await db.schedulerTask.update({
      where: { id },
      data: {
        status: "cancelled",
        completedAt: new Date(),
      },
    });

    return NextResponse.json({ success: true, task });
  } catch (error) {
    console.error("Failed to cancel scheduler task:", error);
    return NextResponse.json({ error: "Failed to cancel scheduler task" }, { status: 500 });
  }
}