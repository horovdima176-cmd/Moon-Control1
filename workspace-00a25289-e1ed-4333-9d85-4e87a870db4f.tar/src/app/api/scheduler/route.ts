import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const tasks = await db.schedulerTask.findMany({
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(tasks);
  } catch (error) {
    console.error("Failed to get scheduler tasks:", error);
    return NextResponse.json({ error: "Failed to get scheduler tasks" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { taskName, runAt, payload } = body;

    if (!taskName) {
      return NextResponse.json({ error: "taskName is required" }, { status: 400 });
    }

    const task = await db.schedulerTask.create({
      data: {
        taskName,
        runAt: runAt ? new Date(runAt) : null,
        payload: payload ? JSON.stringify(payload) : null,
        status: "pending",
      },
    });

    return NextResponse.json(task, { status: 201 });
  } catch (error) {
    console.error("Failed to create scheduler task:", error);
    return NextResponse.json({ error: "Failed to create scheduler task" }, { status: 500 });
  }
}