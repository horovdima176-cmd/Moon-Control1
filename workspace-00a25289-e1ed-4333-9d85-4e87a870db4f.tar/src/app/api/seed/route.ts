import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// ============================================================
// SEED DATA — GTA V RP (MoonLoader / GambitRP scenario)
// ============================================================

const PROFILES = [
  { name: "Government", description: "Профиль для работы в правительстве штата Сан-Андреас" },
  { name: "Police", description: "Профиль для сотрудников LSPD / BCSO" },
  { name: "FBI", description: "Профиль для агентов FIB / IAA" },
  { name: "Family", description: "Профиль для семейного RP" },
  { name: "Test", description: "Тестовый профиль для отладки триггеров" },
];

const CHAT_TYPES = [
  "Government", "Faction", "Family", "Global", "NonRP",
  "VR", "SMS", "Radio", "Admin",
];

const TRIGGER_GROUPS = [
  "Основные",
  "Жалобы",
  "Проверки",
  "Администрация",
  "Тестирование",
];

// Per-group triggers keyed by group name
const TRIGGERS_BY_GROUP: Record<string, { name: string; triggerText: string; matchType: string; description?: string }[]> = {
  "Основные": [
    { name: "Приветствие игрока", triggerText: "Здравствуйте", matchType: "contains", description: "Срабатывает при приветствии" },
    { name: "Прощание", triggerText: "до свидания", matchType: "contains", description: "Когда кто-то прощается" },
    { name: "Помощь", triggerText: "/help", matchType: "startsWith", description: "Запрос помощи" },
    { name: "Команда /me", triggerText: "/me ", matchType: "startsWith", description: "Отслеживание RP действий" },
    { name: "Команда /do", triggerText: "/do ", matchType: "startsWith", description: "Отслеживание RP описаний" },
    { name: "Команда /try", triggerText: "/try ", matchType: "startsWith", description: "Отслеживание попыток действий" },
    { name: "Вызов такси", triggerText: "такси", matchType: "contains", description: "Когда кто-то вызывает такси" },
    { name: "Продажа", triggerText: "продаю", matchType: "contains", description: "Отслеживание продаж на чате" },
  ],
  "Жалобы": [
    { name: "Жалоба на ADM", triggerText: "/report", matchType: "startsWith", description: "Репорт администратору" },
    { name: "NonRP поведение", triggerText: "nonrp", matchType: "contains", description: "Замечание NonRP поведения" },
    { name: "DM", triggerText: "deathmatch", matchType: "contains", description: "Deathmatch жалоба" },
    { name: "VDM", triggerText: "vehicledm", matchType: "contains", description: "Vehicle DM жалоба" },
    { name: "MetaGaming", triggerText: "metagaming", matchType: "contains", description: "MG жалоба" },
    { name: "PowerGaming", triggerText: "powergaming", matchType: "contains", description: "PG жалоба" },
    { name: "FK/CK", triggerText: "fear rp", matchType: "contains", description: "Fear RP жалоба" },
    { name: "Спам", triggerText: "спам", matchType: "contains", description: "Жалоба на спам в чат" },
  ],
  "Проверки": [
    { name: "Запрос лицензий", triggerText: "/licenses", matchType: "equals", description: "Проверка лицензий игрока" },
    { name: "Проверка identity", triggerText: "/id ", matchType: "startsWith", description: "Проверка ID игрока" },
    { name: "Проверка фракции", triggerText: "/faction", matchType: "equals", description: "Проверка фракционной принадлежности" },
    { name: "Уровень розыска", triggerText: "/wanted", matchType: "equals", description: "Проверка уровня розыска" },
    { name: "Список орудий", triggerText: "/frisk", matchType: "equals", description: "Обыск игрока" },
    { name: "Инвентарь", triggerText: "/inv", matchType: "equals", description: "Просмотр инвентаря" },
  ],
  "Администрация": [
    { name: "Кик игрока", triggerText: "/kick ", matchType: "startsWith", description: "Админ команда кика" },
    { name: "Бан игрока", triggerText: "/ban ", matchType: "startsWith", description: "Админ команда бана" },
    { name: "Телепорт", triggerText: "/tp ", matchType: "startsWith", description: "Телепортация к игроку" },
    { name: "Give item", triggerText: "/give ", matchType: "startsWith", description: "Выдача предмета" },
    { name: "Set HP", triggerText: "/sethp ", matchType: "startsWith", description: "Установка HP" },
    { name: "Мут игрока", triggerText: "/mute ", matchType: "startsWith", description: "Мут в чат" },
    { name: "Уни-мут", triggerText: "/unmute ", matchType: "startsWith", description: "Снятие мута" },
    { name: "Respawn", triggerText: "/respawn", matchType: "equals", description: "Респаун игрока" },
  ],
  "Тестирование": [
    { name: "Тестовый триггер 1", triggerText: "test_trigger_1", matchType: "equals", description: "Тестовый триггер для отладки" },
    { name: "Тестовый триггер 2", triggerText: "test_trigger_2", matchType: "equals", description: "Второй тестовый триггер" },
    { name: "Regex тест", triggerText: "\\[\\d+\\]", matchType: "regex", description: "Тест regex — находит числа в скобках" },
    { name: "Номер телефона", triggerText: "\\+7\\(\\d{3}\\)", matchType: "regex", description: "Определяет номера телефонов" },
    { name: "Тест чувствительности", triggerText: "ТЕСТ", matchType: "contains", description: "Проверка чувствительности к регистру" },
  ],
};

const EVENT_TEMPLATES = [
  // Info events
  { level: "info", source: "core", event: "startup", title: "Запуск системы", message: "MoonLoader успешно инициализирован" },
  { level: "info", source: "lua", event: "script_loaded", title: "Скрипт загружен", message: "Скрипт moonloader_core.lua загружен успешно" },
  { level: "info", source: "lua", event: "connected", title: "Подключение к серверу", message: "Успешное подключение к GambitRP #1 (185.249.22.41:22003)" },
  { level: "info", source: "telegram", event: "message_sent", title: "Сообщение отправлено", message: "Уведомление доставлено в Telegram" },
  { level: "info", source: "core", event: "profile_loaded", title: "Профиль загружен", message: "Активирован профиль: Government" },
  { level: "info", source: "automation", event: "trigger_fired", title: "Триггер сработал", message: "Триггер 'Приветствие игрока' активирован" },
  { level: "info", source: "lua", event: "chat_received", title: "Сообщение чата", message: "Получено сообщение в чат Government" },
  { level: "info", source: "core", event: "heartbeat", title: "Heartbeat", message: "Проверка соединения — OK" },
  { level: "info", source: "desktop", event: "window_focus", title: "Окно активно", message: "Пользователь вернулся в окно приложения" },
  { level: "info", source: "core", event: "settings_saved", title: "Настройки сохранены", message: "Настройки Telegram обновлены" },
  { level: "info", source: "lua", event: "script_loaded", title: "Скрипт загружен", message: "Скрипт chat_monitor.lua загружен" },
  { level: "info", source: "lua", event: "script_loaded", title: "Скрипт загружен", message: "Скрипt auto_reply.lua загружен" },
  { level: "info", source: "core", event: "scheduler_run", title: "Планировщик", message: "Задача 'Auto-reconnect check' выполнена успешно" },
  { level: "info", source: "telegram", event: "bot_connected", title: "Бот подключён", message: "Telegram бот @moonloader_bot подключён" },

  // Warning events
  { level: "warning", source: "lua", event: "high_latency", title: "Высокий пинг", message: "Пинг превысил 200мс: 347мс" },
  { level: "warning", source: "core", event: "memory_warning", title: "Память", message: "Использование RAM превысило 80%" },
  { level: "warning", source: "lua", event: "connection_unstable", title: "Нестабильное соединение", message: "Обнаружены потери пакетов: 3.2%" },
  { level: "warning", source: "telegram", event: "send_failed", title: "Ошибка отправки", message: "Не удалось отправить уведомление: timeout" },
  { level: "warning", source: "automation", event: "trigger_cooldown", title: "Кулдаун триггера", message: "Триггер 'Жалоба на ADM' в кулдауне, пропущен" },
  { level: "warning", source: "core", event: "backup_old", title: "Старый бэкап", message: "Последний бэкап был более 24 часов назад" },
  { level: "warning", source: "lua", event: "script_error", title: "Ошибка скрипта", message: "Ошибка в auto_reply.lua: attempt to index nil value" },
  { level: "warning", source: "core", event: "api_rate_limit", title: "Rate limit", message: "Превышен лимит запросов к Telegram API" },

  // Error events
  { level: "error", source: "lua", event: "disconnect", title: "Отключение", message: "Соединение с сервером разорвано: Connection timed out" },
  { level: "error", source: "core", event: "critical_error", title: "Критическая ошибка", message: "Необработанное исключение в модуле core.lua" },
  { level: "error", source: "telegram", event: "auth_failed", title: "Ошибка авторизации", message: "Невалидный bot token, проверьте настройки" },
  { level: "error", source: "lua", event: "script_crash", title: "Аварийное завершение скрипта", message: "Скрипт chat_monitor.lua аварийно завершён" },
  { level: "error", source: "core", event: "database_error", title: "Ошибка БД", message: "SQLite: database is locked" },
  { level: "error", source: "automation", event: "rule_execution_failed", title: "Ошибка правила", message: "Не удалось выполнить правило 'Reconnect on kick': timeout" },
];

const MODULES = [
  { moduleName: "chat-monitor", version: "2.1.3", loaded: true },
  { moduleName: "auto-reply", version: "1.4.0", loaded: true },
  { moduleName: "trigger-engine", version: "3.0.1", loaded: true },
  { moduleName: "telegram-bridge", version: "1.2.5", loaded: true },
  { moduleName: "reconnect-manager", version: "1.0.2", loaded: true },
  { moduleName: "screenshot-capture", version: "0.9.1", loaded: false },
  { moduleName: "sound-notifier", version: "1.1.0", loaded: true },
  { moduleName: "lua-executor", version: "2.3.0", loaded: true },
  { moduleName: "inventory-tracker", version: "0.5.0", loaded: false },
  { moduleName: "gps-tracker", version: "1.0.0", loaded: false },
  { moduleName: "stats-collector", version: "0.3.2", loaded: true },
  { moduleName: "admin-tools", version: "1.5.1", loaded: true },
];

const COMMANDS_HISTORY = [
  { source: "telegram", command: "/status", result: "online", duration: 0.12 },
  { source: "telegram", command: "/profile Government", result: "Активирован", duration: 0.15 },
  { source: "api", command: "ping", result: "pong 12ms", duration: 0.012 },
  { source: "desktop", command: "/triggers list", result: "24 triggers", duration: 0.08 },
  { source: "telegram", command: "/reconnect", result: "Reconnecting in 5s", duration: 0.03 },
  { source: "api", command: "reconnect", result: "Reconnecting in 8s", duration: 0.05 },
  { source: "desktop", command: "/settings theme dark", result: "Theme updated", duration: 0.02 },
  { source: "telegram", command: "/events last 10", result: "10 events", duration: 0.11 },
  { source: "api", command: "ping", result: "pong 8ms", duration: 0.008 },
  { source: "desktop", command: "/backup create", result: "Backup created", duration: 1.23 },
  { source: "telegram", command: "/modules list", result: "12 modules", duration: 0.09 },
  { source: "api", command: "ping", result: "pong 15ms", duration: 0.015 },
  { source: "desktop", command: "/profile activate FBI", result: "Activated", duration: 0.07 },
  { source: "telegram", command: "/automation test 3", result: "Dry run OK", duration: 0.34 },
  { source: "api", command: "reconnect", result: "Reconnecting in 6s", duration: 0.04 },
];

export async function POST() {
  try {
    const startTime = Date.now();

    // 1. Clear all data
    await db.notificationQueue.deleteMany();
    await db.event.deleteMany();
    await db.commandHistory.deleteMany();
    await db.schedulerTask.deleteMany();
    await db.backup.deleteMany();
    await db.automationRule.deleteMany();
    await db.trigger.deleteMany();
    await db.triggerGroup.deleteMany();
    await db.chatFilter.deleteMany();
    await db.profile.deleteMany();
    await db.module.deleteMany();
    await db.user.deleteMany();
    await db.systemInfo.deleteMany();
    await db.desktopSettings.deleteMany();
    await db.reconnectSettings.deleteMany();
    await db.telegramSettings.deleteMany();
    await db.applicationState.deleteMany();

    // 2. Create default ApplicationState
    await db.applicationState.create({
      data: {
        id: "main",
        backendStatus: "online",
        desktopStatus: "online",
        luaStatus: "connected",
        telegramStatus: "connected",
        websocketStatus: "connected",
        currentProfile: "government",
        version: "0.1.0",
        uptime: 14400,
        lastPing: new Date(),
        cpuUsage: 12.5,
        ramUsage: 35.2,
      },
    });

    // 3. Create profiles
    const createdProfiles: Record<string, string> = {};
    for (const p of PROFILES) {
      const profile = await db.profile.create({
        data: {
          name: p.name,
          description: p.description,
          enabled: true,
        },
      });
      createdProfiles[p.name] = profile.id;
    }

    // 4. Create chat filters for each profile
    const chatFilterCounts: Record<string, number> = {};
    for (const [profileName, profileId] of Object.entries(createdProfiles)) {
      let count = 0;
      for (const chatType of CHAT_TYPES) {
        // Enable different subsets for different profiles
        const enabledMap: Record<string, boolean> = {
          Government: ["Government", "Faction", "Global", "Admin", "Radio"].includes(chatType),
          Police: ["Faction", "Government", "Radio", "Global", "Admin"].includes(chatType),
          FBI: ["Faction", "Government", "Global", "Admin", "Radio", "SMS"].includes(chatType),
          Family: ["Family", "Global", "SMS", "Radio"].includes(chatType),
          Test: true, // all enabled for test
        };
        await db.chatFilter.create({
          data: {
            profileId,
            chatType,
            enabled: enabledMap[profileName],
          },
        });
        count++;
      }
      chatFilterCounts[profileName] = count;
    }

    // 5 & 6. Create trigger groups and triggers per profile
    const allTriggerIds: string[] = [];
    for (const [profileName, profileId] of Object.entries(createdProfiles)) {
      for (let gi = 0; gi < TRIGGER_GROUPS.length; gi++) {
        const groupName = TRIGGER_GROUPS[gi];
        const group = await db.triggerGroup.create({
          data: {
            profileId,
            groupName,
            enabled: true,
            priority: gi,
          },
        });

        const triggersForGroup = TRIGGERS_BY_GROUP[groupName] ?? [];
        for (let ti = 0; ti < triggersForGroup.length; ti++) {
          const t = triggersForGroup[ti];
          const trigger = await db.trigger.create({
            data: {
              groupId: group.id,
              name: `${profileName}: ${t.name}`,
              triggerText: t.triggerText,
              matchType: t.matchType,
              caseSensitive: false,
              wholeWord: false,
              enabled: true,
              priority: ti,
              cooldown: ti % 3 === 0 ? 30 : 0,
              description: t.description ?? null,
            },
          });
          allTriggerIds.push(trigger.id);
        }
      }
    }

    // 7. Create automation rules for several triggers
    const automationRulesData = [
      {
        name: "Уведомление о жалобе ADM",
        triggerIndex: 8,  // Жалоба на ADM in each profile
        sendTelegram: true,
        playSound: true,
        popup: true,
        writeLog: true,
        priority: 3,
      },
      {
        name: "Авто-переподключение при кике",
        triggerIndex: 0,  // from "Администрация" — Кик игрока
        disconnect: false,
        reconnect: true,
        reconnectDelay: 30,
        writeLog: true,
        sendTelegram: true,
        priority: 2,
      },
      {
        name: "Скриншот при бане",
        triggerIndex: 1,  // Бан игрока
        takeScreenshot: true,
        writeLog: true,
        sendTelegram: true,
        priority: 3,
      },
      {
        name: "Звук при NonRP",
        triggerIndex: 9,  // NonRP поведение
        playSound: true,
        writeLog: true,
        priority: 1,
      },
      {
        name: "Логирование RP действий",
        triggerIndex: 3,  // /me
        writeLog: true,
        priority: 0,
        cooldown: 60,
      },
      {
        name: "Уведомление о DM жалобе",
        triggerIndex: 10, // DM
        sendTelegram: true,
        playSound: true,
        writeLog: true,
        priority: 2,
      },
      {
        name: "Telegram при VDM",
        triggerIndex: 11, // VDM
        sendTelegram: true,
        writeLog: true,
        priority: 2,
      },
      {
        name: "Админ: мут игрока",
        triggerIndex: 19, // Мут игрока
        writeLog: true,
        sendTelegram: true,
        priority: 2,
        customCommand: "/mute {nickname} 30 NonRP",
      },
    ];

    // We need to map triggerIndex to actual trigger IDs.
    // Each profile has 5 groups. Group triggers:
    // Основные: 0-7 (8 triggers), Жалобы: 8-15 (8), Проверки: 16-21 (6), Администрация: 22-29 (8), Тестирование: 30-34 (5)
    // Per profile = 35 triggers. Total = 5 profiles * 35 = 175 triggers
    const TRIGGERS_PER_PROFILE = allTriggerIds.length / 5;
    for (const ruleData of automationRulesData) {
      // Create for first 3 profiles (Government, Police, FBI)
      for (let p = 0; p < 3; p++) {
        const triggerId = allTriggerIds[p * TRIGGERS_PER_PROFILE + ruleData.triggerIndex];
        if (!triggerId) continue;
        const profileNames = Object.keys(createdProfiles);
        await db.automationRule.create({
          data: {
            name: ruleData.name,
            triggerId,
            profileId: createdProfiles[profileNames[p]],
            enabled: true,
            priority: ruleData.priority,
            sendTelegram: ruleData.sendTelegram ?? false,
            disconnect: ruleData.disconnect ?? false,
            reconnect: ruleData.reconnect ?? false,
            reconnectDelay: ruleData.reconnectDelay ?? 60,
            playSound: ruleData.playSound ?? false,
            popup: ruleData.popup ?? false,
            writeLog: ruleData.writeLog ?? true,
            takeScreenshot: ruleData.takeScreenshot ?? false,
            customCommand: ruleData.customCommand ?? null,
            cooldown: ruleData.cooldown ?? 0,
          },
        });
      }
    }

    // 8. Create default settings
    await db.telegramSettings.create({
      data: {
        id: "main",
        botToken: "7283910564:AAH_test_bot_token_for_moonloader",
        chatId: "993847562",
        ownerName: "MoonAdmin",
        enabled: true,
        sendStatus: true,
        sendTrigger: true,
        sendErrors: true,
        sendLogs: false,
        sendReconnect: true,
        sendStartup: true,
        sendShutdown: true,
        testMode: false,
        monitorOnly: false,
      },
    });

    await db.desktopSettings.create({
      data: {
        id: "main",
        theme: "dark",
        language: "ru",
        sidebarCollapsed: false,
        animations: true,
        autoUpdate: false,
        windowWidth: 1400,
        windowHeight: 900,
        startMinimized: false,
      },
    });

    await db.reconnectSettings.create({
      data: {
        id: "main",
        enabled: true,
        delaySeconds: 60,
        retryCount: 5,
        retryInterval: 30,
        waitForSpawn: true,
        safeReconnect: true,
        randomDelay: true,
        randomRange: 5,
      },
    });

    // 9. Create 50+ events
    const now = Date.now();
    for (let i = 0; i < 55; i++) {
      const template = EVENT_TEMPLATES[i % EVENT_TEMPLATES.length];
      const hoursAgo = Math.floor(Math.random() * 48);
      const minutesAgo = Math.floor(Math.random() * 60);
      const timestamp = new Date(now - (hoursAgo * 3600 + minutesAgo * 60) * 1000);

      // Add some variety to messages
      const suffixes = [
        "", "", "",
        " [авто]",
        " (повтор)",
        ` #${i + 1}`,
      ];
      const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];

      await db.event.create({
        data: {
          timestamp,
          level: template.level,
          source: template.source,
          event: template.event,
          title: template.title,
          message: (template.message ?? "") + suffix,
          jsonData: i % 5 === 0 ? JSON.stringify({ extra: "data", index: i }) : null,
        },
      });
    }

    // 10. Create scheduler tasks
    const schedulerTasks = [
      { taskName: "Авто-переподключение", runAt: new Date(now + 3600000) },
      { taskName: "Ежедневный бэкап", runAt: new Date(now + 86400000) },
      { taskName: "Проверка обновлений", runAt: new Date(now + 7200000) },
      { taskName: "Очистка старых логов", runAt: new Date(now + 43200000) },
      { taskName: "Пинг сервера", runAt: new Date(now + 300000) },
    ];
    for (const task of schedulerTasks) {
      await db.schedulerTask.create({
        data: {
          taskName: task.taskName,
          runAt: task.runAt,
          payload: JSON.stringify({ auto: true }),
          status: "pending",
        },
      });
    }

    // Create some completed/cancelled tasks
    await db.schedulerTask.create({
      data: {
        taskName: "Старое переподключение",
        runAt: new Date(now - 3600000),
        payload: null,
        status: "completed",
        completedAt: new Date(now - 3500000),
      },
    });
    await db.schedulerTask.create({
      data: {
        taskName: "Отменённая задача",
        runAt: new Date(now - 7200000),
        payload: null,
        status: "cancelled",
        completedAt: new Date(now - 7000000),
      },
    });

    // Create command history
    for (let i = 0; i < COMMANDS_HISTORY.length; i++) {
      const cmd = COMMANDS_HISTORY[i];
      const hoursAgo = Math.floor(Math.random() * 24);
      const minutesAgo = Math.floor(Math.random() * 60);
      await db.commandHistory.create({
        data: {
          time: new Date(now - (hoursAgo * 3600 + minutesAgo * 60) * 1000),
          source: cmd.source,
          command: cmd.command,
          result: cmd.result,
          duration: cmd.duration,
        },
      });
    }

    // Create backups
    const backupComments = ["Автоматический бэкап", "Перед обновлением", "Ручной бэкап", null, "Тестовый бэкап"];
    for (let i = 0; i < 5; i++) {
      const daysAgo = i * 2 + 1;
      await db.backup.create({
        data: {
          filename: `moon-control-backup-2025-01-${String(15 - i * 2).padStart(2, "0")}_12-00-00.json`,
          createdAt: new Date(now - daysAgo * 86400000),
          size: Math.floor(Math.random() * 400000) + 80000,
          comment: backupComments[i],
        },
      });
    }

    // Create modules
    for (const mod of MODULES) {
      await db.module.create({
        data: {
          moduleName: mod.moduleName,
          enabled: true,
          loaded: mod.loaded,
          version: mod.version,
          lastUpdate: new Date(now - Math.floor(Math.random() * 7 * 86400000)),
        },
      });
    }

    // 11. Create system info
    await db.systemInfo.create({
      data: {
        id: "main",
        os: "Windows 10 Pro 22H2 (19045.5011)",
        pythonVersion: "3.12.4",
        nodeVersion: "20.14.0",
        rustVersion: "1.78.0",
        cpu: "AMD Ryzen 5 5600X 6-Core Processor",
        ram: "16384 MB DDR4 3200MHz",
        gpu: "NVIDIA GeForce RTX 3060 (12GB VRAM)",
        hostname: "DESKTOP-MOON01",
      },
    });

    // Create default user
    await db.user.create({
      data: {
        username: "admin",
        role: "admin",
        lastLogin: new Date(),
        permissions: JSON.stringify({ all: true }),
      },
    });

    // Create some notification queue items
    await db.notificationQueue.createMany({
      data: [
        { message: "Система запущена успешно", status: "sent", attempts: 1, lastAttempt: new Date(now - 7200000), responseData: '{"ok":true}' },
        { message: "Триггер сработал: Приветствие игрока", status: "sent", attempts: 1, lastAttempt: new Date(now - 3600000), responseData: '{"ok":true}' },
        { message: "Ошибка подключения к Telegram API", status: "failed", attempts: 3, lastAttempt: new Date(now - 1800000), responseData: '{"error":"timeout"}' },
        { message: "Автоматическое переподключение выполнено", status: "pending", attempts: 0 },
      ],
    });

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    // Count results
    const profileCount = await db.profile.count();
    const triggerCount = await db.trigger.count();
    const eventCount = await db.event.count();
    const ruleCount = await db.automationRule.count();

    return NextResponse.json({
      success: true,
      message: "Database seeded successfully",
      duration: `${duration}s`,
      stats: {
        profiles: profileCount,
        triggers: triggerCount,
        events: eventCount,
        automationRules: ruleCount,
        modules: MODULES.length,
        backups: 5,
        schedulerTasks: 7,
        commandHistory: COMMANDS_HISTORY.length,
      },
    });
  } catch (error) {
    console.error("Seed failed:", error);
    return NextResponse.json(
      { error: "Seed failed", details: String(error) },
      { status: 500 }
    );
  }
}