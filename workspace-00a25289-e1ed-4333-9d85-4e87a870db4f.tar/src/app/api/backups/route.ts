import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const backups = await db.backup.findMany({
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(backups);
  } catch (error) {
    console.error("Failed to get backups:", error);
    return NextResponse.json({ error: "Failed to get backups" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { comment } = body ?? {};

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toISOString().slice(11, 19).replace(/:/g, "-");
    const filename = `moon-control-backup-${dateStr}_${timeStr}.json`;

    const backup = await db.backup.create({
      data: {
        filename,
        size: Math.floor(Math.random() * 500000) + 50000,
        comment: comment ?? null,
      },
    });

    return NextResponse.json(backup, { status: 201 });
  } catch (error) {
    console.error("Failed to create backup:", error);
    return NextResponse.json({ error: "Failed to create backup" }, { status: 500 });
  }
}