import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    let settings = await db.reconnectSettings.findUnique({ where: { id: "main" } });

    if (!settings) {
      settings = await db.reconnectSettings.create({ data: { id: "main" } });
    }

    return NextResponse.json(settings);
  } catch (error) {
    console.error("Failed to get reconnect settings:", error);
    return NextResponse.json({ error: "Failed to get reconnect settings" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    const settings = await db.reconnectSettings.upsert({
      where: { id: "main" },
      update: body,
      create: { id: "main", ...body },
    });

    return NextResponse.json(settings);
  } catch (error) {
    console.error("Failed to update reconnect settings:", error);
    return NextResponse.json({ error: "Failed to update reconnect settings" }, { status: 500 });
  }
}