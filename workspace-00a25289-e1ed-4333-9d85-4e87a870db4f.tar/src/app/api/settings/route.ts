import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    let settings = await db.desktopSettings.findUnique({ where: { id: "main" } });

    if (!settings) {
      settings = await db.desktopSettings.create({ data: { id: "main" } });
    }

    return NextResponse.json(settings);
  } catch (error) {
    console.error("Failed to get desktop settings:", error);
    return NextResponse.json({ error: "Failed to get desktop settings" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    const settings = await db.desktopSettings.upsert({
      where: { id: "main" },
      update: body,
      create: { id: "main", ...body },
    });

    return NextResponse.json(settings);
  } catch (error) {
    console.error("Failed to update desktop settings:", error);
    return NextResponse.json({ error: "Failed to update desktop settings" }, { status: 500 });
  }
}