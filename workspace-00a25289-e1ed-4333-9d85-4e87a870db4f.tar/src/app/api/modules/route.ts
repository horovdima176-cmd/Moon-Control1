import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const modules = await db.module.findMany({
      orderBy: { moduleName: "asc" },
    });

    return NextResponse.json(modules);
  } catch (error) {
    console.error("Failed to get modules:", error);
    return NextResponse.json({ error: "Failed to get modules" }, { status: 500 });
  }
}