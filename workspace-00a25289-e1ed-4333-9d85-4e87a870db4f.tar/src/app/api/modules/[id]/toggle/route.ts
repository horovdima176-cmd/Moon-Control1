import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const module_ = await db.module.findUnique({ where: { id } });
    if (!module_) {
      return NextResponse.json({ error: "Module not found" }, { status: 404 });
    }

    const updated = await db.module.update({
      where: { id },
      data: {
        enabled: !module_.enabled,
        loaded: module_.enabled ? false : module_.loaded,
      },
    });

    return NextResponse.json({
      success: true,
      module: updated,
      previousState: module_.enabled ? "enabled" : "disabled",
      newState: updated.enabled ? "enabled" : "disabled",
    });
  } catch (error) {
    console.error("Failed to toggle module:", error);
    return NextResponse.json({ error: "Failed to toggle module" }, { status: 500 });
  }
}