import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST() {
  try {
    const startTime = Date.now();

    // Update last ping
    await db.applicationState.upsert({
      where: { id: "main" },
      update: {
        lastPing: new Date(),
        luaStatus: "connected",
      },
      create: {
        id: "main",
        lastPing: new Date(),
        luaStatus: "connected",
      },
    });

    const responseTime = Date.now() - startTime + Math.floor(Math.random() * 10);

    // Log command
    await db.commandHistory.create({
      data: {
        source: "api",
        command: "ping",
        result: `pong ${responseTime}ms`,
        duration: responseTime / 1000,
      },
    });

    return NextResponse.json({
      success: true,
      message: "pong",
      responseTime: `${responseTime}ms`,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Failed to ping:", error);
    return NextResponse.json({ error: "Failed to ping" }, { status: 500 });
  }
}