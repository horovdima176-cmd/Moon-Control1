import { NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import { join } from 'path';

export async function GET() {
  try {
    const scriptPath = join(process.cwd(), 'agent', 'MoonAgent.lua');
    const content = await readFile(scriptPath, 'utf-8');
    return new NextResponse(content, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': 'attachment; filename="MoonAgent.lua"',
      },
    });
  } catch {
    return NextResponse.json({ error: 'Script not found' }, { status: 404 });
  }
}