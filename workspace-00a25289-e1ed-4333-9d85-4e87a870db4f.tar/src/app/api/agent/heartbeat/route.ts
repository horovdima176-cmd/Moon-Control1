import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fps, ping, nickname, server } = body;

    // Update application state with heartbeat data
    await db.applicationState.upsert({
      where: { id: "main" },
      update: {
        luaStatus: "connected",
        lastPing: new Date(),
      },
      create: {
        id: "main",
        luaStatus: "connected",
        lastPing: new Date(),
        backendStatus: "online",
      },
    });

    return NextResponse.json({
      success: true,
      received: { fps, ping, nickname, server },
    });
  } catch (error) {
    console.error("Failed to process heartbeat:", error);
    return NextResponse.json({ error: "Failed to process heartbeat" }, { status: 500 });
  }
}