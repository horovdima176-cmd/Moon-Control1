import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST() {
  try {
    // Simulate reconnect command
    const reconnectDelay = Math.floor(Math.random() * 10) + 3;

    // Update application state
    await db.applicationState.upsert({
      where: { id: "main" },
      update: {
        luaStatus: "reconnecting",
        lastError: null,
      },
      create: {
        id: "main",
        luaStatus: "reconnecting",
      },
    });

    // Create a log event
    await db.event.create({
      data: {
        level: "info",
        source: "core",
        event: "reconnect_command",
        title: "Команда переподключения",
        message: `Инициализация переподключения к серверу. Задержка: ${reconnectDelay}с`,
      },
    });

    // Create command history entry
    await db.commandHistory.create({
      data: {
        source: "api",
        command: "reconnect",
        result: `Reconnecting in ${reconnectDelay}s`,
        duration: 0.05,
      },
    });

    return NextResponse.json({
      success: true,
      message: "Reconnect command sent",
      delay: reconnectDelay,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Failed to reconnect:", error);
    return NextResponse.json({ error: "Failed to reconnect" }, { status: 500 });
  }
}