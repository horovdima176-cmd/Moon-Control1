import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    let state = await db.applicationState.findUnique({ where: { id: "main" } });

    if (!state) {
      state = await db.applicationState.create({ data: { id: "main" } });
    }

    // Simulated heartbeat data
    const heartbeat = {
      status: state.luaStatus === "connected" ? "alive" : "dead",
      lastPing: state.lastPing ?? new Date(),
      responseTime: Math.floor(Math.random() * 50) + 5,
      packetsSent: Math.floor(Math.random() * 10000) + 1000,
      packetsReceived: Math.floor(Math.random() * 10000) + 1000,
      packetsLost: Math.floor(Math.random() * 5),
      connectionAge: Math.floor(Math.random() * 7200) + 300,
      luaMemory: Math.floor(Math.random() * 50) + 10,
      luaScripts: Math.floor(Math.random() * 20) + 5,
    };

    return NextResponse.json({
      agent: {
        status: state.luaStatus,
        backendStatus: state.backendStatus,
        version: state.version,
        currentProfile: state.currentProfile,
        lastError: state.lastError,
        uptime: state.uptime,
      },
      heartbeat,
    });
  } catch (error) {
    console.error("Failed to get agent status:", error);
    return NextResponse.json({ error: "Failed to get agent status" }, { status: 500 });
  }
}