import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function DELETE() {
  try {
    await db.event.deleteMany({});
    return NextResponse.json({ success: true, message: "All events cleared" });
  } catch (error) {
    console.error("Failed to clear events:", error);
    return NextResponse.json({ error: "Failed to clear events" }, { status: 500 });
  }
}