import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get("page") ?? "1", 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") ?? "50", 10)));
    const level = searchParams.get("level") ?? "";
    const source = searchParams.get("source") ?? "";

    const where: Record<string, unknown> = {};
    if (level) {
      where.level = level;
    }
    if (source) {
      where.source = source;
    }

    const [events, total] = await Promise.all([
      db.event.findMany({
        where,
        orderBy: { timestamp: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.event.count({ where }),
    ]);

    return NextResponse.json({
      data: events,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Failed to get events:", error);
    return NextResponse.json({ error: "Failed to get events" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { level, source, event, title, message, jsonData } = body;

    if (!event) {
      return NextResponse.json({ error: "event is required" }, { status: 400 });
    }

    const newEvent = await db.event.create({
      data: {
        level: level ?? "info",
        source: source ?? "system",
        event,
        title: title ?? null,
        message: message ?? null,
        jsonData: jsonData ?? null,
      },
    });

    return NextResponse.json(newEvent, { status: 201 });
  } catch (error) {
    console.error("Failed to create event:", error);
    return NextResponse.json({ error: "Failed to create event" }, { status: 500 });
  }
}