import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = Math.min(200, Math.max(1, parseInt(searchParams.get("limit") ?? "50", 10)));

    const history = await db.commandHistory.findMany({
      orderBy: { time: "desc" },
      take: limit,
    });

    return NextResponse.json(history);
  } catch (error) {
    console.error("Failed to get command history:", error);
    return NextResponse.json({ error: "Failed to get command history" }, { status: 500 });
  }
}