import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Verify profile exists
    const profile = await db.profile.findUnique({ where: { id } });
    if (!profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 404 });
    }

    // Upsert application state and set current profile
    const state = await db.applicationState.upsert({
      where: { id: "main" },
      update: { currentProfile: id },
      create: {
        id: "main",
        currentProfile: id,
      },
    });

    return NextResponse.json({
      success: true,
      currentProfile: id,
      profileName: profile.name,
      state,
    });
  } catch (error) {
    console.error("Failed to activate profile:", error);
    return NextResponse.json({ error: "Failed to activate profile" }, { status: 500 });
  }
}