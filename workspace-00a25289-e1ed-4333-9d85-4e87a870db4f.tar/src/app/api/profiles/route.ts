import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const profiles = await db.profile.findMany({
      orderBy: { createdAt: "asc" },
      include: {
        _count: {
          select: {
            chatFilters: true,
            triggerGroups: true,
          },
        },
      },
    });

    return NextResponse.json(profiles);
  } catch (error) {
    console.error("Failed to get profiles:", error);
    return NextResponse.json({ error: "Failed to get profiles" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, enabled } = body;

    if (!name || typeof name !== "string") {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const profile = await db.profile.create({
      data: {
        name,
        description: description ?? null,
        enabled: enabled ?? true,
      },
    });

    return NextResponse.json(profile, { status: 201 });
  } catch (error) {
    console.error("Failed to create profile:", error);
    return NextResponse.json({ error: "Failed to create profile" }, { status: 500 });
  }
}