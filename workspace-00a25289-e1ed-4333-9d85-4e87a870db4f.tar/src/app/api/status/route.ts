import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    let state = await db.applicationState.findUnique({ where: { id: "main" } });

    if (!state) {
      state = await db.applicationState.create({
        data: {
          id: "main",
          backendStatus: "online",
          desktopStatus: "online",
          luaStatus: "disconnected",
          telegramStatus: "disconnected",
          websocketStatus: "connected",
          version: "0.1.0",
        },
      });
    }

    // Simulate random health data
    const cpuUsage = Math.round((Math.random() * 30 + 5) * 100) / 100;
    const ramUsage = Math.round((Math.random() * 40 + 20) * 100) / 100;
    const uptime = Math.floor(Math.random() * 86400) + 3600;

    return NextResponse.json({
      ...state,
      cpuUsage,
      ramUsage,
      uptime,
    });
  } catch (error) {
    console.error("Failed to get status:", error);
    return NextResponse.json({ error: "Failed to get status" }, { status: 500 });
  }
}