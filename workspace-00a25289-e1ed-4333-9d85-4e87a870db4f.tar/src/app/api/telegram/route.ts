import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    let settings = await db.telegramSettings.findUnique({ where: { id: "main" } });

    if (!settings) {
      settings = await db.telegramSettings.create({ data: { id: "main" } });
    }

    // Mask the bot token for security
    const masked = {
      ...settings,
      botToken: settings.botToken
        ? `${settings.botToken.slice(0, 8)}****${settings.botToken.slice(-4)}`
        : null,
    };

    return NextResponse.json(masked);
  } catch (error) {
    console.error("Failed to get Telegram settings:", error);
    return NextResponse.json({ error: "Failed to get Telegram settings" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();

    const settings = await db.telegramSettings.upsert({
      where: { id: "main" },
      update: body,
      create: { id: "main", ...body },
    });

    return NextResponse.json(settings);
  } catch (error) {
    console.error("Failed to update Telegram settings:", error);
    return NextResponse.json({ error: "Failed to update Telegram settings" }, { status: 500 });
  }
}